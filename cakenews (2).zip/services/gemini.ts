
// Ce service a été supprimé. CakeNews est désormais une plateforme 100% humaine.
export {};
