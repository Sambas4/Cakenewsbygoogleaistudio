
import React, { useState, useCallback, useMemo, useEffect, Suspense, lazy } from 'react';
import { HashRouter as Router, Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { AppTab, Category, Message, AppViewMode, Article } from './types';
import { MOCK_ARTICLES, CAKENEWS_MESSAGES } from './data/mockData';
import { CATEGORY_COLORS } from './constants';
import BottomNav from './components/BottomNav';
import ActionBar from './components/ActionBar';
import GlobalModalRegistry from './components/GlobalModalRegistry';
import { InteractionProvider, useInteraction } from './context/InteractionContext';
import { ModalProvider, useModal } from './context/ModalContext';
import { BroadcastProvider } from './context/BroadcastContext';
import { TranslationProvider } from './context/TranslationContext';
import { ToastProvider, useToast } from './context/ToastContext';
import { ModuleLoader } from './components/ui/Loader';
import VibeTicker from './components/ui/VibeTicker';
import BreakingNewsOverlay from './components/ui/BreakingNewsOverlay';
import AuthView from './components/AuthView';
import ErrorBoundary from './components/ui/ErrorBoundary';
import { ChevronLeft } from 'lucide-react';

// Lazy loading
const FeedView = lazy(() => import('./components/FeedView'));
const MessagesView = lazy(() => import('./components/MessagesView'));
const ProfileView = lazy(() => import('./components/ProfileView'));
const AdminView = lazy(() => import('./components/admin/AdminView'));

const GlobalSideSignature = () => (
  <div className="fixed right-0 top-[50vw] -translate-y-1/2 z-[100] pointer-events-none select-none">
    <div className="bg-black/80 border-y border-l border-white/10 py-3 px-1.5 rounded-l-lg flex flex-col items-center transition-all duration-700">
      <span className="text-[5px] font-[1000] uppercase tracking-[0.4em] text-white vertical-text-signature whitespace-nowrap">
        CAKENEWS
      </span>
    </div>
  </div>
);

const TabLoader = () => (
  <div className="w-full h-full flex items-center justify-center bg-black animate-pulse">
    <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
  </div>
);

// Wrapper pour la logique d'état principale
const MainLayout: React.FC<{ 
    viewMode: AppViewMode, 
    allArticles: Article[],
    cnMessages: Message[],
    hasNewNotification: boolean,
    setViewMode: (mode: AppViewMode) => void,
    handleLogout: () => void,
    setCnMessages: React.Dispatch<React.SetStateAction<Message[]>>,
    setHasNewNotification: React.Dispatch<React.SetStateAction<boolean>>,
}> = ({ viewMode, allArticles, cnMessages, hasNewNotification, setViewMode, handleLogout, setCnMessages, setHasNewNotification }) => {
    
    const navigate = useNavigate();
    const location = useLocation();
    const { toggleLike, isLiked, toggleSave, isSaved } = useInteraction();
    const { openModal } = useModal();
    const { showToast } = useToast();

    const [commentTrigger, setCommentTrigger] = useState(0);
    const [isCommentBlinking, setIsCommentBlinking] = useState(false);
    const [unreadCommentsCount, setUnreadCommentsCount] = useState(0);
    
    // --- LOGIQUE MÉMOIRE DE LECTURE ---
    const [lastViewedArticleId, setLastViewedArticleId] = useState<string | null>(null);

    useEffect(() => {
        // Dès qu'on est sur une URL d'article, on mémorise l'ID
        if (location.pathname.startsWith('/article/')) {
            const id = location.pathname.split('/')[2];
            setLastViewedArticleId(id);
        } else if (location.pathname === '/') {
            // Si on est à la racine, c'est le premier article
            if (allArticles.length > 0) setLastViewedArticleId(allArticles[0].id);
        }
    }, [location.pathname, allArticles]);

    // GESTION INTELLIGENTE DU BOUTON INFO
    const handleHomeNavigation = useCallback(() => {
        const isCurrentlyOnFeed = location.pathname === '/' || location.pathname.startsWith('/article/');
        
        if (!isCurrentlyOnFeed) {
            // CAS 1: On revient d'ailleurs (Profil, Messages...)
            // On restaure le dernier article vu
            if (lastViewedArticleId) {
                navigate(`/article/${lastViewedArticleId}`);
            } else {
                navigate('/');
            }
        } else {
            // CAS 2: On est DÉJÀ sur le flux
            // On remonte tout en haut (article le plus récent)
            // C'est le comportement "Scroll to Top" classique
            if (allArticles.length > 0) {
                navigate(`/article/${allArticles[0].id}`);
            }
        }
    }, [location.pathname, lastViewedArticleId, navigate, allArticles]);
    // -----------------------------------

    const currentArticleId = useMemo(() => {
        if (location.pathname.startsWith('/article/')) {
            return location.pathname.split('/')[2];
        }
        if (location.pathname === '/') {
            return allArticles[0]?.id;
        }
        return null;
    }, [location.pathname, allArticles]);

    const currentArticle = useMemo(() => {
        return allArticles.find(a => a.id === currentArticleId) || allArticles[0];
    }, [currentArticleId, allArticles]);

    const handleLike = useCallback(() => {
        if (!currentArticle) return;
        const isAddingLike = !isLiked(currentArticle.id);
        toggleLike(currentArticle.id);
    }, [currentArticle, isLiked, toggleLike]);

    const handleSaveAction = useCallback(() => {
        if (!currentArticle) return;
        toggleSave(currentArticle.id);
        if (!isSaved(currentArticle.id)) {
            showToast("Dossier sauvegardé", "success");
        } else {
            showToast("Retiré des favoris", "info");
        }
    }, [currentArticle, isSaved, toggleSave, showToast]);

    const handleShare = useCallback(() => {
        if (!currentArticle) return;
        openModal('SHARE', { article: currentArticle });
    }, [currentArticle, openModal]);

    const handleReportSubmitted = useCallback((ticketId: string, articleTitle: string) => {
        showToast(`Audit #${ticketId} transmis`, 'success');
        setCnMessages(prev => [{
            id: Date.now().toString(),
            sender: 'Audit CakeNews',
            avatar: 'https://picsum.photos/seed/audit/150/150',
            text: `AUDIT REÇU - Réf: ${ticketId}. Signalement pour "${articleTitle}" en cours d'analyse.`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isOfficial: true,
            articleId: currentArticle?.id
        }, ...prev]);
        setHasNewNotification(true);
    }, [currentArticle, setCnMessages, setHasNewNotification, showToast]);

    const handleNavigateToArticle = (id: string) => navigate(`/article/${id}`);

    const isFeedActive = location.pathname === '/' || location.pathname.startsWith('/article/') || location.pathname === '/feed';
    const accentColor = currentArticle ? (currentArticle.isExclusive ? '#ff0000' : currentArticle.isSensitive ? '#ffcc00' : CATEGORY_COLORS[currentArticle.category]) : '#ffffff';

    return (
        <div className="h-screen w-full bg-black text-white relative overflow-hidden flex flex-col">
            <GlobalSideSignature />
            <BreakingNewsOverlay onNavigate={handleNavigateToArticle} />

            {isFeedActive && (
                <div className="absolute top-0 left-0 right-0 z-[60]">
                    <VibeTicker />
                </div>
            )}

            <main className="flex-1 w-full overflow-hidden relative">
                <ErrorBoundary>
                    <Suspense fallback={<TabLoader />}>
                        <Routes>
                            <Route path="/" element={
                                <FeedView 
                                    articles={allArticles} 
                                    onRoomEnter={() => { setIsCommentBlinking(true); setTimeout(() => setIsCommentBlinking(false), 4000); }}
                                    onUnreadCommentsChange={setUnreadCommentsCount}
                                    commentTrigger={commentTrigger}
                                />
                            } />
                            <Route path="/article/:id" element={
                                <FeedView 
                                    articles={allArticles} 
                                    onRoomEnter={() => { setIsCommentBlinking(true); setTimeout(() => setIsCommentBlinking(false), 4000); }}
                                    onUnreadCommentsChange={setUnreadCommentsCount}
                                    commentTrigger={commentTrigger}
                                />
                            } />
                            <Route path="/feed" element={
                                <FeedView 
                                    articles={allArticles.filter(a => ['Tech', 'Crypto'].includes(a.category))} 
                                    onRoomEnter={() => {}}
                                />
                            } />
                            <Route path="/messages" element={
                                <MessagesView dynamicCakeNewsMessages={cnMessages} onNavigateToArticle={handleNavigateToArticle} />
                            } />
                            <Route path="/profile" element={
                                <ProfileView 
                                    preferences={['Tech']} 
                                    togglePreference={() => {}} 
                                    onLogout={handleLogout}
                                />
                            } />
                            <Route path="*" element={<Navigate to="/" replace />} />
                        </Routes>
                    </Suspense>
                </ErrorBoundary>
            </main>

            <footer className="w-full flex flex-col bg-black relative z-[55] select-none pointer-events-none">
                {isFeedActive && currentArticle && (
                    <div className="pointer-events-auto pb-[60px] bg-black">
                        <ActionBar 
                            likes={currentArticle.likes + (isLiked(currentArticle.id) ? 1 : 0)}
                            comments={currentArticle.comments}
                            isLiked={isLiked(currentArticle.id)}
                            isSaved={isSaved(currentArticle.id)}
                            isCommentBlinking={isCommentBlinking}
                            hasUnreadComments={unreadCommentsCount > 0}
                            accentColor={accentColor}
                            onLike={handleLike}
                            onSave={handleSaveAction}
                            onShare={handleShare}
                            onCommentClick={() => { setCommentTrigger(prev => prev + 1); setIsCommentBlinking(false); }}
                            onReportClick={() => openModal('REPORT', { articleTitle: currentArticle.title, onReportSubmitted: handleReportSubmitted })}
                        />
                    </div>
                )}
            </footer>

            <BottomNav 
                hasNotification={hasNewNotification} 
                onHomeClick={handleHomeNavigation} 
            />
            <GlobalModalRegistry />
        </div>
    );
};

const AppContent: React.FC = () => {
    const [viewMode, setViewMode] = useState<AppViewMode>('AUTH');
    const [allArticles, setAllArticles] = useState<Article[]>(MOCK_ARTICLES);
    const [cnMessages, setCnMessages] = useState<Message[]>(CAKENEWS_MESSAGES);
    const [hasNewNotification, setHasNewNotification] = useState(false);

    const handleArticlePublish = (newArticle: Article) => {
        setAllArticles(prev => [newArticle, ...prev]);
    };

    const handleSendSystemMessage = (target: string, content: string) => {
        const newMessage: Message = {
            id: `sys-${Date.now()}`,
            sender: 'CakeNews Team',
            avatar: 'https://picsum.photos/seed/cake/150/150',
            text: target === 'ALL' ? `[BROADCAST] ${content}` : content,
            time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
            isOfficial: true
        };
        setCnMessages(prev => [newMessage, ...prev]);
        setHasNewNotification(true);
    };

    if (viewMode === 'AUTH') {
        return <AuthView onLogin={(role) => setViewMode(role)} />;
    }

    if (viewMode === 'ADMIN') {
        return (
            <Suspense fallback={<TabLoader />}>
                <AdminView 
                    articles={allArticles}
                    onArticlePublish={handleArticlePublish}
                    onSendSystemMessage={handleSendSystemMessage}
                    onLogout={() => setViewMode('AUTH')}
                />
            </Suspense>
        );
    }

    return (
        <Router>
            <MainLayout 
                viewMode={viewMode}
                allArticles={allArticles}
                cnMessages={cnMessages}
                hasNewNotification={hasNewNotification}
                setViewMode={setViewMode}
                handleLogout={() => setViewMode('AUTH')}
                setCnMessages={setCnMessages}
                setHasNewNotification={setHasNewNotification}
            />
        </Router>
    );
};

const App: React.FC = () => (
  <InteractionProvider>
    <BroadcastProvider>
      <TranslationProvider>
        <ModalProvider>
          <ToastProvider> 
            <AppContent />
          </ToastProvider>
        </ModalProvider>
      </TranslationProvider>
    </BroadcastProvider>
  </InteractionProvider>
);

export default App;
