
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { BroadcastCampaign, TickerConfig, ManualRankingEntry } from '../types';
import { useInteraction } from './InteractionContext';

interface BroadcastContextType {
  campaigns: BroadcastCampaign[];
  activeAlert: BroadcastCampaign | null; // L'alerte prioritaire à afficher en overlay
  activeTickerMessages: BroadcastCampaign[]; // TOUS les messages (Alertes + Infos) pour le bandeau
  config: TickerConfig;
  
  // Actions Admin
  addCampaign: (campaign: BroadcastCampaign) => void;
  updateCampaign: (campaign: BroadcastCampaign) => void;
  deleteCampaign: (id: string) => void;
  updateConfig: (config: TickerConfig) => void;
  addManualRanking: (entry: ManualRankingEntry) => void;
  removeManualRanking: (id: string) => void;
  moveRanking: (id: string, direction: 'up' | 'down') => void;
  
  // Actions User
  dismissAlert: (campaignId: string) => void; // L'utilisateur ferme l'overlay
  recordView: (campaignId: string) => void; // Enregistrer une vue (pour le capping)
}

const BroadcastContext = createContext<BroadcastContextType | undefined>(undefined);

const DEFAULT_CONFIG: TickerConfig = {
  mode: 'HYBRID',
  speed: 'normal',
  defaultLocation: 'Paris',
  rankingMode: 'AUTO',
  manualRankings: [],
  categoryTitles: {} // NOUVEAU
};

export const BroadcastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Récupération de la location et des intérêts de l'utilisateur
  const { userLocation, userInterests } = useInteraction();

  // 1. État des Campagnes (Admin)
  const [campaigns, setCampaigns] = useState<BroadcastCampaign[]>(() => {
    try {
      const saved = localStorage.getItem('cakenews-campaigns');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [config, setConfig] = useState<TickerConfig>(() => {
    try {
      const saved = localStorage.getItem('cakenews-config');
      return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });
  
  // Stockage des vues persistantes : { "campaignId": count }
  const [viewsHistory, setViewsHistory] = useState<Record<string, number>>(() => {
      try {
          const saved = localStorage.getItem('cakenews-views-history');
          return saved ? JSON.parse(saved) : {};
      } catch { return {}; }
  });

  // Stockage de session pour les alertes fermées manuellement par l'utilisateur
  const [sessionDismissed, setSessionDismissed] = useState<Set<string>>(new Set());

  // Persistance
  useEffect(() => {
    localStorage.setItem('cakenews-campaigns', JSON.stringify(campaigns));
  }, [campaigns]);

  useEffect(() => {
    localStorage.setItem('cakenews-config', JSON.stringify(config));
  }, [config]);

  useEffect(() => {
      localStorage.setItem('cakenews-views-history', JSON.stringify(viewsHistory));
  }, [viewsHistory]);


  // --- LOGIQUE DE FILTRAGE INTELLIGENTE ---
  
  const filterCampaigns = useCallback((typeFilter?: 'ALERT' | 'INFO' | 'ALL') => {
      const now = new Date();
      
      return campaigns.filter(c => {
          // 1. Check Status
          if (!c.schedule.isActive) return false;
          
          // 2. Check Type (Optional)
          if (typeFilter && typeFilter !== 'ALL' && c.type !== typeFilter) return false;

          // 3. Check Session Dismiss (Pour l'Overlay seulement)
          if (typeFilter === 'ALERT' && sessionDismissed.has(c.id)) return false;

          // 4. Check Schedule
          const start = new Date(c.schedule.startDate);
          if (now < start) return false;
          if (c.schedule.endDate) {
              const end = new Date(c.schedule.endDate);
              if (now > end) return false;
          }

          // 5. CIBLAGE AVANCÉ (GEOLOCALISATION + INTERETS)
          const hasLocationTargeting = c.targeting.locations.length > 0;
          const hasInterestTargeting = c.targeting.interests && c.targeting.interests.length > 0;

          // Si aucun ciblage n'est défini, c'est GLOBAL (visible par tous)
          if (!hasLocationTargeting && !hasInterestTargeting) {
              // Pass (continue aux checks suivants)
          } else {
              // Logique "Smart Reach" : Match Location OU Match Intérêt
              let matchesLoc = false;
              let matchesInterest = false;

              // Check Location
              if (hasLocationTargeting) {
                  if (userLocation.isSet) {
                      matchesLoc = c.targeting.locations.some(locTag => {
                          const tag = locTag.toLowerCase().trim();
                          return (
                              userLocation.neighborhood.toLowerCase().includes(tag) ||
                              userLocation.city.toLowerCase().includes(tag) ||
                              userLocation.country.toLowerCase().includes(tag)
                          );
                      });
                  }
              }

              // Check Interest
              if (hasInterestTargeting && c.targeting.interests) {
                  matchesInterest = c.targeting.interests.some(cat => userInterests.includes(cat));
              }

              // Si l'utilisateur ne matche NI la zone NI l'intérêt, on masque
              if (!matchesLoc && !matchesInterest) return false;
          }

          // 6. Check Capping Global
          if (c.capping.maxViews > 0) {
              const currentViews = viewsHistory[c.id] || 0;
              if (currentViews >= c.capping.maxViews) return false;
          }

          return true;
      });
  }, [campaigns, userLocation, userInterests, viewsHistory, sessionDismissed]);

  // UPDATE: Le Ticker affiche TOUT (Alertes + Infos), trié par priorité
  const activeTickerMessages = useMemo(() => {
      // On prend 'ALL' pour avoir infos ET alertes dans le bandeau
      return filterCampaigns('ALL').sort((a, b) => b.priority - a.priority);
  }, [filterCampaigns]);

  // L'Overlay ne prend que les 'ALERT' non dismissées
  const activeAlert = useMemo(() => {
      const alerts = filterCampaigns('ALERT').sort((a, b) => b.priority - a.priority);
      return alerts.length > 0 ? alerts[0] : null;
  }, [filterCampaigns]);


  // --- ACTIONS ---

  const addCampaign = (campaign: BroadcastCampaign) => {
      setCampaigns(prev => [...prev, campaign]);
  };

  const updateCampaign = (campaign: BroadcastCampaign) => {
      setCampaigns(prev => prev.map(c => c.id === campaign.id ? campaign : c));
  };

  const deleteCampaign = (id: string) => {
      setCampaigns(prev => prev.filter(c => c.id !== id));
  };

  const updateConfig = (newConfig: TickerConfig) => {
      setConfig(newConfig);
  };

  const addManualRanking = (entry: ManualRankingEntry) => {
      setConfig(prev => ({
          ...prev,
          manualRankings: [...prev.manualRankings, entry]
      }));
  };

  const removeManualRanking = (id: string) => {
      setConfig(prev => ({
          ...prev,
          manualRankings: prev.manualRankings.filter(r => r.id !== id)
      }));
  };

  const moveRanking = (id: string, direction: 'up' | 'down') => {
      setConfig(prev => {
          const list = [...prev.manualRankings];
          const index = list.findIndex(r => r.id === id);
          if (index === -1) return prev;

          if (direction === 'up' && index > 0) {
              [list[index], list[index - 1]] = [list[index - 1], list[index]];
          } else if (direction === 'down' && index < list.length - 1) {
              [list[index], list[index + 1]] = [list[index + 1], list[index]];
          }
          return { ...prev, manualRankings: list };
      });
  };

  const recordView = (campaignId: string) => {
      setViewsHistory(prev => ({
          ...prev,
          [campaignId]: (prev[campaignId] || 0) + 1
      }));
  };

  const dismissAlert = (campaignId: string) => {
      setSessionDismissed(prev => new Set(prev).add(campaignId));
      recordView(campaignId);
  };

  return (
    <BroadcastContext.Provider value={{ 
      campaigns,
      activeAlert,
      activeTickerMessages,
      config,
      addCampaign,
      updateCampaign,
      deleteCampaign,
      updateConfig,
      dismissAlert,
      recordView,
      addManualRanking,
      removeManualRanking,
      moveRanking
    }}>
      {children}
    </BroadcastContext.Provider>
  );
};

export const useBroadcast = () => {
  const context = useContext(BroadcastContext);
  if (!context) throw new Error('useBroadcast must be used within BroadcastProvider');
  return context;
};
