
import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { UserLocation, Category, UserStats } from '../types';

export type ArticleVibe = 'shocked' | 'skeptical' | 'bullish' | 'validated' | null;

interface InteractionContextType {
  likedIds: Set<string>;
  savedIds: Set<string>;
  readItemIds: Set<string>;
  articleVibes: Record<string, ArticleVibe>;
  userLocation: UserLocation;
  userInterests: Category[];
  userStats: UserStats; // NOUVEAU : Tracking Actif
  
  toggleLike: (id: string) => void;
  toggleSave: (id: string) => void;
  markAsRead: (id: string) => void;
  trackCommentPosted: () => void; // NOUVEAU : Incrément commentaires
  setArticleVibe: (articleId: string, vibe: ArticleVibe) => void;
  updateUserLocation: (loc: Partial<UserLocation>) => void;
  toggleUserInterest: (cat: Category) => void;
  isRead: (id: string) => boolean;
  isLiked: (id: string) => boolean;
  isSaved: (id: string) => boolean;
  triggerHaptic: (pattern?: 'light' | 'medium' | 'heavy' | 'success') => void;
}

const InteractionContext = createContext<InteractionContextType | undefined>(undefined);

// Localisation par défaut (Vide)
const DEFAULT_USER_LOCATION: UserLocation = {
    neighborhood: '',
    city: '',
    country: '',
    isSet: false
};

// Stats par défaut (Nouveau User)
const DEFAULT_USER_STATS: UserStats = {
    likesGiven: 0,
    likesReceived: 0, // Mocked pour l'instant
    commentsPosted: 0,
    reportsReceived: 0,
    trustScore: 50 // Départ neutre
};

// Intérêts par défaut
const DEFAULT_INTERESTS: Category[] = ['Tech', 'Crypto', 'Mode', 'Culture'];

export const InteractionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // LIKES
  const [likedIds, setLikedIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('cakenews-likes');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch (e) {
      return new Set();
    }
  });

  // SAVES (FAVORIS)
  const [savedIds, setSavedIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('cakenews-saved');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch (e) {
      return new Set();
    }
  });

  // USER STATS (TRACKING)
  const [userStats, setUserStats] = useState<UserStats>(() => {
      try {
          const saved = localStorage.getItem('cakenews-user-stats');
          return saved ? JSON.parse(saved) : DEFAULT_USER_STATS;
      } catch { return DEFAULT_USER_STATS; }
  });

  // USER LOCATION
  const [userLocation, setUserLocationState] = useState<UserLocation>(() => {
      try {
          const saved = localStorage.getItem('cakenews-user-location');
          return saved ? JSON.parse(saved) : DEFAULT_USER_LOCATION;
      } catch (e) { return DEFAULT_USER_LOCATION; }
  });

  // USER INTERESTS
  const [userInterests, setUserInterests] = useState<Category[]>(() => {
      try {
          const saved = localStorage.getItem('cakenews-user-interests');
          return saved ? JSON.parse(saved) : DEFAULT_INTERESTS;
      } catch (e) { return DEFAULT_INTERESTS; }
  });

  const [readItemIds, setReadItemIds] = useState<Set<string>>(new Set());
  const [articleVibes, setArticleVibes] = useState<Record<string, ArticleVibe>>({});

  // Persistance LIKES
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem('cakenews-likes', JSON.stringify(Array.from(likedIds)));
      } catch (e) { /* Ignore */ }
    }, 1000); 
    return () => clearTimeout(timer);
  }, [likedIds]);

  // Persistance SAVES
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem('cakenews-saved', JSON.stringify(Array.from(savedIds)));
      } catch (e) { /* Ignore */ }
    }, 1000); 
    return () => clearTimeout(timer);
  }, [savedIds]);

  // Persistance STATS
  useEffect(() => {
      const timer = setTimeout(() => {
          localStorage.setItem('cakenews-user-stats', JSON.stringify(userStats));
      }, 500);
      return () => clearTimeout(timer);
  }, [userStats]);

  // Persistance LOCATION
  useEffect(() => {
      localStorage.setItem('cakenews-user-location', JSON.stringify(userLocation));
  }, [userLocation]);

  // Persistance INTERETS
  useEffect(() => {
      localStorage.setItem('cakenews-user-interests', JSON.stringify(userInterests));
  }, [userInterests]);

  const triggerHaptic = useCallback((pattern: 'light' | 'medium' | 'heavy' | 'success' = 'light') => {
     if (navigator.vibrate) {
         switch(pattern) {
             case 'light': navigator.vibrate(10); break;
             case 'medium': navigator.vibrate(25); break;
             case 'heavy': navigator.vibrate([30, 50, 30]); break;
             case 'success': navigator.vibrate([10, 30, 10, 30]); break;
         }
     }
  }, []);

  const toggleLike = useCallback((id: string) => {
    setLikedIds(prev => {
      const next = new Set(prev);
      let newStats = { ...userStats };
      
      if (next.has(id)) {
          next.delete(id);
          // Si on retire un like, on décrémente
          // (Optionnel: on pourrait décider que le like est acquis pour le leaderboard)
          // Ici on veut encourager l'activité donc on compte les actions positives.
      } else {
          next.add(id);
          // TRACKING : LIKE DONNÉ
          newStats.likesGiven += 1;
      }
      
      // Mise à jour différée du state stats pour éviter trop de re-renders si spam click
      setUserStats(newStats);
      return next;
    });
    triggerHaptic('light');
  }, [triggerHaptic, userStats]);

  const toggleSave = useCallback((id: string) => {
    setSavedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    triggerHaptic('success');
  }, [triggerHaptic]);

  const markAsRead = useCallback((id: string) => {
    setReadItemIds(prev => new Set(prev).add(id));
  }, []);

  const trackCommentPosted = useCallback(() => {
      setUserStats(prev => ({
          ...prev,
          commentsPosted: prev.commentsPosted + 1
      }));
  }, []);

  const setArticleVibe = useCallback((articleId: string, vibe: ArticleVibe) => {
    setArticleVibes(prev => ({ ...prev, [articleId]: vibe }));
  }, []);

  const updateUserLocation = useCallback((loc: Partial<UserLocation>) => {
      setUserLocationState(prev => ({ ...prev, ...loc, isSet: true }));
  }, []);

  const toggleUserInterest = useCallback((cat: Category) => {
      setUserInterests(prev => prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]);
  }, []);

  const isRead = useCallback((id: string) => readItemIds.has(id), [readItemIds]);
  const isLiked = useCallback((id: string) => likedIds.has(id), [likedIds]);
  const isSaved = useCallback((id: string) => savedIds.has(id), [savedIds]);

  return (
    <InteractionContext.Provider value={{ 
      likedIds, savedIds, readItemIds, articleVibes, userLocation, userInterests, userStats,
      toggleLike, toggleSave, markAsRead, trackCommentPosted, setArticleVibe, updateUserLocation, toggleUserInterest,
      isRead, isLiked, isSaved, triggerHaptic
    }}>
      {children}
    </InteractionContext.Provider>
  );
};

export const useInteraction = () => {
  const context = useContext(InteractionContext);
  if (!context) throw new Error('useInteraction must be used within InteractionProvider');
  return context;
};
