
import React, { createContext, useContext, useState, useCallback } from 'react';
import { ExternalVoice } from '../types';

type ModalType = 'REPORT' | 'ECHO_VIEWER' | 'TROPHY_VIEWER' | 'HALL_OF_FAME' | 'SHARE' | null;

interface ModalState {
  type: ModalType;
  props?: any;
}

interface ModalContextType {
  modal: ModalState;
  openModal: (type: ModalType, props?: any) => void;
  closeModal: () => void;
}

const ModalContext = createContext<ModalContextType | undefined>(undefined);

export const ModalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [modal, setModal] = useState<ModalState>({ type: null });

  const openModal = useCallback((type: ModalType, props?: any) => {
    setModal({ type, props });
  }, []);

  const closeModal = useCallback(() => {
    setModal({ type: null });
  }, []);

  return (
    <ModalContext.Provider value={{ modal, openModal, closeModal }}>
      {children}
    </ModalContext.Provider>
  );
};

export const useModal = () => {
  const context = useContext(ModalContext);
  if (!context) throw new Error('useModal must be used within ModalProvider');
  return context;
};
