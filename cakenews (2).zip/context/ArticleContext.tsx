
import React, { createContext, useContext } from 'react';
import { Article } from '../types';

interface ArticleContextType {
  article: Article;
  isActive: boolean;
  isUnlocked: boolean;
  accentColor: string;
  readingMode: 'flash' | 'deep';
  setReadingMode: (mode: 'flash' | 'deep') => void;
}

const ArticleContext = createContext<ArticleContextType | undefined>(undefined);

export const ArticleProvider: React.FC<{
  children: React.ReactNode;
  value: ArticleContextType;
}> = ({ children, value }) => {
  return (
    <ArticleContext.Provider value={value}>
      {children}
    </ArticleContext.Provider>
  );
};

export const useArticle = () => {
  const context = useContext(ArticleContext);
  if (!context) {
    throw new Error('useArticle must be used within an ArticleProvider');
  }
  return context;
};
