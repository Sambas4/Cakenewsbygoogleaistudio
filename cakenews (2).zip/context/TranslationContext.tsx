
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { TranslationDictionary } from '../types';

// Dictionnaire FRANÇAIS par défaut (Base immuable)
export const DEFAULT_DICTIONARY: TranslationDictionary = {
  id: 'default_fr',
  name: 'Français (Défaut)',
  isDefault: true,
  translations: {
    // --- NAVIGATION ---
    'NAV_HOME': 'INFO',
    'NAV_FEED': 'FLUX',
    'NAV_CHATS': 'CHATS',
    'NAV_PROFILE': 'MOI',
    
    // --- AUTHENTIFICATION ---
    'AUTH_TITLE': 'ENTREZ VOTRE CLÉ',
    'AUTH_DENIED': 'ACCÈS REFUSÉ',
    'AUTH_BUTTON': 'CONNECTER',
    
    // --- ACTIONS BAR ---
    'ACTION_LIKE': 'J\'aime',
    'ACTION_LIKED': 'Aimé',
    'ACTION_COMMENT': 'Avis',
    'ACTION_SAVE': 'Sauver',
    'ACTION_SAVED': 'Sauvé',
    'ACTION_SHARE': 'Partager',
    'ACTION_REPORT': 'Signaler',
    
    // --- LOCK SCREEN & ALERTS ---
    'LOCK_TITLE': 'ACCÈS SÉCURISÉ',
    'LOCK_DESC': 'Dossier classé secret défense par l\'audit communautaire.',
    'LOCK_UNLOCK': 'DÉBLOQUER L\'INFO',
    'LOCK_SKIP': 'PASSER CE CONTENU',
    'OVERLAY_FLASH_TITLE': 'FLASH SPÉCIAL',
    'OVERLAY_INTERRUPTION': 'Interruption Directe',
    'OVERLAY_OPEN': 'OUVRIR LE DOSSIER',
    'OVERLAY_IGNORE': 'RETOURNER AU DIRECT',
    
    // --- UI ELEMENTS ---
    'UI_LOADING': 'Chargement...',
    'UI_SEARCH': 'Rechercher...',
    'UI_READ_MORE': 'Lire la suite',
    'UI_CLOSE': 'Fermer',
    'UI_BACK': 'Retour',
    'UI_SEND': 'Envoyer',
    'UI_EDIT': 'Éditer',
    'UI_HOTFIX': 'HOTFIX (Corriger)',
    'UI_DELETE': 'Supprimer',
    'UI_CONFIRM': 'Confirmer',
    'UI_CANCEL': 'Annuler',
    'UI_EMPTY': 'Rien à afficher',
    
    // --- MODULE DOSSIER ---
    'DOSSIER_AUDIO_READY': 'Audio Briefing • Prêt',
    'DOSSIER_AUDIO_PLAYING': 'Lecture en cours...',
    'DOSSIER_MODE_FLASH': 'Flash',
    'DOSSIER_MODE_DEEP': 'Immersion',
    'DOSSIER_SIGNATURE': 'Certifié par',
    'DOSSIER_ROLE': 'Membre du Directoire CakeNews',
    'DOSSIER_FLASH_LABEL': 'Dépêche Flash Humaine',
    
    // --- MODULE VIBE ---
    'VIBE_TITLE': 'Vibe Check Communautaire',
    'VIBE_SHOCKED': 'Choqué',
    'VIBE_SKEPTICAL': 'Sceptique',
    'VIBE_BULLISH': 'Bullish',
    'VIBE_VALIDATED': 'Validé',
    'VIBE_DESC': 'Votre réaction définit la température du débat.',

    // --- MODULE ROOM & DEBATS ---
    'ROOM_TAB_DEBATES': 'Débats',
    'ROOM_TAB_ECHOES': 'Échos',
    'ROOM_EMPTY': 'Le débat est ouvert. Lancez-le.',
    'ROOM_INPUT_PLACEHOLDER': 'Participez au débat...',
    'ROOM_REPLY_TO': 'Réponse à',
    'DEBAT_DELETE_CONFIRM': 'Supprimer ?',
    'DEBAT_WARN': 'Signaler',
    
    // --- ECHOES ---
    'ECHO_TITLE_DEFAULT': 'Titre de l\'écho',
    'ECHO_SOURCE_LABEL': 'SELON',
    'ECHO_ANALYSIS_BTN': 'Analyse Complète',
    'ECHO_CERTIFICATION': 'Certification CakeNews',
    'ECHO_SOURCE_BTN': 'Source',
    
    // --- PROFIL ---
    'PROF_TITLE': 'Mon Profil',
    'PROF_MY_ZONE': 'Ma Zone',
    'PROF_ZONE_DESC': 'Configuration requise pour les infos locales.',
    'PROF_CONFIRM_ZONE': 'Confirmer ma zone',
    'PROF_REWARDS': 'Mes Récompenses',
    'PROF_REGISTRY': 'Voir le Registre Officiel',
    'PROF_INTERESTS': 'Mes Intérêts',
    'PROF_INTERESTS_SUB': 'Configurez votre flux d\'élite.',
    'PROF_HISTORY': 'Historique de lecture',
    'PROF_LOGOUT': 'Se déconnecter',
    'PROF_STATS_GIVEN': 'Donnés',
    'PROF_STATS_POSTS': 'Débats',
    'PROF_STATS_RECEIVED': 'Reçus',

    // --- MESSAGERIE ---
    'MSG_TAB_ALERTS': 'Alertes',
    'MSG_TAB_PRIVATE': 'Privé',
    'MSG_TAB_OFFICIAL': 'CakeNews',
    'MSG_EMPTY_ALERTS': 'Zéro activité',
    'MSG_EMPTY_PRIVATE': 'Aucun message privé',
    'MSG_OFFICIAL_DESC': 'Canal de diffusion officiel. Aucune réponse possible.',
    
    // --- REPORT / AUDIT ---
    'RPT_TITLE': 'Audit Public',
    'RPT_SUBTITLE': 'Nature du signalement',
    'RPT_DESC_PLACEHOLDER': 'Décrivez précisément pourquoi ce contenu pose problème...',
    'RPT_BTN_NEXT': 'Suivant : Preuves',
    'RPT_BTN_SUBMIT': 'SCELLER LE DOSSIER',
    'RPT_CAT_TRUTH': 'Contester l\'Info',
    'RPT_CAT_ETHICS': 'Intégrité Éthique',
    'RPT_CAT_TECH': 'Anomalie Technique',
    
    // --- TROPHIES & HALL OF FAME ---
    'HOF_TITLE': 'Registre Officiel',
    'HOF_SUB': 'CakeNews Hall of Fame',
    'HOF_SEARCH': 'Rechercher ID ou User...',
    'HOF_SCAN_BTN': 'Scanner un QR Code',
    'HOF_SCANNING': 'Analyse Camera...',
    'HOF_EMPTY': 'Aucun certificat trouvé.',
    'HOF_VERIFIED': 'Vérifié',
    'HOF_SCORE': 'Score',
    'HOF_ID': 'ID Unique',
    'TROPHY_LABEL': 'Trophée Virtuel',
    'TROPHY_SHARE_BTN': 'Partager',
    'TROPHY_COPIED': 'Copié !',
    'TROPHY_ANTI_FAKE': 'Protection Anti-Fake • Scan pour auditer',

    // --- ADMIN UI ---
    'ADMIN_LOGOUT': 'DÉCONNEXION',
    'ADMIN_TAB_NETWORK': 'RÉSEAU',
    'ADMIN_TAB_FILES': 'DOSSIERS',
    'ADMIN_TAB_ANTENNA': 'ANTENNE',
    'ADMIN_TAB_USERS': 'USERS',
    'ADMIN_TAB_AUDIT': 'AUDIT',
    'ADMIN_TAB_LANG': 'LANGUE',
    'ADMIN_LANG_NEW': 'Nouveau Pack',
    'ADMIN_LANG_SEARCH': 'Rechercher clé...',
    'ADMIN_LANG_RESTORE': 'Restaurer',

    // --- DASHBOARD ADMIN ---
    'DASH_AUDIENCE': 'Audience 24h',
    'DASH_INTERACTIONS': 'Interactions',
    'DASH_VIBE_CHECK': 'Vibe Check (Émotion)',
    'DASH_PERF_TITLE': 'Performance Éditoriale',
    'DASH_READ_RATE': 'Taux de lecture',
    'DASH_VIRALITY': 'Viralité',
    'DASH_INFRA': 'État de l\'Infrastructure',
    'DASH_OPERATIONAL': 'OPÉRATIONNEL',

    // --- ADMIN ANTENNE ---
    'ANT_MONITOR': 'MONITEUR DE DIFFUSION',
    'ANT_ACTIVE': 'ACTIFS',
    'ANT_EMPTY': 'Antenne Vide',
    'ANT_CONFIG_RANK': 'CONFIGURATION CLASSEMENT',
    'ANT_MODE_AUTO': 'Auto',
    'ANT_MODE_HYBRID': 'Mixte',
    'ANT_MODE_MANUAL': 'Manuel',
    'ANT_TITLE_PUBLIC': 'Titre Public',
    'ANT_APPLY': 'Appliquer',
    'ANT_BTN_MSG': 'MESSAGE',
    'ANT_BTN_RANK': 'PODIUM',
    'ANT_CONTENT_EDIT': 'CONTENU ÉDITORIAL',
    'ANT_TARGET_AUDIENCE': 'CIBLAGE AUDIENCE',
    'ANT_GLOBAL': 'GLOBAL (TOUT LE MONDE)',
    'ANT_TARGETED': 'CIBLÉ',
    'ANT_MODE_TV': 'Mode TV',
    'ANT_URGENT': 'Urgent',
    'ANT_SEND': 'ENVOYER',
    'ANT_UPDATE': 'METTRE À JOUR',

    // --- ADMIN STUDIO (DEFAULTS) ---
    'STUDIO_TITLE_PLACEHOLDER': 'TITRE DU DOSSIER...',
    'STUDIO_SUMMARY_PLACEHOLDER': 'RÉSUMÉ FLASH...',
    'STUDIO_CONTENT_PLACEHOLDER': 'CONTENU DÉTAILLÉ DU DOSSIER...',
    'STUDIO_AUTHOR_DEFAULT': 'Rédaction CakeNews',
    'STUDIO_PREVIEW_TITLE': 'Titre du Dossier (Aperçu)',
    'STUDIO_PREVIEW_SUMMARY': 'Ceci est un résumé temporaire pour la prévisualisation.',

    // --- MODULE RESEAU ---
    'RES_TITLE': 'Audit de Résonance',
    'RES_REALTIME': 'Temps Réel',
    'RES_IMPACT': 'Impact & Portée',
    'RES_VIEWS': 'Vues Totales',
    'RES_READ_RATE': 'Taux de Lecture',
    'RES_INTERACTIONS': 'Interactions Humaines',
    'RES_SOURCES': 'Sources Echos',
    'RES_AVG_TIME': 'Temps Moyen',
    'RES_VIRALITY': 'Viralité',
    'RES_INTEGRITY': 'Index d\'Intégrité',
    'RES_REPORTS': 'Signalements',
    'RES_CONTEST': 'Contestations',
    'RES_TRANSPARENCY': 'Transparence Radicale',
    'RES_DISCLAIMER': 'Cakenews s\'engage à la transparence totale.',
    'RES_BTN_FULL': 'Voir le rapport complet',

    // --- GAMIFICATION & RANKS ---
    'RANK_LEGEND': 'LÉGENDE',
    'RANK_INFLUENCER': 'INFLUENCEUR',
    'RANK_ELITE': 'ÉLITE',
    'RANK_TOP10': 'TOP 10',
    'RANK_RANKED': 'CLASSÉ',
    'RANK_INSIDER': 'INITIÉ',
    'RANK_OBSERVER': 'OBSERVATEUR',

    // --- TICKER INDICATORS ---
    'TICKER_URGENT': 'URGENT',
    'TICKER_TARGETED': 'CIBLÉ',
    'TICKER_TOP': 'TOP',
    'TICKER_LIVE': 'LIVE',
    
    // --- CATEGORIES (UI Only) ---
    'CAT_TECH': 'Tech',
    'CAT_POLITIQUE': 'Politique',
    'CAT_SPORT': 'Sport',
    'CAT_CULTURE': 'Culture',
    'CAT_CRYPTO': 'Crypto',
    'CAT_MODE': 'Mode',
    'CAT_LIFESTYLE': 'Lifestyle'
  }
};

interface TranslationContextType {
  currentDictionary: TranslationDictionary;
  availableDictionaries: TranslationDictionary[];
  t: (key: string, defaultVal?: string) => string;
  updateDictionary: (id: string, updates: Partial<TranslationDictionary>) => void;
  createDictionary: (name: string) => void;
  switchDictionary: (id: string) => void;
  deleteDictionary: (id: string) => void;
  resetToDefault: (id: string) => void;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Liste des dictionnaires (chargés depuis le stockage ou défaut)
  const [availableDictionaries, setAvailableDictionaries] = useState<TranslationDictionary[]>(() => {
    try {
      const saved = localStorage.getItem('cakenews-dictionaries');
      return saved ? JSON.parse(saved) : [DEFAULT_DICTIONARY];
    } catch {
      return [DEFAULT_DICTIONARY];
    }
  });

  // ID du dictionnaire actif
  const [activeId, setActiveId] = useState<string>(() => {
    return localStorage.getItem('cakenews-active-lang') || 'default_fr';
  });

  // Dictionnaire actif (computed)
  const currentDictionary = availableDictionaries.find(d => d.id === activeId) || DEFAULT_DICTIONARY;

  // Persistance
  useEffect(() => {
    localStorage.setItem('cakenews-dictionaries', JSON.stringify(availableDictionaries));
  }, [availableDictionaries]);

  useEffect(() => {
    localStorage.setItem('cakenews-active-lang', activeId);
  }, [activeId]);

  // FONCTION DE TRADUCTION
  const t = useCallback((key: string, defaultVal?: string): string => {
    return currentDictionary.translations[key] || defaultVal || key;
  }, [currentDictionary]);

  // ACTIONS
  const updateDictionary = (id: string, updates: Partial<TranslationDictionary>) => {
    setAvailableDictionaries(prev => prev.map(d => {
        if (d.id === id) {
            return { ...d, ...updates };
        }
        return d;
    }));
  };

  const createDictionary = (name: string) => {
    const newDict: TranslationDictionary = {
        id: `custom_${Date.now()}`,
        name: name,
        isDefault: false,
        translations: { ...DEFAULT_DICTIONARY.translations } // Copie des clés par défaut
    };
    setAvailableDictionaries(prev => [...prev, newDict]);
    setActiveId(newDict.id); // Switch auto
  };

  const switchDictionary = (id: string) => {
      setActiveId(id);
  };

  const deleteDictionary = (id: string) => {
      if (id === 'default_fr') return; // Impossible de supprimer le défaut
      setAvailableDictionaries(prev => prev.filter(d => d.id !== id));
      if (activeId === id) setActiveId('default_fr');
  };

  const resetToDefault = (id: string) => {
      setAvailableDictionaries(prev => prev.map(d => {
          if (d.id === id) {
              return { ...d, translations: { ...DEFAULT_DICTIONARY.translations } };
          }
          return d;
      }));
  };

  return (
    <TranslationContext.Provider value={{
      currentDictionary,
      availableDictionaries,
      t,
      updateDictionary,
      createDictionary,
      switchDictionary,
      deleteDictionary,
      resetToDefault
    }}>
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (!context) throw new Error('useTranslation must be used within TranslationProvider');
  return context;
};
