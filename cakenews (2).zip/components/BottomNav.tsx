
import React from 'react';
import { AppTab } from '../types';
import { Home as HomeIcon, Zap as ZapIcon, MessageSquare as MessageIcon, User as UserIcon } from 'lucide-react';
import { useTranslation } from '../context/TranslationContext';
import { useNavigate, useLocation } from 'react-router-dom';

interface BottomNavProps {
  hasNotification?: boolean;
  onHomeClick?: () => void; // NOUVEAU PROP
}

const BottomNav: React.FC<BottomNavProps> = ({ hasNotification, onHomeClick }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  // Mapping des routes vers les IDs d'onglets
  const getActiveTab = () => {
      const p = location.pathname;
      if (p === '/' || p.startsWith('/article/')) return AppTab.HOME;
      if (p === '/feed') return AppTab.MY_FEED;
      if (p === '/messages') return AppTab.MESSAGES;
      if (p === '/profile') return AppTab.PROFILE;
      return AppTab.HOME;
  };

  const activeTab = getActiveTab();

  const handleNav = (tab: AppTab) => {
      switch(tab) {
          case AppTab.HOME: 
            // Si une fonction custom est fournie (logique mémoire), on l'utilise
            if (onHomeClick) {
                onHomeClick();
            } else {
                navigate('/'); 
            }
            break;
          case AppTab.MY_FEED: navigate('/feed'); break;
          case AppTab.MESSAGES: navigate('/messages'); break;
          case AppTab.PROFILE: navigate('/profile'); break;
      }
  };

  const navItems = [
    { id: AppTab.HOME, icon: HomeIcon, label: t('NAV_HOME') },
    { id: AppTab.MY_FEED, icon: ZapIcon, label: t('NAV_FEED') },
    { id: AppTab.MESSAGES, icon: MessageIcon, label: t('NAV_CHATS') },
    { id: AppTab.PROFILE, icon: UserIcon, label: t('NAV_PROFILE') },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-zinc-950 border-t border-white/5 px-2 pb-safe pt-1 z-[300]">
      <div className="w-full flex justify-between items-center h-[52px]">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const showDot = item.id === AppTab.MESSAGES && hasNotification;

          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className="flex flex-col items-center justify-center gap-1 transition-all flex-1 relative active:scale-90 duration-150"
            >
              <div className="relative">
                <Icon 
                  className={`w-4 h-4 transition-all duration-200 ${isActive ? 'text-white scale-110' : 'text-zinc-500'}`} 
                />
                {showDot && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#ff0000] rounded-full border border-black animate-flash"></span>
                )}
              </div>
              <span className={`text-[7.5px] font-black uppercase tracking-[0.2em] ${isActive ? 'text-white' : 'text-zinc-500'}`}>
                {item.label}
              </span>
              {isActive && <div className="absolute -bottom-1 w-6 h-[1.5px] bg-[#ff0000] rounded-full"></div>}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
