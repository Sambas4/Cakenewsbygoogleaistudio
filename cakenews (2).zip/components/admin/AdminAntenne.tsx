
import React, { useState, forwardRef, useImperativeHandle, useMemo, useEffect } from 'react';
import { AdminTabHandle } from './AdminView';
import { BroadcastCampaign, BroadcastType, Article, ManualRankingEntry, Category } from '../../types';
import { CATEGORIES } from '../../constants';
import { MOCK_USERS, MOCK_TICKER_DATA } from '../../data/mockData'; 
import { Radio, Plus, Trash2, Mic2, MapPin, EyeOff, Play, Pause, Search, Link as LinkIcon, Trophy, Zap, User, ArrowUp, ArrowDown, AlertTriangle, MessageSquare, Check, X, Megaphone, Monitor, Tag, Edit2, RotateCcw, Target, PieChart, Globe, Download, RefreshCw, Filter, Sliders, LayoutList, PenLine } from 'lucide-react';
import { useBroadcast } from '../../context/BroadcastContext';
import { useTranslation } from '../../context/TranslationContext'; // IMPORT

interface AdminAntenneProps {
    articles?: Article[]; 
}

type ConsoleMode = 'MESSAGE' | 'RANKING';

const formatCompactNumber = (number: number) => {
  return Intl.NumberFormat('fr-FR', {
    notation: "compact",
    maximumFractionDigits: 1
  }).format(number);
};

// Composant de Titre de Section Réutilisable
const SectionTitle = ({ icon: Icon, title, rightContent }: { icon: any, title: string, rightContent?: React.ReactNode }) => (
    <div className="flex items-center justify-between mb-4 pb-2 border-b border-zinc-800/50">
        <div className="flex items-center gap-2 text-zinc-500">
            <Icon className="w-4 h-4" />
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em]">{title}</h3>
        </div>
        {rightContent}
    </div>
);

const AdminAntenne = forwardRef<AdminTabHandle, AdminAntenneProps>(({ articles = [] }, ref) => {
  const { t } = useTranslation(); // HOOK
  const { 
      campaigns, addCampaign, updateCampaign, deleteCampaign, 
      config, updateConfig, addManualRanking, removeManualRanking, moveRanking 
  } = useBroadcast();
  
  const [consoleMode, setConsoleMode] = useState<ConsoleMode>('MESSAGE');
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // GESTION CLASSEMENT
  const [rankingCategoryFilter, setRankingCategoryFilter] = useState<string>('TOUT');
  const [rankingUserSearch, setRankingUserSearch] = useState('');
  const [categoryTitleEdit, setCategoryTitleEdit] = useState('');

  const [rankingForm, setRankingForm] = useState<{
      score: string;
      categoryLabel: string;
      color: string;
      userId: string;
  }>({ score: '', categoryLabel: '', color: '#ffcc00', userId: '' });

  // Mise à jour automatique du label si on change d'onglet
  useEffect(() => {
      if (rankingCategoryFilter !== 'TOUT') {
          setRankingForm(prev => ({ ...prev, categoryLabel: rankingCategoryFilter }));
          // Pré-remplir le titre existant
          const existingTitle = config.categoryTitles?.[rankingCategoryFilter] || '';
          setCategoryTitleEdit(existingTitle);
      }
  }, [rankingCategoryFilter, config.categoryTitles]);

  // FORMULAIRE MESSAGE
  const [msgForm, setMsgForm] = useState<{
      category: string; // Titre/Catégorie
      text: string;
      isUrgent: boolean; 
      withOverlay: boolean; 
      location: string[];
      interests: Category[];
      linkedArticleId: string;
  }>({
      category: '',
      text: '',
      isUrgent: false,
      withOverlay: false,
      location: [],
      interests: [],
      linkedArticleId: ''
  });

  const [locInput, setLocInput] = useState(''); // Pour l'input de location

  const availableUsers = useMemo(() => {
      if (!rankingUserSearch) return [];
      return MOCK_USERS.filter(u => u.name.toLowerCase().includes(rankingUserSearch.toLowerCase()));
  }, [rankingUserSearch]);

  const availableLocations = useMemo(() => {
      const locs = new Set<string>();
      MOCK_USERS.forEach(user => {
          if (user.location?.isSet) {
              if (user.location.neighborhood) locs.add(user.location.neighborhood);
              if (user.location.city) locs.add(user.location.city);
          }
      });
      return Array.from(locs).sort();
  }, []);

  const filteredRankings = useMemo(() => {
      if (rankingCategoryFilter === 'TOUT') return config.manualRankings;
      return config.manualRankings.filter(entry => 
          entry.categoryLabel.toUpperCase() === rankingCategoryFilter.toUpperCase()
      );
  }, [config.manualRankings, rankingCategoryFilter]);

  useImperativeHandle(ref, () => ({
    handleBack: () => {
        if (editingId) {
            handleCancelEdit();
            return true;
        }
        return false;
    }
  }));

  // --- ACTIONS ---

  const handleEdit = (c: BroadcastCampaign) => {
      setMsgForm({
          category: c.name,
          text: c.message,
          isUrgent: c.priority === 8,
          withOverlay: c.type === 'ALERT',
          location: c.targeting.locations,
          interests: c.targeting.interests || [],
          linkedArticleId: c.linkedArticleId || ''
      });
      setEditingId(c.id);
      setConsoleMode('MESSAGE');
  };

  const handleCancelEdit = () => {
      setMsgForm({ category: '', text: '', isUrgent: false, withOverlay: false, location: [], interests: [], linkedArticleId: '' });
      setEditingId(null);
  };

  const handlePublishMessage = () => {
      if (!msgForm.text) return;

      const type: BroadcastType = msgForm.withOverlay ? 'ALERT' : 'INFO';
      const priority = msgForm.withOverlay ? 10 : (msgForm.isUrgent ? 8 : 5);
      
      if (editingId) {
          // MODE MISE À JOUR
          const existing = campaigns.find(c => c.id === editingId);
          if (existing) {
              const updated: BroadcastCampaign = {
                  ...existing,
                  name: msgForm.category ? msgForm.category.toUpperCase() : 'INFO',
                  message: msgForm.text,
                  type: type,
                  priority: priority,
                  targeting: { 
                      ...existing.targeting, 
                      locations: msgForm.location,
                      interests: msgForm.interests
                  },
                  linkedArticleId: msgForm.linkedArticleId || undefined
              };
              updateCampaign(updated);
          }
      } else {
          // MODE CRÉATION
          const newCampaign: BroadcastCampaign = {
              id: Date.now().toString(),
              name: msgForm.category ? msgForm.category.toUpperCase() : 'INFO', 
              message: msgForm.text,
              type: type,
              priority: priority,
              capping: { maxViews: 0, resetPeriod: 'never' },
              targeting: { 
                  locations: msgForm.location,
                  interests: msgForm.interests
              },
              schedule: { startDate: new Date().toISOString(), isActive: true },
              createdAt: new Date().toISOString(),
              linkedArticleId: msgForm.linkedArticleId || undefined
          };
          addCampaign(newCampaign);
      }

      handleCancelEdit(); // Reset form & exit edit mode
  };

  const handleAddRanking = () => {
      const user = MOCK_USERS.find(u => u.id === rankingForm.userId);
      if (!user || !rankingForm.score || !rankingForm.categoryLabel) return;
      const numericScore = parseFloat(rankingForm.score);
      const entry: ManualRankingEntry = {
          id: Date.now().toString(),
          userName: user.name,
          avatar: user.avatar,
          score: formatCompactNumber(numericScore),
          rawValue: numericScore,
          categoryLabel: rankingForm.categoryLabel.toUpperCase(),
          color: rankingForm.color
      };
      addManualRanking(entry);
      // Reset intelligent: on garde la catégorie si on est dans un onglet spécifique
      setRankingForm(prev => ({ 
          ...prev, 
          score: '', 
          userId: '',
          categoryLabel: rankingCategoryFilter !== 'TOUT' ? rankingCategoryFilter : ''
      }));
      setRankingUserSearch('');
  };

  const handleUpdateCategoryTitle = () => {
      if (rankingCategoryFilter === 'TOUT') return;
      const newTitles = { ...config.categoryTitles, [rankingCategoryFilter]: categoryTitleEdit };
      updateConfig({ ...config, categoryTitles: newTitles });
  };

  const handleLoadDemoData = () => {
      const demoEntries: ManualRankingEntry[] = [];
      const newTitles = { ...config.categoryTitles };
      
      MOCK_TICKER_DATA.forEach(group => {
          const cat = group.users[0]?.category || 'DIVERS';
          newTitles[cat] = group.label;

          group.users.forEach((user, index) => {
              demoEntries.push({
                  id: `demo-${Date.now()}-${index}-${user.name}`,
                  userName: user.name,
                  avatar: `https://i.pravatar.cc/150?u=${user.name}`,
                  score: user.score,
                  rawValue: parseInt(user.score.replace(/\s/g, ''), 10) || 0,
                  categoryLabel: cat,
                  color: group.color
              });
          });
      });

      updateConfig({ 
          ...config, 
          manualRankings: demoEntries,
          rankingMode: 'MANUAL',
          categoryTitles: newTitles
      });
  };

  const handleClearRankings = () => {
      updateConfig({ ...config, manualRankings: [] });
  }

  const toggleCampaignStatus = (campaign: BroadcastCampaign) => {
      updateCampaign({
          ...campaign,
          schedule: { ...campaign.schedule, isActive: !campaign.schedule.isActive }
      });
  };

  const addLocation = (loc: string) => {
      if (!loc) return;
      const cleanLoc = loc.trim();
      if (!msgForm.location.includes(cleanLoc)) {
          setMsgForm(prev => ({ ...prev, location: [...prev.location, cleanLoc] }));
      }
      setLocInput('');
  };

  const removeLocation = (loc: string) => {
      setMsgForm(prev => ({ ...prev, location: prev.location.filter(l => l !== loc) }));
  };

  const toggleInterest = (cat: Category) => {
      setMsgForm(prev => {
          const exists = prev.interests.includes(cat);
          return {
              ...prev,
              interests: exists ? prev.interests.filter(c => c !== cat) : [...prev.interests, cat]
          };
      });
  };

  // --- HELPERS VISUELS ---
  
  const getCardStyle = (c: BroadcastCampaign) => {
      if (c.id === editingId) return 'bg-zinc-800 border-yellow-500 ring-1 ring-yellow-500 shadow-xl scale-[1.02] z-10';
      if (!c.schedule.isActive) return 'bg-zinc-900 border-zinc-800 opacity-50 grayscale';
      if (c.priority >= 8) return 'bg-red-600 border-red-500 shadow-[0_0_20px_rgba(220,38,38,0.4)] text-white';
      if (c.type === 'ALERT') return 'bg-white border-white shadow-[0_0_30px_rgba(255,255,255,0.2)] text-black';
      return 'bg-zinc-900 border-zinc-700 text-zinc-300';
  };

  const getInputStyle = () => {
      if (msgForm.isUrgent) return 'bg-red-600 text-white border-red-500 placeholder:text-white/60';
      if (msgForm.withOverlay) return 'bg-white text-black border-white placeholder:text-black/40';
      return 'bg-black text-white border-zinc-700 placeholder:text-zinc-600';
  };

  return (
    <div className="h-full bg-zinc-950 flex flex-col relative overflow-hidden font-sans">
      
      {/* 1. VISUALISATION DES FLUX */}
      <div className="flex-1 overflow-y-auto p-4 pb-96">
          
          {/* SECTION 1: ANTENNE DIRECTE */}
          <section className="mb-8">
              <SectionTitle 
                  icon={Radio} 
                  title={t('ANT_MONITOR')}
                  rightContent={<span className="text-[9px] font-bold text-zinc-600">{campaigns.length} {t('ANT_ACTIVE')}</span>}
              />

              <div className="space-y-4">
                  {campaigns.length === 0 && (
                      <div className="p-8 border-2 border-dashed border-zinc-800 rounded-xl text-center flex flex-col items-center gap-2">
                          <Mic2 className="w-6 h-6 text-zinc-700" />
                          <p className="text-[10px] text-zinc-600 uppercase tracking-widest">{t('ANT_EMPTY')}</p>
                      </div>
                  )}

                  {campaigns
                    .sort((a, b) => b.priority - a.priority)
                    .map(campaign => (
                      <div 
                        key={campaign.id} 
                        className={`relative p-4 rounded-xl border flex flex-col gap-2 transition-all duration-300 ${getCardStyle(campaign)}`}
                      >
                          <div className="flex justify-between items-start">
                              <div className="flex items-center gap-4 flex-1">
                                  <button 
                                    onClick={() => toggleCampaignStatus(campaign)} 
                                    className={`hover:scale-110 transition-transform p-2 rounded-full ${campaign.schedule.isActive ? 'bg-white/10' : 'bg-black/20'}`}
                                  >
                                      {campaign.schedule.isActive ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
                                  </button>
                                  
                                  <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-widest ${campaign.priority >= 8 ? 'bg-white text-black' : 'bg-blue-500 text-white'}`}>
                                              {campaign.name}
                                          </span>

                                          {campaign.type === 'ALERT' && (
                                              <span className={`px-2 py-0.5 rounded border text-[9px] font-black uppercase tracking-widest flex items-center gap-1 animate-pulse ${campaign.priority >= 8 ? 'bg-white text-red-600 border-white' : 'bg-red-600 text-white border-red-500'}`}>
                                                  <Monitor className="w-3 h-3" /> OVERLAY TV
                                              </span>
                                          )}
                                          
                                          {/* INDICATEURS DE CIBLAGE */}
                                          {(campaign.targeting.locations.length > 0 || (campaign.targeting.interests && campaign.targeting.interests.length > 0)) ? (
                                              <div className="flex items-center gap-2 opacity-80">
                                                  {campaign.targeting.locations.length > 0 && (
                                                      <span className="text-[9px] font-bold uppercase flex items-center gap-1 bg-white/20 px-1.5 rounded">
                                                          <MapPin className="w-3 h-3" />
                                                          {campaign.targeting.locations.length} ZONES
                                                      </span>
                                                  )}
                                                  {campaign.targeting.interests && campaign.targeting.interests.length > 0 && (
                                                      <span className="text-[9px] font-bold uppercase flex items-center gap-1 bg-white/20 px-1.5 rounded">
                                                          <PieChart className="w-3 h-3" />
                                                          {campaign.targeting.interests.length} INTÉRÊTS
                                                      </span>
                                                  )}
                                              </div>
                                          ) : (
                                              <span className="text-[9px] font-bold uppercase opacity-60 flex items-center gap-1">
                                                  <Globe className="w-3 h-3" /> {t('ANT_GLOBAL')}
                                              </span>
                                          )}
                                      </div>
                                      
                                      <p className="text-base font-bold leading-tight break-words">
                                          {campaign.message}
                                      </p>
                                  </div>
                              </div>
                              <div className="flex items-center gap-1">
                                  <button onClick={() => handleEdit(campaign)} className="opacity-60 hover:opacity-100 p-2 hover:bg-white/10 rounded-lg transition-all text-current"><Edit2 className="w-4 h-4" /></button>
                                  <button onClick={() => deleteCampaign(campaign.id)} className="opacity-60 hover:opacity-100 p-2 hover:bg-red-500/20 hover:text-red-500 rounded-lg transition-all"><Trash2 className="w-4 h-4" /></button>
                              </div>
                          </div>
                      </div>
                  ))}
              </div>
          </section>
          
          {/* SECTION 2: CLASSEMENT TICKER */}
          <section className="pt-6 border-t border-zinc-800">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-zinc-800/50">
                  <div className="flex items-center gap-2 text-zinc-500">
                      <Trophy className="w-4 h-4" />
                      <h3 className="text-[10px] font-black uppercase tracking-[0.2em]">{t('ANT_CONFIG_RANK')}</h3>
                  </div>
                  
                  {/* BOUTONS ACTIONS CLASSEMENT */}
                  <div className="flex bg-black p-0.5 rounded border border-zinc-800">
                      <button onClick={() => updateConfig({ ...config, rankingMode: 'AUTO' })} className={`px-2 py-1 text-[8px] font-black uppercase rounded ${config.rankingMode === 'AUTO' ? 'bg-zinc-800 text-white' : 'text-zinc-600'}`}>{t('ANT_MODE_AUTO')}</button>
                      <button onClick={() => updateConfig({ ...config, rankingMode: 'HYBRID' })} className={`px-2 py-1 text-[8px] font-black uppercase rounded ${config.rankingMode === 'HYBRID' ? 'bg-sky-600 text-white' : 'text-zinc-600'}`}>{t('ANT_MODE_HYBRID')}</button>
                      <button onClick={() => updateConfig({ ...config, rankingMode: 'MANUAL' })} className={`px-2 py-1 text-[8px] font-black uppercase rounded ${config.rankingMode === 'MANUAL' ? 'bg-[#ffcc00] text-black' : 'text-zinc-600'}`}>{t('ANT_MODE_MANUAL')}</button>
                  </div>
              </div>

              {/* BARRE D'ONGLETS CATEGORIES */}
              <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-4 px-1">
                  {['TOUT', ...CATEGORIES].map(cat => (
                      <button
                          key={cat}
                          onClick={() => setRankingCategoryFilter(cat)}
                          className={`flex-shrink-0 px-3 py-1.5 rounded-lg border text-[9px] font-black uppercase tracking-widest transition-all ${
                              rankingCategoryFilter === cat 
                              ? 'bg-white text-black border-white' 
                              : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-zinc-600'
                          }`}
                      >
                          {cat === 'TOUT' ? 'TOUT' : t(`CAT_${cat.toUpperCase()}`, cat)}
                      </button>
                  ))}
              </div>

              {/* CONFIGURATION DU TITRE DE LA CATEGORIE (SI FILTRE ACTIF) */}
              {rankingCategoryFilter !== 'TOUT' && (
                  <div className="mb-6 p-4 bg-zinc-900 border border-zinc-800 rounded-xl animate-in slide-in-from-top-2">
                      <div className="flex items-center gap-2 mb-2">
                          <PenLine className="w-3 h-3 text-zinc-500" />
                          <span className="text-[9px] font-black uppercase text-zinc-500 tracking-widest">{t('ANT_TITLE_PUBLIC')} ({rankingCategoryFilter})</span>
                      </div>
                      <div className="flex gap-2">
                          <input 
                              type="text" 
                              value={categoryTitleEdit}
                              onChange={(e) => setCategoryTitleEdit(e.target.value)}
                              placeholder={`Ex: LES ROIS DE LA ${rankingCategoryFilter}`}
                              className="flex-1 bg-black border border-zinc-700 rounded-lg px-3 py-2 text-xs text-white font-bold outline-none focus:border-white/50 uppercase"
                          />
                          <button 
                              onClick={handleUpdateCategoryTitle}
                              className="px-4 bg-zinc-800 text-white rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-zinc-700"
                          >
                              {t('ANT_APPLY')}
                          </button>
                      </div>
                  </div>
              )}

              {/* LISTE DES CLASSEMENTS FILTRÉE */}
              <div className="space-y-2 min-h-[100px]">
                  {filteredRankings.length === 0 ? (
                      <div className="p-6 border border-dashed border-zinc-800 rounded-xl flex flex-col items-center justify-center opacity-50">
                          <Filter className="w-5 h-5 text-zinc-600 mb-2" />
                          <p className="text-[9px] text-zinc-600 uppercase tracking-widest">
                              Aucun classement {rankingCategoryFilter !== 'TOUT' ? `en ${rankingCategoryFilter}` : 'configuré'}
                          </p>
                          {config.manualRankings.length === 0 && (
                              <button 
                                  onClick={handleLoadDemoData}
                                  className="mt-4 flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-[9px] font-black uppercase text-zinc-400 hover:text-white"
                              >
                                  <Download className="w-3 h-3" /> Charger Démo
                              </button>
                          )}
                      </div>
                  ) : (
                      filteredRankings.map((entry, idx) => (
                          <div key={entry.id} className="flex items-center justify-between bg-zinc-900 border border-zinc-800 p-3 rounded-xl hover:bg-zinc-800 transition-colors group">
                              <div className="flex items-center gap-4">
                                  <div className="flex flex-col items-center justify-center w-6">
                                      <span className={`text-xs font-black ${idx < 3 ? 'text-[#ffcc00]' : 'text-zinc-600'}`}>#{idx + 1}</span>
                                      {idx < 3 && <Trophy className="w-2 h-2 text-[#ffcc00] mt-0.5" />}
                                  </div>
                                  
                                  <img src={entry.avatar} className="w-8 h-8 rounded-full border border-zinc-700 object-cover" alt="" />
                                  
                                  <div className="flex flex-col">
                                      <span className="text-xs font-bold text-white leading-none">{entry.userName}</span>
                                      <div className="flex items-center gap-2 mt-1">
                                          <span 
                                            className="text-[8px] font-black px-1.5 py-0.5 rounded text-black uppercase"
                                            style={{ backgroundColor: entry.color }}
                                          >
                                              {entry.categoryLabel}
                                          </span>
                                          <span className="text-[9px] font-mono text-zinc-500">{entry.score} pts</span>
                                      </div>
                                  </div>
                              </div>
                              
                              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <button onClick={() => moveRanking(entry.id, 'up')} className="p-1.5 hover:bg-white/10 rounded"><ArrowUp className="w-3 h-3 text-zinc-400" /></button>
                                  <button onClick={() => moveRanking(entry.id, 'down')} className="p-1.5 hover:bg-white/10 rounded"><ArrowDown className="w-3 h-3 text-zinc-400" /></button>
                                  <button onClick={() => removeManualRanking(entry.id)} className="p-1.5 hover:bg-red-500/20 rounded text-zinc-600 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>
                              </div>
                          </div>
                      ))
                  )}
                  
                  {config.manualRankings.length > 0 && rankingCategoryFilter === 'TOUT' && (
                      <div className="flex justify-center pt-2">
                          <button 
                              onClick={handleClearRankings}
                              className="text-[9px] font-bold text-red-500 hover:text-red-400 flex items-center gap-1 uppercase tracking-widest"
                          >
                              <RefreshCw className="w-3 h-3" /> RàZ Liste
                          </button>
                      </div>
                  )}
              </div>
          </section>
      </div>

      {/* 2. CONSOLE DE COMMANDE */}
      <div className="absolute bottom-0 left-0 right-0 bg-black border-t border-zinc-800 z-20 shadow-[0_-20px_50px_rgba(0,0,0,0.8)]">
          <div className="flex">
              <button onClick={() => setConsoleMode('MESSAGE')} className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border-t-2 transition-colors ${consoleMode === 'MESSAGE' ? 'border-white bg-zinc-900 text-white' : 'border-transparent text-zinc-600 hover:text-zinc-400 bg-black'}`}>
                  <MessageSquare className="w-3 h-3" /> {editingId ? 'MODIFICATION' : t('ANT_BTN_MSG')}
              </button>
              <button onClick={() => setConsoleMode('RANKING')} className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border-t-2 transition-colors ${consoleMode === 'RANKING' ? 'border-[#ffcc00] bg-zinc-900 text-white' : 'border-transparent text-zinc-600 hover:text-zinc-400 bg-black'}`}>
                  <Trophy className="w-3 h-3" /> {t('ANT_BTN_RANK')}
              </button>
          </div>

          <div className="p-4 bg-zinc-900 pb-8 max-h-[60vh] overflow-y-auto">
              {consoleMode === 'MESSAGE' && (
                  <div className="space-y-4 animate-in slide-in-from-bottom-2">
                      
                      {/* BLOC 1: CONTENU */}
                      <div>
                          <SectionTitle icon={Edit2} title={t('ANT_CONTENT_EDIT')} />
                          <div className="flex flex-col gap-2">
                              <div className="relative">
                                  <input 
                                      type="text"
                                      value={msgForm.category}
                                      onChange={(e) => setMsgForm({...msgForm, category: e.target.value})}
                                      placeholder="TITRE / CATÉGORIE (Ex: CHOC, SANTÉ...)"
                                      className={`w-full rounded-lg px-4 py-2 text-xs font-black uppercase outline-none transition-all ${msgForm.isUrgent ? 'bg-red-900/50 text-white border-red-500 border placeholder:text-red-300' : 'bg-black border border-zinc-700 text-white placeholder:text-zinc-600'}`}
                                  />
                                  <Tag className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-500" />
                              </div>

                              <div className="flex gap-2 items-stretch h-20">
                                  <textarea 
                                      value={msgForm.text}
                                      onChange={(e) => setMsgForm({...msgForm, text: e.target.value})}
                                      placeholder={msgForm.withOverlay ? "CONTENU DE L'ALERTE FLASH..." : "Contenu de l'information défilante..."}
                                      className={`flex-1 rounded-xl p-3 text-sm font-bold uppercase outline-none resize-none transition-all duration-300 ${getInputStyle()}`}
                                  />
                                  <div className="flex flex-col gap-2 w-24">
                                      <button 
                                          onClick={() => setMsgForm({...msgForm, withOverlay: !msgForm.withOverlay})}
                                          className={`flex-1 px-2 rounded-lg flex flex-col items-center justify-center gap-1 border transition-all duration-200 ${msgForm.withOverlay ? 'bg-white text-black border-white' : 'bg-black border-zinc-800 text-zinc-600 hover:border-zinc-600'}`}
                                      >
                                          <Monitor className="w-4 h-4" />
                                          <span className="text-[7px] font-black uppercase tracking-tighter">{t('ANT_MODE_TV')}</span>
                                      </button>
                                      <button 
                                          onClick={() => setMsgForm({...msgForm, isUrgent: !msgForm.isUrgent})}
                                          className={`flex-1 px-2 rounded-lg flex flex-col items-center justify-center gap-1 border transition-all duration-200 ${msgForm.isUrgent && !msgForm.withOverlay ? 'bg-red-600 text-white border-red-600' : 'bg-black border-zinc-800 text-zinc-600'}`}
                                          disabled={msgForm.withOverlay}
                                      >
                                          <Zap className="w-4 h-4" />
                                          <span className="text-[7px] font-black uppercase tracking-tighter">{t('ANT_URGENT')}</span>
                                      </button>
                                  </div>
                              </div>
                          </div>
                      </div>

                      {/* BLOC 2: CIBLAGE */}
                      <div className="bg-black border border-zinc-800 rounded-xl p-3 space-y-3">
                          <SectionTitle 
                              icon={Target} 
                              title={t('ANT_TARGET_AUDIENCE')} 
                              rightContent={
                                <span className="text-[8px] font-mono text-zinc-600">
                                    {(msgForm.location.length === 0 && msgForm.interests.length === 0) ? t('ANT_GLOBAL') : t('ANT_TARGETED')}
                                </span>
                              }
                          />

                          {/* 1. GEOLOCALISATION */}
                          <div className="space-y-2">
                              <div className="flex gap-2">
                                  <div className="relative flex-1">
                                      <input 
                                          type="text" 
                                          value={locInput}
                                          onChange={(e) => setLocInput(e.target.value)}
                                          onKeyDown={(e) => { if(e.key === 'Enter') addLocation(locInput); }}
                                          placeholder="Ajouter une zone (Ville, Quartier...)"
                                          className="w-full bg-zinc-900 border border-zinc-800 px-3 py-2 pl-8 text-xs text-white rounded-lg outline-none focus:border-white/20"
                                      />
                                      <MapPin className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-500" />
                                  </div>
                                  <button onClick={() => addLocation(locInput)} className="px-3 bg-zinc-800 text-white rounded-lg hover:bg-zinc-700">
                                      <Plus className="w-4 h-4" />
                                  </button>
                              </div>
                              {/* Suggestions rapides */}
                              <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
                                  {availableLocations.slice(0, 5).map(loc => (
                                      <button key={loc} onClick={() => addLocation(loc)} className="whitespace-nowrap px-2 py-1 bg-zinc-900 border border-zinc-800 rounded text-[9px] text-zinc-500 hover:text-white uppercase font-bold">
                                          {loc}
                                      </button>
                                  ))}
                              </div>
                              {/* Tags sélectionnés */}
                              <div className="flex flex-wrap gap-2">
                                  {msgForm.location.map(loc => (
                                      <span key={loc} className="flex items-center gap-1 px-2 py-1 bg-sky-900/30 border border-sky-500/30 text-sky-400 rounded-md text-[10px] font-bold uppercase">
                                          {loc}
                                          <button onClick={() => removeLocation(loc)}><X className="w-3 h-3 hover:text-white" /></button>
                                      </span>
                                  ))}
                              </div>
                          </div>

                          <div className="h-[1px] bg-zinc-800 w-full my-2"></div>

                          {/* 2. INTERETS */}
                          <div>
                              <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest block mb-2">Cibler aussi par intérêt (Même hors zone)</span>
                              <div className="flex flex-wrap gap-2">
                                  {CATEGORIES.map(cat => (
                                      <button
                                          key={cat}
                                          onClick={() => toggleInterest(cat)}
                                          className={`px-2 py-1 rounded text-[9px] font-bold uppercase border transition-all ${
                                              msgForm.interests.includes(cat) 
                                              ? 'bg-purple-600 text-white border-purple-500' 
                                              : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-zinc-600'
                                          }`}
                                      >
                                          {t(`CAT_${cat.toUpperCase()}`, cat)}
                                      </button>
                                  ))}
                              </div>
                          </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                          {editingId && (
                              <button onClick={handleCancelEdit} className="px-4 bg-zinc-800 text-zinc-400 rounded-xl font-black uppercase text-xs hover:text-white hover:bg-zinc-700">
                                  <RotateCcw className="w-4 h-4" />
                              </button>
                          )}
                          <button 
                              onClick={handlePublishMessage}
                              disabled={!msgForm.text}
                              className={`flex-1 py-4 font-black uppercase text-xs tracking-widest rounded-xl hover:scale-[1.01] active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 shadow-xl flex items-center justify-center gap-2 ${
                                  msgForm.isUrgent ? 'bg-red-600 text-white' : (msgForm.withOverlay ? 'bg-white text-black' : 'bg-zinc-800 text-white hover:bg-zinc-700')
                              }`}
                          >
                              {editingId ? <><Edit2 className="w-4 h-4" /> {t('ANT_UPDATE')}</> : (msgForm.isUrgent ? t('ANT_SEND') : (msgForm.withOverlay ? 'LANCER INTERRUPTION ANTENNE' : 'AJOUTER AU CLASSEMENT'))}
                          </button>
                      </div>
                  </div>
              )}
              {/* (Ranking Form Updated with Auto-Label Logic) */}
              {consoleMode === 'RANKING' && (
                  <div className="space-y-4 animate-in slide-in-from-bottom-2">
                      <SectionTitle icon={Sliders} title="CONFIGURATION DU PROFIL" />
                      
                      <div className="relative">
                          <input type="text" value={rankingUserSearch} onChange={(e) => setRankingUserSearch(e.target.value)} placeholder="Rechercher utilisateur..." className="w-full bg-black border border-zinc-700 rounded-xl py-3 pl-4 pr-4 text-white text-xs font-bold outline-none" />
                          {rankingUserSearch && availableUsers.length > 0 && !rankingForm.userId && (
                              <div className="absolute bottom-full left-0 right-0 bg-zinc-900 border border-zinc-700 mb-1 rounded-xl max-h-32 overflow-y-auto z-10 shadow-xl">
                                  {availableUsers.map(u => (
                                      <button key={u.id} onClick={() => { setRankingForm(prev => ({ ...prev, userId: u.id })); setRankingUserSearch(u.name); }} className="w-full text-left p-3 hover:bg-zinc-800 flex items-center gap-3 border-b border-zinc-800 last:border-0">
                                          <img src={u.avatar} className="w-6 h-6 rounded-full" alt="" />
                                          <span className="text-xs text-white font-bold">{u.name}</span>
                                      </button>
                                  ))}
                              </div>
                          )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                          <input type="number" min="0" value={rankingForm.score} onChange={(e) => setRankingForm(prev => ({ ...prev, score: e.target.value }))} placeholder="Score" className="bg-black border border-zinc-700 rounded-xl p-3 text-white text-xs font-bold outline-none" />
                          <input type="text" value={rankingForm.categoryLabel} onChange={(e) => setRankingForm(prev => ({ ...prev, categoryLabel: e.target.value }))} placeholder="Label (ex: TECH)" className="bg-black border border-zinc-700 rounded-xl p-3 text-white text-xs font-bold outline-none uppercase" />
                      </div>
                      <button onClick={handleAddRanking} disabled={!rankingForm.userId || !rankingForm.score} className="w-full py-4 bg-[#ffcc00] text-black font-black uppercase text-xs tracking-widest rounded-xl hover:bg-white active:scale-95 transition-all disabled:opacity-50 mt-2">ÉPINGLER AU SOMMET</button>
                  </div>
              )}
          </div>
      </div>
    </div>
  );
});

export default AdminAntenne;
