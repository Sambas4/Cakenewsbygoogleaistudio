
import React, { useState, useEffect, useRef } from 'react';
import { AdminTab, Article } from '../../types';
import { BarChart3, Layers, ShieldAlert, Database, Users, ChevronLeft, X, Save, Clock, Send, Eye, Radio, Globe } from 'lucide-react';
import AdminDashboard from './AdminDashboard';
import AdminStudio from './AdminStudio';
import AdminUsers from './AdminUsers';
import AdminAudit from './AdminAudit';
import AdminAntenne from './AdminAntenne';
import AdminLocalisation from './AdminLocalisation';
import ArticleCard from '../ArticleCard';
import { useTranslation } from '../../context/TranslationContext'; // IMPORT

interface AdminViewProps {
  articles: Article[];
  onArticlePublish: (article: Article) => void;
  onSendSystemMessage: (target: string, content: string) => void;
  onLogout: () => void;
}

export interface AdminTabHandle {
  handleBack: () => boolean; 
}

const AdminView: React.FC<AdminViewProps> = ({ 
    articles, 
    onArticlePublish, 
    onSendSystemMessage, 
    onLogout
}) => {
  const { t } = useTranslation(); // HOOK
  const [activeTab, setActiveTab] = useState<AdminTab>(AdminTab.RESEAU);
  const [previewArticle, setPreviewArticle] = useState<Article | null>(null);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const activeTabRef = useRef<AdminTabHandle>(null);

  useEffect(() => {
    if (previewArticle) {
        setEditingArticle(JSON.parse(JSON.stringify(previewArticle)));
    } else {
        setEditingArticle(null);
    }
  }, [previewArticle]);

  const handlePreview = (article: Article) => {
    setPreviewArticle(article);
  };

  const handleEditFromAudit = (articleId: string) => {
      const articleToEdit = articles.find(a => a.id === articleId);
      if (articleToEdit) {
          setPreviewArticle(articleToEdit);
      } else {
          alert("Article introuvable ou supprimé.");
      }
  };

  const closePreview = () => {
    setPreviewArticle(null);
    setEditingArticle(null);
  };

  const handleSave = (status?: 'draft' | 'scheduled' | 'published') => {
    if (!editingArticle) return;
    setIsSaving(true);
    
    setTimeout(() => {
        const finalArticle = { ...editingArticle };
        if (status) finalArticle.status = status;
        onArticlePublish(finalArticle);
        setIsSaving(false);
        if (status === 'published') {
            closePreview();
            if (activeTab === AdminTab.DOSSIERS) {
                setActiveTab(AdminTab.RESEAU);
            }
        }
    }, 800);
  };

  const handleBackNavigation = () => {
    const handledByChild = activeTabRef.current?.handleBack?.();
    if (!handledByChild) {
      setActiveTab(AdminTab.RESEAU);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case AdminTab.RESEAU:
        return <AdminDashboard articles={articles} />;
      case AdminTab.DOSSIERS:
        return (
          <AdminStudio 
            ref={activeTabRef}
            articles={articles} 
            onPublish={(a) => { onArticlePublish(a); setActiveTab(AdminTab.RESEAU); }} 
            onPreview={handlePreview}
          />
        );
      case AdminTab.UTILISATEURS:
        return (
          <AdminUsers 
            ref={activeTabRef}
            onSendNotification={onSendSystemMessage} 
          />
        );
      case AdminTab.AUDIT:
        return (
            <AdminAudit 
                ref={activeTabRef}
                onSendNotification={onSendSystemMessage} 
                onEditArticle={handleEditFromAudit} 
            />
        );
      case AdminTab.ANTENNE:
        return (
            <AdminAntenne 
                ref={activeTabRef}
                articles={articles}
            />
        );
      case AdminTab.LOCALISATION:
        return (
            <AdminLocalisation ref={activeTabRef} />
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center h-full text-zinc-600 bg-zinc-950">
             <Database className="w-12 h-12 mb-4" />
             <p className="text-xs font-mono uppercase">Module Offline</p>
          </div>
        );
    }
  };

  const navItems = [
    { id: AdminTab.RESEAU, icon: BarChart3, label: t('ADMIN_TAB_NETWORK') },
    { id: AdminTab.DOSSIERS, icon: Layers, label: t('ADMIN_TAB_FILES') },
    { id: AdminTab.ANTENNE, icon: Radio, label: t('ADMIN_TAB_ANTENNA') },
    { id: AdminTab.UTILISATEURS, icon: Users, label: t('ADMIN_TAB_USERS') },
    { id: AdminTab.AUDIT, icon: ShieldAlert, label: t('ADMIN_TAB_AUDIT') },
    { id: AdminTab.LOCALISATION, icon: Globe, label: t('ADMIN_TAB_LANG') },
  ];

  return (
    <div className="h-screen w-full bg-zinc-950 text-white flex flex-col font-sans relative">
      
      {/* OVERLAY DE PRÉVISUALISATION */}
      {editingArticle && (
        <div className="fixed inset-0 z-[400] bg-black flex flex-col animate-in slide-in-from-bottom duration-300">
          <div className="h-16 bg-zinc-900 border-b border-white/10 flex items-center justify-between px-4 shrink-0 z-50">
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-500 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Studio Live
              </span>
              <span className="text-xs text-white/50 font-bold truncate max-w-[200px]">Édition Visuelle</span>
            </div>
            <button onClick={closePreview} className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 text-white rounded-full font-black uppercase text-[10px] tracking-widest hover:bg-white hover:text-black transition-all">
              <X className="w-4 h-4" /> {t('UI_CLOSE')}
            </button>
          </div>

          <div className="flex-1 w-full relative overflow-hidden bg-black">
             <ArticleCard 
               article={editingArticle} 
               isActive={true} 
               isPreloading={false}
               isEditable={true}
               onArticleUpdate={(updated) => setEditingArticle(updated)}
             />
          </div>

          <div className="shrink-0 bg-zinc-950 border-t border-white/10 p-4 pb-8 flex items-center justify-between gap-4 z-50">
             <div className="flex items-center gap-2 bg-black border border-white/10 p-1 rounded-xl">
                 <button onClick={() => handleSave('draft')} className={`p-3 rounded-lg flex flex-col items-center gap-1 min-w-[60px] ${editingArticle.status === 'draft' ? 'bg-white text-black' : 'text-zinc-500 hover:text-white'}`}>
                    <Save className="w-4 h-4" />
                    <span className="text-[8px] font-black uppercase">Brouillon</span>
                 </button>
                 <button onClick={() => handleSave('scheduled')} className={`p-3 rounded-lg flex flex-col items-center gap-1 min-w-[60px] ${editingArticle.status === 'scheduled' ? 'bg-amber-500 text-black' : 'text-zinc-500 hover:text-white'}`}>
                    <Clock className="w-4 h-4" />
                    <span className="text-[8px] font-black uppercase">Programmé</span>
                 </button>
             </div>
             <button onClick={() => handleSave()} className="flex-1 py-4 bg-zinc-800 text-white rounded-xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">
                {isSaving ? <span className="animate-pulse">Sauvegarde...</span> : <><Save className="w-4 h-4" /> {t('ACTION_SAVE')}</>}
             </button>
             <button onClick={() => handleSave('published')} className="flex-[1.5] py-4 bg-white text-black rounded-xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 hover:bg-emerald-400 transition-colors active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                <Send className="w-4 h-4" /> PUBLIER
             </button>
          </div>
        </div>
      )}

      {/* Admin Header */}
      <div className="h-14 bg-black border-b border-zinc-800 flex items-center justify-between px-4 shrink-0 z-50">
        <div className="flex items-center gap-3">
          {activeTab !== AdminTab.RESEAU ? (
            <button onClick={handleBackNavigation} className="p-1.5 -ml-2 hover:bg-zinc-800 rounded-lg transition-colors text-white">
              <ChevronLeft className="w-5 h-5" />
            </button>
          ) : (
            <div className="w-3 h-3 bg-emerald-500 rounded-sm" />
          )}
          <span className="text-xs font-bold font-mono tracking-widest text-zinc-400">
            {activeTab === AdminTab.RESEAU ? 'CAKENEWS STUDIO' : activeTab.toUpperCase()}
          </span>
        </div>
        <button onClick={onLogout} className="text-xs font-black bg-zinc-900 px-3 py-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors">
          {t('ADMIN_LOGOUT')}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative bg-zinc-950">
        {renderContent()}
      </div>

      {/* Admin Nav (OPTIMISÉ) */}
      <nav className="h-20 bg-black border-t border-zinc-800 flex shrink-0 z-50 relative overflow-x-auto hide-scrollbar pb-safe">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex-1 min-w-[70px] flex flex-col items-center justify-center gap-1.5 transition-all ${
                isActive ? 'bg-white text-black' : 'bg-black text-zinc-600 hover:bg-zinc-900'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-[9px] md:text-[10px] font-black uppercase tracking-wider leading-none">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default AdminView;
