
import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { ReportTicket, AuditLog } from '../../types';
import { MOCK_REPORTS } from '../../data/mockData';
import { 
  ShieldAlert, CheckCircle, ExternalLink, 
  Eye, User, MessageSquare, 
  Search, Lock, Send, AlertTriangle, Zap, Edit3, ArrowLeft, Archive, FileText, Users, Cpu
} from 'lucide-react';
import { AdminTabHandle } from './AdminView';

interface AdminAuditProps {
    onSendNotification?: (target: string, content: string) => void;
    onEditArticle?: (articleId: string) => void;
}

type AuditViewMode = 'truth' | 'ethics' | 'tech' | 'archives';

const AdminAudit = forwardRef<AdminTabHandle, AdminAuditProps>(({ onSendNotification, onEditArticle }, ref) => {
  const [reports, setReports] = useState<ReportTicket[]>(MOCK_REPORTS);
  const [selectedReport, setSelectedReport] = useState<ReportTicket | null>(null);
  
  // NOUVELLE LOGIQUE DE NAVIGATION : PAR MÉTIER
  const [viewMode, setViewMode] = useState<AuditViewMode>('truth');
  
  const [internalNote, setInternalNote] = useState('');

  // Hook pour exposer la méthode handleBack
  useImperativeHandle(ref, () => ({
    handleBack: () => {
      // Si un rapport est ouvert, on le ferme pour revenir à la liste
      if (selectedReport) {
        setSelectedReport(null);
        return true;
      }
      return false;
    }
  }));

  // HELPERS VISUELS
  const getPriorityColor = (reason: string) => {
    switch (reason) {
      case 'ethics': return 'text-red-500 bg-red-500/10 border-red-500/30';
      case 'truth': return 'text-amber-500 bg-amber-500/10 border-amber-500/30';
      case 'tech': return 'text-sky-500 bg-sky-500/10 border-sky-500/30';
      default: return 'text-zinc-500 bg-zinc-500/10';
    }
  };

  const getScoreColor = (score: number) => {
      if (score >= 80) return 'text-emerald-500';
      if (score >= 50) return 'text-amber-500';
      return 'text-red-500';
  };

  // ACTIONS WORKFLOW
  const handleAssign = (report: ReportTicket) => {
      // Simulation: L'admin courant prend le ticket
      const updated = { ...report, status: 'IN_PROGRESS' as const, assignedTo: 'Moi (Admin)' };
      setReports(prev => prev.map(r => r.id === report.id ? updated : r));
      setSelectedReport(updated);
  };

  const handleAddNote = () => {
      if (!selectedReport || !internalNote.trim()) return;
      const newNote: AuditLog = {
          id: Date.now().toString(),
          adminName: 'Moi',
          action: internalNote,
          timestamp: new Date().toLocaleTimeString()
      };
      
      const updated = { 
          ...selectedReport, 
          internalNotes: [...(selectedReport.internalNotes || []), newNote] 
      };
      
      setReports(prev => prev.map(r => r.id === selectedReport.id ? updated : r));
      setSelectedReport(updated);
      setInternalNote('');
  };

  const handleVerdict = (verdict: 'VALID' | 'INVALID' | 'WARN', customMsg?: string) => {
      if (!selectedReport) return;

      let notifMsg = "";
      let newStatus: 'RESOLVED' | 'DISMISSED' = 'RESOLVED';

      switch (verdict) {
          case 'VALID':
              notifMsg = customMsg || `Verdict : Votre signalement "${selectedReport.targetTitle}" a été validé. Le contenu a été supprimé. Merci pour votre vigilance.`;
              newStatus = 'RESOLVED';
              break;
          case 'INVALID':
              notifMsg = customMsg || `Verdict : Après analyse, le contenu "${selectedReport.targetTitle}" respecte nos standards. Signalement classé.`;
              newStatus = 'DISMISSED';
              break;
          case 'WARN':
              notifMsg = customMsg || `Verdict : Contenu maintenu mais sous surveillance grâce à vous.`;
              newStatus = 'RESOLVED';
              break;
      }

      // Envoi Notification
      onSendNotification?.(selectedReport.reporter, notifMsg);

      // Mise à jour Ticket
      const updated = { ...selectedReport, status: newStatus };
      setReports(prev => prev.map(r => r.id === selectedReport.id ? updated : r));
      setSelectedReport(null); // Retour liste
  };

  // FILTRAGE STRICT PAR DOMAINE
  const filteredReports = reports.filter(r => {
      if (viewMode === 'archives') {
          return r.status === 'RESOLVED' || r.status === 'DISMISSED';
      }
      // Pour les onglets métiers, on ne montre que ce qui est Actif (Open ou In Progress)
      // et qui correspond à la catégorie
      return r.reason === viewMode && (r.status === 'OPEN' || r.status === 'IN_PROGRESS');
  });

  const getCount = (mode: AuditViewMode) => {
      if (mode === 'archives') return reports.filter(r => r.status === 'RESOLVED' || r.status === 'DISMISSED').length;
      return reports.filter(r => r.reason === mode && (r.status === 'OPEN' || r.status === 'IN_PROGRESS')).length;
  };

  return (
    <div className="h-full flex bg-zinc-950 font-sans relative overflow-hidden">
      
      {/* 1. LISTE & NAVIGATION (Left Panel) */}
      <div className={`w-full md:w-96 border-r border-zinc-800 bg-zinc-925 flex-col shrink-0 ${selectedReport ? 'hidden md:flex' : 'flex'}`}>
         
         {/* HEADER TITLE */}
         <div className="p-4 border-b border-zinc-800 bg-zinc-950 flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-white" />
            <h2 className="text-sm font-black uppercase text-white tracking-widest">Audit Center</h2>
         </div>

         {/* NAVIGATION PRINCIPALE : LES BUREAUX */}
         <div className="grid grid-cols-4 bg-zinc-950 border-b border-zinc-800">
             <button 
                onClick={() => setViewMode('truth')}
                className={`flex flex-col items-center justify-center gap-1.5 py-4 border-b-2 transition-colors ${viewMode === 'truth' ? 'border-amber-500 bg-amber-500/5' : 'border-transparent text-zinc-600 hover:bg-zinc-900'}`}
             >
                 <FileText className={`w-4 h-4 ${viewMode === 'truth' ? 'text-amber-500' : 'text-zinc-500'}`} />
                 <span className={`text-[9px] font-black uppercase tracking-wider ${viewMode === 'truth' ? 'text-white' : 'text-zinc-500'}`}>Médias</span>
                 {getCount('truth') > 0 && <span className="bg-amber-500 text-black text-[9px] font-bold px-1.5 rounded-full">{getCount('truth')}</span>}
             </button>

             <button 
                onClick={() => setViewMode('ethics')}
                className={`flex flex-col items-center justify-center gap-1.5 py-4 border-b-2 transition-colors ${viewMode === 'ethics' ? 'border-red-500 bg-red-500/5' : 'border-transparent text-zinc-600 hover:bg-zinc-900'}`}
             >
                 <Users className={`w-4 h-4 ${viewMode === 'ethics' ? 'text-red-500' : 'text-zinc-500'}`} />
                 <span className={`text-[9px] font-black uppercase tracking-wider ${viewMode === 'ethics' ? 'text-white' : 'text-zinc-500'}`}>Social</span>
                 {getCount('ethics') > 0 && <span className="bg-red-500 text-white text-[9px] font-bold px-1.5 rounded-full">{getCount('ethics')}</span>}
             </button>

             <button 
                onClick={() => setViewMode('tech')}
                className={`flex flex-col items-center justify-center gap-1.5 py-4 border-b-2 transition-colors ${viewMode === 'tech' ? 'border-sky-500 bg-sky-500/5' : 'border-transparent text-zinc-600 hover:bg-zinc-900'}`}
             >
                 <Cpu className={`w-4 h-4 ${viewMode === 'tech' ? 'text-sky-500' : 'text-zinc-500'}`} />
                 <span className={`text-[9px] font-black uppercase tracking-wider ${viewMode === 'tech' ? 'text-white' : 'text-zinc-500'}`}>Tech</span>
                 {getCount('tech') > 0 && <span className="bg-sky-500 text-black text-[9px] font-bold px-1.5 rounded-full">{getCount('tech')}</span>}
             </button>

             <button 
                onClick={() => setViewMode('archives')}
                className={`flex flex-col items-center justify-center gap-1.5 py-4 border-b-2 transition-colors ${viewMode === 'archives' ? 'border-white/50 bg-white/5' : 'border-transparent text-zinc-600 hover:bg-zinc-900'}`}
             >
                 <Archive className={`w-4 h-4 ${viewMode === 'archives' ? 'text-white' : 'text-zinc-500'}`} />
                 <span className={`text-[9px] font-black uppercase tracking-wider ${viewMode === 'archives' ? 'text-white' : 'text-zinc-500'}`}>Archive</span>
             </button>
         </div>

         {/* SUB-HEADER CONTEXTUEL */}
         <div className="p-3 bg-zinc-900 border-b border-zinc-800 flex justify-between items-center">
             <div className="flex items-center gap-2">
                 <div className={`w-1.5 h-1.5 rounded-full ${viewMode === 'truth' ? 'bg-amber-500' : viewMode === 'ethics' ? 'bg-red-500' : viewMode === 'tech' ? 'bg-sky-500' : 'bg-white'}`}></div>
                 <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                    {viewMode === 'truth' && 'File Éditoriale'}
                    {viewMode === 'ethics' && 'Modération Communauté'}
                    {viewMode === 'tech' && 'Bugs & Support'}
                    {viewMode === 'archives' && 'Historique Global'}
                 </span>
             </div>
             <Search className="w-3 h-3 text-zinc-600" />
         </div>

         {/* LISTE DES TICKETS */}
         <div className="flex-1 overflow-y-auto">
            {filteredReports.map(report => (
                <div 
                  key={report.id}
                  onClick={() => setSelectedReport(report)}
                  className={`p-4 border-b border-zinc-800 cursor-pointer hover:bg-zinc-800 transition-colors group relative ${selectedReport?.id === report.id ? 'bg-zinc-800' : ''}`}
                >
                    {selectedReport?.id === report.id && <div className="absolute left-0 top-0 bottom-0 w-1 bg-white"></div>}
                    
                    <div className="flex justify-between items-start mb-2">
                        {/* On affiche le statut ici car la catégorie est déjà filtrée par l'onglet */}
                        <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded border ${
                            report.status === 'OPEN' ? 'bg-white text-black border-white' : 
                            report.status === 'IN_PROGRESS' ? 'bg-transparent text-white border-white/30' : 
                            'bg-transparent text-zinc-500 border-zinc-700'
                        }`}>
                            {report.status === 'OPEN' ? 'À FAIRE' : 
                             report.status === 'IN_PROGRESS' ? 'EN COURS' : 'CLOS'}
                        </span>
                        <span className="text-[9px] font-mono text-zinc-600">{report.timestamp}</span>
                    </div>
                    
                    <h3 className="text-sm font-bold text-white mb-1 truncate leading-tight group-hover:text-white transition-colors">
                        {report.targetTitle || 'Contenu signalé'}
                    </h3>
                    
                    <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full ${getScoreColor(report.reporterScore)} bg-current`}></div>
                            <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wide">{report.reporter}</span>
                        </div>
                        {report.assignedTo && (
                            <div className="flex items-center gap-1 text-[8px] text-amber-500 font-mono bg-amber-500/10 px-1.5 py-0.5 rounded">
                                <Lock className="w-2 h-2" /> {report.assignedTo.split(' ')[0]}
                            </div>
                        )}
                    </div>
                </div>
            ))}
            
            {filteredReports.length === 0 && (
                <div className="flex flex-col items-center justify-center py-20 opacity-30">
                    <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mb-4">
                        <CheckCircle className="w-8 h-8 text-zinc-500" />
                    </div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-center px-6">
                        Tout est propre.<br/>Aucun ticket dans le bureau {viewMode}.
                    </p>
                </div>
            )}
         </div>
      </div>

      {/* 2. WORKSPACE / COCKPIT (Right Panel) */}
      <div className={`flex-1 bg-black flex flex-col min-w-0 ${!selectedReport ? 'hidden md:flex' : 'fixed inset-0 z-30 md:static'}`}>
         {selectedReport ? (
             <>
                {/* COCKPIT HEADER */}
                <div className="h-16 border-b border-zinc-800 flex items-center justify-between px-4 md:px-6 bg-zinc-950 shrink-0">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setSelectedReport(null)} className="md:hidden p-2 -ml-2 text-zinc-400 hover:text-white">
                            <ArrowLeft className="w-5 h-5" />
                        </button>
                        <div>
                            <h1 className="text-lg font-black text-white uppercase tracking-tight flex items-center gap-2">
                                #{selectedReport.id.split('-')[1]} 
                                <span className={`text-[10px] px-2 py-0.5 rounded border ${getPriorityColor(selectedReport.reason)} hidden md:inline`}>
                                    {selectedReport.reason.toUpperCase()}
                                </span>
                            </h1>
                        </div>
                    </div>
                    
                    {selectedReport.status === 'OPEN' ? (
                        <button 
                            onClick={() => handleAssign(selectedReport)}
                            className="bg-white text-black px-4 py-2 rounded-lg font-black text-[10px] md:text-xs uppercase tracking-widest hover:bg-zinc-200 transition-colors flex items-center gap-2"
                        >
                            <Lock className="w-3 h-3" /> <span className="hidden md:inline">Prendre le dossier</span><span className="md:hidden">Prendre</span>
                        </button>
                    ) : (
                        <div className="flex items-center gap-2 px-3 py-1 bg-zinc-900 rounded border border-zinc-800">
                            <div className={`w-2 h-2 rounded-full animate-pulse ${selectedReport.status === 'IN_PROGRESS' ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
                            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest truncate max-w-[100px] md:max-w-none">
                                {selectedReport.status === 'RESOLVED' ? 'CLÔTURÉ' : selectedReport.assignedTo}
                            </span>
                        </div>
                    )}
                </div>

                {/* SPLIT CONTENT (Mobile: Stacked, Desktop: Row) */}
                <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
                    
                    {/* GAUCHE: LE SIGNALEMENT */}
                    <div className="w-full md:w-1/2 border-r border-zinc-800 p-6 overflow-y-auto bg-zinc-950 order-2 md:order-1 pb-32 md:pb-6">
                        <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-6 flex items-center gap-2">
                            <AlertTriangle className="w-3 h-3" /> Accusation
                        </h3>
                        
                        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 mb-6">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Motif</span>
                                <div className="flex items-center gap-2">
                                    <User className="w-3 h-3 text-zinc-600" />
                                    <span className="text-[9px] font-bold text-zinc-400">{selectedReport.reporter}</span>
                                    <span className={`text-[9px] px-1 rounded ${getScoreColor(selectedReport.reporterScore)} bg-white/5`}>
                                        {selectedReport.reporterScore}%
                                    </span>
                                </div>
                            </div>
                            <p className="text-white font-medium text-sm leading-relaxed">"{selectedReport.description}"</p>
                        </div>

                        {selectedReport.evidenceLinks && selectedReport.evidenceLinks.length > 0 && (
                            <div className="mb-6">
                                <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest mb-2 block">Preuves</span>
                                <div className="space-y-2">
                                    {selectedReport.evidenceLinks.map((link, i) => (
                                        <a key={i} href={link} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sky-500 hover:text-sky-400 text-xs font-mono truncate p-2 bg-zinc-900 rounded border border-zinc-800">
                                            <ExternalLink className="w-3 h-3 shrink-0" /> {link}
                                        </a>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div className="mt-8 pt-8 border-t border-zinc-800">
                            <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] mb-4 flex items-center gap-2">
                                <MessageSquare className="w-3 h-3" /> Notes d'équipe
                            </h3>
                            <div className="space-y-3 mb-4">
                                {selectedReport.internalNotes?.map(note => (
                                    <div key={note.id} className="bg-zinc-900 p-3 rounded-lg border border-zinc-800">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-[9px] font-bold text-zinc-400 uppercase">{note.adminName}</span>
                                            <span className="text-[8px] font-mono text-zinc-600">{note.timestamp}</span>
                                        </div>
                                        <p className="text-xs text-white">{note.action}</p>
                                    </div>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={internalNote}
                                    onChange={(e) => setInternalNote(e.target.value)}
                                    placeholder="Note interne..."
                                    className="flex-1 bg-black border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white focus:border-zinc-600 outline-none"
                                    onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                                />
                                <button onClick={handleAddNote} className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-white">
                                    <Send className="w-3 h-3" />
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* DROITE: LE CONTENU & VERDICT */}
                    <div className="w-full md:w-1/2 flex flex-col bg-black order-1 md:order-2 border-b md:border-b-0 border-zinc-800 h-[60vh] md:h-auto">
                        <div className="flex-1 p-6 overflow-y-auto">
                            <div className="flex items-center justify-between mb-6">
                                <h3 className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.2em] flex items-center gap-2">
                                    <Eye className="w-3 h-3" /> Contenu Incriminé
                                </h3>
                                
                                {/* BOUTON EDITER ARTICLE (HOTFIX) */}
                                {selectedReport.targetType === 'ARTICLE' && selectedReport.status !== 'DISMISSED' && (
                                    <button 
                                        onClick={() => onEditArticle?.(selectedReport.targetId)}
                                        className="bg-[#ffcc00] text-black px-4 py-2 rounded-lg font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:scale-105 transition-transform shadow-[0_0_15px_rgba(255,204,0,0.3)] animate-pulse"
                                    >
                                        <Edit3 className="w-3 h-3" /> HOTFIX (Corriger)
                                    </button>
                                )}
                            </div>
                            
                            {/* PREVIEW CARD */}
                            <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mb-8">
                                <div className="h-32 bg-zinc-800 flex items-center justify-center relative">
                                    <span className="text-zinc-600 text-xs font-black uppercase">Média / Image</span>
                                </div>
                                <div className="p-5">
                                    <h4 className="text-white font-bold mb-2">{selectedReport.targetTitle}</h4>
                                    <p className="text-zinc-400 text-xs leading-relaxed">{selectedReport.targetContentPreview}</p>
                                </div>
                            </div>

                            {/* VERDICT SECTION */}
                            {selectedReport.status !== 'RESOLVED' && selectedReport.status !== 'DISMISSED' && (
                                <div className="animate-in slide-in-from-bottom-4 duration-500">
                                    <h3 className="text-[10px] font-black uppercase text-white tracking-[0.2em] mb-4 flex items-center gap-2">
                                        <Zap className="w-3 h-3 text-yellow-500" /> Verdict Rapide
                                    </h3>
                                    
                                    <div className="grid grid-cols-2 gap-3 mb-6">
                                        <button 
                                            onClick={() => handleVerdict('VALID')}
                                            className="p-4 bg-red-900/20 border border-red-500/30 hover:bg-red-900/40 rounded-xl text-left transition-all group active:scale-95"
                                        >
                                            <span className="text-red-500 font-black uppercase text-xs tracking-widest block mb-1">Sanctionner</span>
                                            <span className="text-red-300/60 text-[10px]">Le signalement est valide. Supprimer le contenu.</span>
                                        </button>
                                        <button 
                                            onClick={() => handleVerdict('INVALID')}
                                            className="p-4 bg-zinc-900 border border-zinc-700 hover:border-zinc-500 rounded-xl text-left transition-all group active:scale-95"
                                        >
                                            <span className="text-white font-black uppercase text-xs tracking-widest block mb-1">Rejeter</span>
                                            <span className="text-zinc-500 text-[10px]">Faux positif. Le contenu reste en ligne.</span>
                                        </button>
                                    </div>

                                    <div>
                                        <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest mb-2 block">Réponses pré-enregistrées</span>
                                        <div className="flex flex-wrap gap-2">
                                            <button 
                                                onClick={() => handleVerdict('VALID', 'Merci. Votre vigilance aide à garder CakeNews propre. Contenu supprimé.')}
                                                className="px-3 py-2 rounded-lg border border-zinc-800 text-[10px] text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors bg-zinc-950"
                                            >
                                                "Merci, contenu supprimé"
                                            </button>
                                            <button 
                                                onClick={() => handleVerdict('INVALID', 'Après analyse humaine, ce contenu ne viole pas nos règles. Merci quand même.')}
                                                className="px-3 py-2 rounded-lg border border-zinc-800 text-[10px] text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors bg-zinc-950"
                                            >
                                                "Conforme aux règles"
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}
                            
                            {(selectedReport.status === 'RESOLVED' || selectedReport.status === 'DISMISSED') && (
                                <div className="p-6 bg-zinc-900 rounded-xl border border-zinc-800 text-center">
                                    <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-3" />
                                    <p className="text-xs font-bold text-white uppercase tracking-widest">Dossier Clôturé</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
             </>
         ) : (
             <div className="flex-1 flex flex-col items-center justify-center text-zinc-700 bg-zinc-950">
                 <div className="w-20 h-20 rounded-full bg-zinc-900 flex items-center justify-center mb-6">
                    <ShieldAlert className="w-8 h-8 opacity-20" />
                 </div>
                 <p className="text-sm font-mono uppercase tracking-widest text-center px-4">
                     Sélectionnez un ticket pour l'audit<br/>
                     <span className="text-[10px] opacity-50 block mt-2">Utilisez les onglets pour filtrer la file</span>
                 </p>
             </div>
         )}
      </div>
    </div>
  );
});

export default AdminAudit;
