
import React, { useState } from 'react';
import { Article } from '../../types';
import { Eye, Activity, List, Server, TrendingUp, Smile, Frown, AlertCircle, Zap } from 'lucide-react';
import { useTranslation } from '../../context/TranslationContext'; // IMPORT

type DashboardSubTab = 'SYNTHESE' | 'LIVE' | 'SYSTEME';

const AdminDashboard: React.FC<{ articles: Article[] }> = ({ articles }) => {
  const { t } = useTranslation(); // HOOK
  const [activeSubTab, setActiveSubTab] = useState<DashboardSubTab>('SYNTHESE');

  // Stats calculées
  const totalViews = articles.reduce((acc, _) => acc + Math.floor(Math.random() * 5000), 12000);
  const totalComments = articles.reduce((acc, curr) => acc + curr.comments, 0);

  const SubTabButton = ({ id, label, icon: Icon }: { id: DashboardSubTab; label: string; icon: any }) => (
    <button
      onClick={() => setActiveSubTab(id)}
      className={`flex-1 py-3 flex items-center justify-center gap-2 border-b-2 text-[10px] font-black uppercase tracking-widest transition-colors ${
        activeSubTab === id
          ? 'border-white text-white'
          : 'border-transparent text-zinc-600 hover:text-zinc-400'
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );

  return (
    <div className="h-full flex flex-col bg-zinc-950 font-sans">
      {/* SUB-NAVIGATION */}
      <div className="flex bg-black border-b border-zinc-800 shrink-0">
        <SubTabButton id="SYNTHESE" label="Synthèse" icon={TrendingUp} />
        <SubTabButton id="LIVE" label="Flux Live" icon={List} />
        <SubTabButton id="SYSTEME" label="Système" icon={Server} />
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        
        {/* VUE SYNTHÈSE */}
        {activeSubTab === 'SYNTHESE' && (
          <div className="space-y-4 animate-in fade-in slide-in-from-left-4 duration-300">
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-zinc-900 p-6 border border-zinc-800">
                <span className="text-[10px] font-mono text-zinc-500 uppercase block mb-2">{t('DASH_AUDIENCE')}</span>
                <p className="text-3xl font-bold text-white font-mono">{(totalViews / 1000).toFixed(1)}k</p>
              </div>
              <div className="bg-zinc-900 p-6 border border-zinc-800">
                <span className="text-[10px] font-mono text-zinc-500 uppercase block mb-2">{t('DASH_INTERACTIONS')}</span>
                <p className="text-3xl font-bold text-white font-mono">{totalComments}</p>
              </div>
            </div>

            {/* VIBE CHECK ANALYTICS (NOUVEAU) */}
            <div className="bg-zinc-900 border border-zinc-800 p-4">
               <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4 flex items-center gap-2">
                   <Zap className="w-3 h-3 text-yellow-500" /> {t('DASH_VIBE_CHECK')}
               </h3>
               <div className="grid grid-cols-4 gap-2 mb-4">
                   <div className="bg-black p-3 text-center border border-zinc-800 rounded-lg">
                       <span className="text-2xl block mb-1">🤯</span>
                       <span className="text-xs font-bold text-white block">24%</span>
                       <span className="text-[8px] text-zinc-500 uppercase">{t('VIBE_SHOCKED')}</span>
                   </div>
                   <div className="bg-black p-3 text-center border border-zinc-800 rounded-lg">
                       <span className="text-2xl block mb-1">🤨</span>
                       <span className="text-xs font-bold text-white block">15%</span>
                       <span className="text-[8px] text-zinc-500 uppercase">{t('VIBE_SKEPTICAL')}</span>
                   </div>
                   <div className="bg-black p-3 text-center border border-zinc-800 rounded-lg">
                       <span className="text-2xl block mb-1">🚀</span>
                       <span className="text-xs font-bold text-white block">51%</span>
                       <span className="text-[8px] text-zinc-500 uppercase">{t('VIBE_BULLISH')}</span>
                   </div>
                   <div className="bg-black p-3 text-center border border-zinc-800 rounded-lg">
                       <span className="text-2xl block mb-1">✅</span>
                       <span className="text-xs font-bold text-white block">10%</span>
                       <span className="text-[8px] text-zinc-500 uppercase">{t('VIBE_VALIDATED')}</span>
                   </div>
               </div>
               <p className="text-[10px] text-zinc-600 text-center">
                   * Données basées sur les votes "Vibe Check" des 12 dernières heures.
               </p>
            </div>
            
            <div className="bg-zinc-900 border border-zinc-800 p-4">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-4">{t('DASH_PERF_TITLE')}</h3>
              <div className="space-y-4">
                 <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-white">{t('DASH_READ_RATE')}</span>
                    <span className="text-xs font-mono text-emerald-500">84%</span>
                 </div>
                 <div className="w-full h-1 bg-zinc-800">
                    <div className="h-full bg-emerald-500 w-[84%]"></div>
                 </div>

                 <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-white">{t('DASH_VIRALITY')}</span>
                    <span className="text-xs font-mono text-amber-500">Élevée</span>
                 </div>
                 <div className="w-full h-1 bg-zinc-800">
                    <div className="h-full bg-amber-500 w-[65%]"></div>
                 </div>
              </div>
            </div>
          </div>
        )}

        {/* VUE FLUX LIVE */}
        {activeSubTab === 'LIVE' && (
          <div className="animate-in fade-in slide-in-from-right-4 duration-300">
            <h3 className="text-xs font-black uppercase tracking-widest text-zinc-500 mb-4 px-1">Derniers Dossiers Publiés</h3>
            <div className="flex flex-col gap-1">
              {articles.map(article => (
                <div key={article.id} className="flex items-center gap-3 p-4 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 cursor-pointer transition-colors">
                  <div className={`w-1 h-10 ${article.isExclusive ? 'bg-red-600' : 'bg-zinc-700'}`}></div>
                  <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-[9px] font-mono text-zinc-500 uppercase bg-black px-1.5 py-0.5">{article.category}</span>
                        <span className="text-[9px] font-mono text-zinc-600">{article.timestamp}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white truncate">{article.title}</h4>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-[10px] text-zinc-500 font-mono flex items-center gap-1">
                          <Eye className="w-3 h-3" /> {article.likes}
                        </span>
                      </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VUE SYSTÈME */}
        {activeSubTab === 'SYSTEME' && (
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="bg-zinc-900 border border-zinc-800 p-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-6 flex items-center gap-2">
                <Activity className="w-3 h-3" /> {t('DASH_INFRA')}
              </h3>
              <div className="space-y-0 divide-y divide-zinc-800 font-mono text-xs">
                <div className="flex justify-between items-center py-4">
                  <span className="text-zinc-500">API_GATEWAY_V1</span>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span className="text-white font-bold">{t('DASH_OPERATIONAL')}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center py-4">
                  <span className="text-zinc-500">DATABASE_PRIMARY</span>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-white font-bold">{t('DASH_OPERATIONAL')}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center py-4">
                  <span className="text-zinc-500">CONTENT_DELIVERY (CDN)</span>
                  <span className="text-white font-bold">98ms</span>
                </div>
                <div className="flex justify-between items-center py-4">
                  <span className="text-zinc-500">TAUX DE CACHE</span>
                  <span className="text-amber-500 font-bold">94.2%</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default AdminDashboard;
