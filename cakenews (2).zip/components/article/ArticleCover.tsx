
import React, { useState, useMemo, useCallback } from 'react';
import { ImageSkeleton } from '../ui/Loader';
import { ImageOff, Heart, Play } from 'lucide-react';
import { useInteraction } from '../../context/InteractionContext';

interface ArticleCoverProps {
  imageUrl: string;
  videoUrl?: string;
  title: string;
  articleId: string;
}

const ArticleCover: React.FC<ArticleCoverProps> = ({
  imageUrl,
  videoUrl,
  title,
  articleId
}) => {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const { toggleLike, isLiked, triggerHaptic } = useInteraction();

  // Gestion du Double Tap
  const [lastTap, setLastTap] = useState(0);

  const handleTap = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;

    if (now - lastTap < DOUBLE_TAP_DELAY) {
      // C'est un double tap !
      e.stopPropagation();
      
      if (!isLiked(articleId)) {
        toggleLike(articleId);
      } else {
        triggerHaptic('medium'); // Juste un feedback si déjà liké
      }

      // Animation du coeur
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 800);
    }
    
    setLastTap(now);
  }, [lastTap, articleId, isLiked, toggleLike, triggerHaptic]);

  const optimizedUrl = useMemo(() => {
    if (!imageUrl || !imageUrl.includes('unsplash.com')) return imageUrl;
    try {
      const url = new URL(imageUrl);
      url.searchParams.delete('w');
      url.searchParams.delete('q');
      url.searchParams.delete('fm');
      // Optimisation HD 1080x1080 pour le format carré
      url.searchParams.set('w', '1080'); 
      url.searchParams.set('h', '1080');
      url.searchParams.set('q', '80');
      url.searchParams.set('fm', 'webp');
      url.searchParams.set('fit', 'crop');
      return url.toString();
    } catch (e) {
      return imageUrl;
    }
  }, [imageUrl]);

  if (error && !videoUrl) {
    return (
      <div 
        className="relative w-full aspect-square flex-shrink-0 bg-zinc-900 overflow-hidden flex flex-col items-center justify-center border-b border-white/5"
        style={{ contain: 'strict' }}
      >
         <ImageOff className="w-12 h-12 text-white/10 mb-4" />
         <span className="text-white/20 font-black uppercase tracking-widest text-[10px]">Média Non Disponible</span>
      </div>
    );
  }

  return (
    <div 
      className="relative w-full aspect-square flex-shrink-0 bg-black overflow-hidden select-none"
      style={{ contain: 'strict' }}
      onClick={handleTap}
    >
      {!loaded && <ImageSkeleton />}
      
      {videoUrl ? (
        <video
          src={videoUrl}
          // "object-cover" force le rognage pour remplir le carré sans déformation
          // "object-center" assure que le rognage se fait par rapport au centre de la vidéo
          className={`w-full h-full object-cover object-center transition-opacity duration-500 ${loaded ? 'opacity-100' : 'opacity-0'}`}
          autoPlay
          loop
          muted
          playsInline
          poster={optimizedUrl}
          onLoadedData={() => setLoaded(true)}
          onError={() => {
             // Fallback to image if video fails but we have an image
             if (optimizedUrl) setError(true);
          }}
        />
      ) : (
        <img 
            src={optimizedUrl} 
            alt={title} 
            onLoad={() => setLoaded(true)}
            onError={() => {
            setError(true);
            setLoaded(true);
            }}
            className={`w-full h-full object-cover object-center transition-opacity duration-500 ${loaded ? 'opacity-100' : 'opacity-0'}`}
            loading="lazy" 
            decoding="async" 
        />
      )}

      {/* Animation Coeur Double Tap */}
      {showHeart && (
        <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
           <Heart className="w-32 h-32 text-white fill-white animate-in zoom-in-50 fade-out duration-700 drop-shadow-2xl" />
        </div>
      )}
    </div>
  );
};

export default React.memo(ArticleCover);
