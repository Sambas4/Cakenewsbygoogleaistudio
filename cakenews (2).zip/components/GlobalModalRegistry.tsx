import React, { lazy, Suspense } from 'react';
import { useModal } from '../context/ModalContext';
import { ModuleLoader } from './ui/Loader';

const ReportPopup = lazy(() => import('./ReportPopup'));
const EchoViewer = lazy(() => import('./modules/echoes/EchoViewer'));
const TrophyModal = lazy(() => import('./trophy/TrophyModal'));
const HallOfFame = lazy(() => import('./trophy/HallOfFame'));
const ShareModal = lazy(() => import('./share/ShareModal'));

const GlobalModalRegistry: React.FC = () => {
  const { modal, closeModal } = useModal();

  if (!modal.type) return null;

  return (
    // Z-INDEX 1000 : Priorité absolue sur l'interface (BottomNav est z-300)
    <div className="fixed inset-0 z-[1000]">
      <Suspense fallback={
        <div className="fixed inset-0 bg-black flex items-center justify-center">
          <ModuleLoader />
        </div>
      }>
        {modal.type === 'REPORT' && (
          <ReportPopup 
            articleTitle={modal.props?.articleTitle} 
            onClose={closeModal} 
            onReportSubmitted={modal.props?.onReportSubmitted} 
          />
        )}
        {modal.type === 'ECHO_VIEWER' && (
          <EchoViewer 
            voice={modal.props?.voice} 
            accentColor={modal.props?.accentColor} 
            onClose={closeModal} 
          />
        )}
        {modal.type === 'TROPHY_VIEWER' && (
          <TrophyModal 
            data={modal.props?.data}
            onClose={closeModal}
          />
        )}
        {modal.type === 'HALL_OF_FAME' && (
          <HallOfFame 
            initialSearchId={modal.props?.initialSearchId}
            onClose={closeModal}
          />
        )}
        {modal.type === 'SHARE' && (
          <ShareModal 
            article={modal.props?.article}
            onClose={closeModal}
          />
        )}
      </Suspense>
    </div>
  );
};

export default GlobalModalRegistry;