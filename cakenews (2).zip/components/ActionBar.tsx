
import React, { useState, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Flag, Bookmark } from 'lucide-react';
import { useInteraction } from '../context/InteractionContext';
import { useTranslation } from '../context/TranslationContext';

interface ActionBarProps {
  onLike: () => void;
  onCommentClick: () => void;
  onReportClick: () => void;
  onSave: () => void;
  onShare: () => void;
  isLiked: boolean;
  isSaved: boolean;
  isCommentBlinking?: boolean;
  hasUnreadComments?: boolean;
  accentColor: string;
  likes: number;
  comments: number;
}

const ActionBar: React.FC<ActionBarProps> = ({ 
  onLike, 
  onCommentClick, 
  onReportClick, 
  onSave,
  onShare,
  isLiked, 
  isSaved,
  isCommentBlinking = false,
  hasUnreadComments = false,
  accentColor,
  likes, 
  comments
}) => {
  const [isLit, setIsLit] = useState(false);
  const { triggerHaptic } = useInteraction();
  const { t } = useTranslation();
  
  // Le point clignote si on a une demande explicite (blink) ou des non-lus
  const showDot = isCommentBlinking || hasUnreadComments;

  useEffect(() => {
    let timer: number;
    if (isLit) {
      timer = window.setTimeout(() => setIsLit(false), 500);
    }
    return () => clearTimeout(timer);
  }, [isLit]);

  const handleAction = (action: () => void, intensity: 'light' | 'medium' = 'light') => {
    triggerHaptic(intensity);
    action();
  };

  const buttonClass = `
    flex flex-col items-center justify-center gap-1.5 flex-1
    active:scale-90 opacity-100 transition-all duration-100
  `;

  return (
    <div className="w-full bg-black border-t border-white/10 px-2 py-3 flex justify-around items-center z-40 relative h-[80px] overflow-hidden select-none touch-none">
      
      {/* BOUTON LIKE */}
      <button onClick={onLike} className={buttonClass}>
        <div className="relative">
          {/* CORRECTION: Icône statique, pas d'animation sur l'icône */}
          <Heart className={`w-5 h-5 ${isLiked ? 'text-[#ff0000] fill-current scale-110' : 'text-white/40'}`} />
        </div>
        <span className="text-[9px] font-black uppercase tracking-widest text-white/40">{likes}</span>
      </button>
      
      {/* BOUTON COMMENTAIRES */}
      <button onClick={() => handleAction(onCommentClick, 'medium')} className={buttonClass}>
        <div className="relative">
          {/* CORRECTION: Icône statique. Seul le point clignote. */}
          <MessageCircle className="w-5 h-5 text-white/40 hover:text-white transition-colors" />
          
          {showDot && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-black animate-flash"></span>
          )}
        </div>
        <span className="text-[9px] font-black uppercase tracking-widest text-white/40">{comments}</span>
      </button>

      {/* BOUTON SAVE */}
      <button onClick={onSave} className={buttonClass}>
        <div className="relative">
           {isSaved ? (
             <Bookmark className="w-5 h-5 text-[#ffd700] fill-current scale-110" />
           ) : (
             <Bookmark className="w-5 h-5 text-white/20" />
           )}
        </div>
        <span className={`text-[9px] font-black uppercase tracking-widest ${isSaved ? 'text-[#ffd700]' : 'text-white/10'}`}>
            {isSaved ? t('ACTION_SAVED') : t('ACTION_SAVE')}
        </span>
      </button>

      {/* BOUTON SHARE */}
      <button onClick={onShare} className={buttonClass}>
        <Share2 className="w-5 h-5 text-white/20 hover:text-white transition-colors" />
        <span className="text-[9px] font-black uppercase tracking-widest text-white/10">{t('ACTION_SHARE')}</span>
      </button>

      {/* BOUTON REPORT */}
      <button onClick={() => handleAction(onReportClick, 'medium')} className={buttonClass}>
        <Flag className="w-5 h-5 text-white/20 hover:text-red-500 transition-colors" />
        <span className="text-[9px] font-black uppercase tracking-widest text-white/10">{t('ACTION_REPORT')}</span>
      </button>
    </div>
  );
};

export default ActionBar;
