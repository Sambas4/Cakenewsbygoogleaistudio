
import React, { useState, useEffect } from 'react';
import { CATEGORIES, CATEGORY_COLORS, getTextColor } from '../constants.tsx';
import { Category } from '../types';
import { Settings, LogOut, ChevronRight, PieChart, Trophy, QrCode, MapPin, Check, Edit2, Zap, Heart, MessageSquare } from 'lucide-react';
import { useModal } from '../context/ModalContext';
import { useInteraction } from '../context/InteractionContext';
import { useTranslation } from '../context/TranslationContext';
import { ProfileSkeleton } from './ui/Loader';

interface ProfileViewProps {
  preferences: Category[];
  togglePreference: (cat: Category) => void;
  onLogout: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ preferences, togglePreference, onLogout }) => {
  const { openModal } = useModal();
  const { savedIds, userLocation, updateUserLocation, userStats } = useInteraction();
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [isEditingLoc, setIsEditingLoc] = useState(!userLocation.isSet);
  
  // Local state form
  const [locForm, setLocForm] = useState({
      neighborhood: userLocation.neighborhood,
      city: userLocation.city,
      country: userLocation.country || 'Gabon' // Default
  });

  // Calcul du "Grade" basé sur les stats - MAINTENANT TRADUIT
  const getUserRank = () => {
      const score = userStats.likesGiven + (userStats.commentsPosted * 5);
      if (score > 1000) return { label: t('RANK_LEGEND'), color: '#ffcc00' };
      if (score > 500) return { label: t('RANK_INFLUENCER'), color: '#00f0ff' };
      if (score > 100) return { label: t('RANK_INSIDER'), color: '#22c55e' };
      return { label: t('RANK_OBSERVER'), color: '#52525b' };
  };

  const rank = getUserRank();

  // Simulation chargement initial
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const handleSaveLoc = () => {
      if(locForm.neighborhood && locForm.city && locForm.country) {
          updateUserLocation(locForm);
          setIsEditingLoc(false);
      }
  };

  if (isLoading) {
      return <ProfileSkeleton />;
  }

  return (
    <div className="flex flex-col h-full bg-black overflow-y-auto hide-scrollbar pb-32 animate-in fade-in duration-500">
      <div className="p-8">
        <div className="flex items-center justify-between mb-10">
          <h1 className="text-3xl font-[1000] uppercase tracking-normal">{t('PROF_TITLE')}</h1>
          <button className="p-3 border-2 border-white/10 bg-zinc-900"><Settings className="w-6 h-6" /></button>
        </div>

        {/* IDENTITY CARD - CORRECTION: PLUS DE DEGRADÉ, BG SOLID */}
        <div className="bg-zinc-900 border border-white/10 rounded-[40px] p-8 mb-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-5">
             <Trophy className="w-32 h-32" />
          </div>
          
          <div className="flex items-center gap-6 relative z-10 text-white mb-8">
            <div className="w-24 h-24 rounded-full border-4 border-black ring-2 ring-white/10">
               <img src="https://i.pravatar.cc/150?u=current" className="w-full h-full rounded-full object-cover" />
            </div>
            <div>
              <h2 className="text-2xl font-[1000] uppercase leading-none mb-2 tracking-tight">Alex Carter</h2>
              <span className="px-3 py-1 bg-white text-black text-[9px] font-black uppercase tracking-widest rounded-full" style={{ backgroundColor: rank.color }}>
                  {rank.label}
              </span>
            </div>
          </div>

          {/* STATS TRACKING GRID - CORRECTION: BG SOLID */}
          <div className="grid grid-cols-3 gap-2">
              <div className="bg-black p-4 rounded-2xl flex flex-col items-center border border-white/10">
                  <Heart className="w-4 h-4 mb-2 text-[#ff0000]" />
                  <span className="text-lg font-[1000]">{userStats.likesGiven}</span>
                  <span className="text-[8px] font-bold text-white/30 uppercase tracking-widest">{t('PROF_STATS_GIVEN')}</span>
              </div>
              <div className="bg-black p-4 rounded-2xl flex flex-col items-center border border-white/10">
                  <MessageSquare className="w-4 h-4 mb-2 text-sky-400" />
                  <span className="text-lg font-[1000]">{userStats.commentsPosted}</span>
                  <span className="text-[8px] font-bold text-white/30 uppercase tracking-widest">{t('PROF_STATS_POSTS')}</span>
              </div>
              <div className="bg-black p-4 rounded-2xl flex flex-col items-center border border-white/10">
                  <Zap className="w-4 h-4 mb-2 text-yellow-400" />
                  <span className="text-lg font-[1000]">{userStats.likesReceived}</span>
                  <span className="text-[8px] font-bold text-white/30 uppercase tracking-widest">{t('PROF_STATS_RECEIVED')}</span>
              </div>
          </div>
        </div>

        {/* SECTION MA ZONE */}
        <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                    <MapPin className="w-6 h-6 text-sky-500" />
                    <h3 className="text-xl font-[1000] uppercase tracking-normal">{t('PROF_MY_ZONE')}</h3>
                </div>
                {!isEditingLoc && (
                    <button onClick={() => setIsEditingLoc(true)} className="p-2 bg-white/10 rounded-full">
                        <Edit2 className="w-4 h-4 text-white/70" />
                    </button>
                )}
            </div>

            <div className={`p-6 rounded-[24px] border-2 transition-all duration-300 ${!userLocation.isSet || isEditingLoc ? 'bg-zinc-900 border-sky-500' : 'bg-zinc-900 border-white/10'}`}>
                {!userLocation.isSet || isEditingLoc ? (
                    <div className="space-y-4">
                        <p className="text-[10px] font-bold text-sky-400 uppercase tracking-widest mb-2">
                            {t('PROF_ZONE_DESC')}
                        </p>
                        <div className="space-y-3">
                            <input 
                                type="text" 
                                value={locForm.country} 
                                onChange={(e) => setLocForm({...locForm, country: e.target.value})}
                                placeholder="Pays (ex: Gabon)"
                                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-sky-500"
                            />
                            <input 
                                type="text" 
                                value={locForm.city} 
                                onChange={(e) => setLocForm({...locForm, city: e.target.value})}
                                placeholder="Ville (ex: Libreville)"
                                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-sky-500"
                            />
                            <input 
                                type="text" 
                                value={locForm.neighborhood} 
                                onChange={(e) => setLocForm({...locForm, neighborhood: e.target.value})}
                                placeholder="Quartier (ex: Louis, Nzeng Ayong...)"
                                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-sky-500"
                            />
                        </div>
                        <button 
                            onClick={handleSaveLoc}
                            disabled={!locForm.city || !locForm.neighborhood}
                            className="w-full py-4 bg-sky-500 text-white font-black uppercase text-xs tracking-widest rounded-xl flex items-center justify-center gap-2 mt-4 active:scale-95 transition-transform disabled:opacity-50"
                        >
                            <Check className="w-4 h-4" /> {t('PROF_CONFIRM_ZONE')}
                        </button>
                    </div>
                ) : (
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-2xl font-[1000] text-white uppercase">{userLocation.neighborhood}</p>
                            <p className="text-xs font-bold text-white/50 uppercase tracking-widest mt-1">
                                {userLocation.city}, {userLocation.country}
                            </p>
                        </div>
                        <div className="w-12 h-12 bg-sky-500/20 rounded-full flex items-center justify-center">
                            <MapPin className="w-6 h-6 text-sky-500" />
                        </div>
                    </div>
                )}
            </div>
        </section>
        
        {/* SECTION HALL OF FAME ACCESS - CORRECTION: BG SOLID */}
        <div className="mb-12">
           <button 
             onClick={() => openModal('HALL_OF_FAME')}
             className="w-full p-6 bg-zinc-900 border border-[#ffd700] rounded-2xl flex items-center justify-between group active:scale-95 transition-all"
           >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#ffd700] rounded-xl text-black">
                  <Trophy className="w-6 h-6 fill-current" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-[1000] uppercase text-white tracking-tight">{t('PROF_REWARDS')}</h3>
                  <p className="text-[10px] font-bold text-[#ffd700] uppercase tracking-widest mt-0.5">{t('PROF_REGISTRY')}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-black rounded-lg border border-white/10">
                    <QrCode className="w-4 h-4 text-white/50" />
                 </div>
                 <ChevronRight className="w-5 h-5 text-white/30" />
              </div>
           </button>
        </div>

        <section className="mb-12">
          <div className="flex items-center gap-3 mb-6">
             <PieChart className="w-6 h-6 text-[#ff0000]" />
             <h3 className="text-xl font-[1000] uppercase tracking-normal">{t('PROF_INTERESTS')}</h3>
          </div>
          <p className="text-gray-500 text-xs mb-8 font-bold uppercase tracking-wider">{t('PROF_INTERESTS_SUB')}</p>
          
          <div className="grid grid-cols-2 gap-4">
            {CATEGORIES.map((cat) => {
              const isSelected = preferences.includes(cat);
              const catColor = CATEGORY_COLORS[cat];
              const textColor = getTextColor(cat);
              const translatedLabel = t(`CAT_${cat.toUpperCase()}`, cat);
              
              return (
                <button
                  key={cat}
                  onClick={() => togglePreference(cat)}
                  className={`py-5 px-6 font-[1000] uppercase text-sm border-2 transition-all flex items-center justify-between ${
                    isSelected 
                      ? `${textColor} border-white` 
                      : 'bg-zinc-900 border-zinc-800 text-gray-500'
                  }`}
                  style={{ backgroundColor: isSelected ? catColor : undefined }}
                >
                  {translatedLabel}
                  {isSelected && <div className={`w-3 h-3 rotate-45 ${textColor === 'text-black' ? 'bg-black' : 'bg-white'}`}></div>}
                </button>
              );
            })}
          </div>
        </section>

        <div className="space-y-4">
          <button className="w-full flex items-center justify-between p-6 bg-zinc-900 border border-white/10 hover:border-white/20 transition-colors text-white">
            <span className="font-black uppercase tracking-tight">{t('PROF_HISTORY')}</span>
            <ChevronRight className="w-6 h-6 text-gray-500" />
          </button>
          
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-between p-6 bg-zinc-900 border border-[#ff0000]/50 hover:bg-[#ff0000] hover:text-white transition-colors active:scale-[0.98]"
          >
            <span className="font-black uppercase tracking-tight text-[#ff0000] group-hover:text-white">{t('PROF_LOGOUT')}</span>
            <LogOut className="w-6 h-6 text-[#ff0000] group-hover:text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
