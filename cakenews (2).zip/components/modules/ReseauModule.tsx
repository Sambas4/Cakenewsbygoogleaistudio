
import React, { useState, useEffect } from 'react';
import { 
  Zap, BookOpen, Globe, Eye, 
  Heart, MessageCircle, Flag, BarChart3, Clock, TrendingUp, CheckCircle2, Share2
} from 'lucide-react';
import { ReseauSkeleton } from '../ui/Loader';
import { useArticle } from '../../context/ArticleContext';
import { useTranslation } from '../../context/TranslationContext'; // IMPORT

interface ReseauModuleProps {
  likes: number;
  comments: number;
  echoesCount: number;
  author: string;
  accentColor: string;
}

// Hook pour animer les nombres
const useCountUp = (end: number, duration: number = 2000, start: number = 0) => {
  const [count, setCount] = useState(start);

  useEffect(() => {
    let startTime: number | null = null;
    let animationFrameId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      // Easing function: easeOutExpo
      const easeValue = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      
      setCount(Math.floor(easeValue * (end - start) + start));

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    animationFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrameId);
  }, [end, duration, start]);

  return count;
};

const AnimatedStatCard: React.FC<{ 
  label: string; 
  value: number; 
  icon: any; 
  subValue?: string;
  color?: string;
  isKilo?: boolean;
}> = ({ label, value, icon: Icon, subValue, color = "text-white", isKilo = false }) => {
  const displayValue = useCountUp(value, 1500);
  
  // Formatage : 14200 -> 14.2K
  const formatted = isKilo 
    ? (displayValue / 1000).toFixed(1) + 'K' 
    : displayValue.toLocaleString();

  return (
    <div className="bg-zinc-900 border border-white/5 p-5 rounded-[24px] flex flex-col justify-between transition-all hover:border-white/20">
      <div className="flex items-center justify-between mb-4">
        <div className="p-2 bg-white/5 rounded-xl">
          <Icon className="w-4 h-4 text-white/40" />
        </div>
        {subValue && (
          <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">{subValue}</span>
        )}
      </div>
      <div>
        <p className={`text-2xl font-[1000] leading-none mb-1 ${color}`}>{formatted}</p>
        <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">{label}</p>
      </div>
    </div>
  );
};

const ReseauModule: React.FC<ReseauModuleProps> = ({ likes, comments, echoesCount, author, accentColor }) => {
  const { t } = useTranslation(); // HOOK
  const [isLoading, setIsLoading] = useState(true);
  const { article } = useArticle();

  useEffect(() => {
    setIsLoading(true);
    // Simulation d'un appel API pour les stats temps réel
    const timer = setTimeout(() => setIsLoading(false), 1000);
    return () => clearTimeout(timer);
  }, [article.id]);

  if (isLoading) {
    return <ReseauSkeleton />;
  }

  return (
    <div className="animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
      <div className="flex items-center justify-between mb-10">
        <h3 className="text-2xl font-[1000] uppercase tracking-tighter text-white">{t('RES_TITLE')}</h3>
        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full">
          <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: accentColor }}></div>
          <span className="text-[8px] font-black text-white/40 uppercase tracking-widest">{t('RES_REALTIME')}</span>
        </div>
      </div>
      
      {/* SECTION 1: VISIBILITÉ & ENGAGEMENT */}
      <div className="mb-12">
        <div className="flex items-center gap-2 mb-6 opacity-40">
          <TrendingUp className="w-3 h-3" />
          <span className="text-[9px] font-black uppercase tracking-[0.4em]">{t('RES_IMPACT')}</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <AnimatedStatCard label={t('RES_VIEWS')} value={142000} icon={Eye} subValue="+12%" isKilo />
          <div className="bg-zinc-900 border border-white/5 p-5 rounded-[24px] flex flex-col justify-between transition-all hover:border-white/20">
             <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-white/5 rounded-xl"><BookOpen className="w-4 h-4 text-white/40" /></div>
                <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">{t('DOSSIER_MODE_FLASH')}</span>
             </div>
             <div>
                <p className="text-2xl font-[1000] leading-none mb-1 text-white">68%</p>
                <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">{t('RES_READ_RATE')}</p>
             </div>
          </div>
          <AnimatedStatCard label={t('ACTION_LIKE')} value={likes} icon={Heart} color="text-[#ff0000]" />
          <AnimatedStatCard label={t('ACTION_SHARE')} value={2400} icon={Share2} isKilo />
        </div>
      </div>

      {/* SECTION 2: CONVERSATION & ECHO */}
      <div className="mb-12">
        <div className="flex items-center gap-2 mb-6 opacity-40">
          <MessageCircle className="w-3 h-3" />
          <span className="text-[9px] font-black uppercase tracking-[0.4em]">{t('RES_INTERACTIONS')}</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <AnimatedStatCard label={t('ROOM_TAB_DEBATES')} value={comments} icon={MessageCircle} />
          <AnimatedStatCard label={t('RES_SOURCES')} value={echoesCount} icon={Globe} color="text-sky-400" />
          
          <div className="bg-zinc-900 border border-white/5 p-5 rounded-[24px] flex flex-col justify-between">
             <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-white/5 rounded-xl"><Clock className="w-4 h-4 text-white/40" /></div>
             </div>
             <div>
                <p className="text-2xl font-[1000] leading-none mb-1 text-white">1m 42s</p>
                <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">{t('RES_AVG_TIME')}</p>
             </div>
          </div>

          <div className="bg-zinc-900 border border-white/5 p-5 rounded-[24px] flex flex-col justify-between">
             <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-white/5 rounded-xl"><Zap className="w-4 h-4 text-white/40" /></div>
                <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">/10</span>
             </div>
             <div>
                <p className="text-2xl font-[1000] leading-none mb-1 text-yellow-500">9.4</p>
                <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.2em]">{t('RES_VIRALITY')}</p>
             </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: TRANSPARENCE RADICALE */}
      <div className="mb-12 p-8 bg-zinc-900 border-2 border-white/10 rounded-[40px] relative">
        <div className="absolute -top-4 right-8">
           <div className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-full border border-black/10">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-[10px] font-[1000] uppercase tracking-tighter">{t('ECHO_CERTIFICATION')}</span>
           </div>
        </div>

        <div className="flex items-center gap-3 mb-8 text-white">
          <Flag className="w-5 h-5 opacity-60" />
          <span className="text-[12px] font-[1000] uppercase tracking-[0.4em]">{t('RES_INTEGRITY')}</span>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-white/5 p-5 rounded-[24px] border border-white/5">
             <p className="text-3xl font-[1000] text-white leading-none mb-1">12</p>
             <p className="text-[9px] font-bold text-white/40 uppercase tracking-widest">{t('RES_REPORTS')}</p>
          </div>
          <div className="bg-white/5 p-5 rounded-[24px] border border-white/5">
             <p className="text-3xl font-[1000] text-white leading-none mb-1">03</p>
             <p className="text-[9px] font-bold text-white/40 uppercase tracking-widest">{t('RES_CONTEST')}</p>
          </div>
        </div>
        
        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-white/20 to-transparent mb-8"></div>

        <div className="space-y-4">
           <p className="text-[16px] text-white font-[1000] leading-tight uppercase tracking-tight text-center">
             {t('RES_TRANSPARENCY')}
           </p>
           <p className="text-[12px] text-white/70 font-medium leading-relaxed text-center px-2">
             {t('RES_DISCLAIMER')}
           </p>
        </div>
      </div>

      {/* JOURNALISTE SECTION */}
      <div className="p-8 bg-zinc-900 border border-white/5 rounded-[40px]">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-white flex items-center justify-center text-black text-3xl font-[1000] rounded-2xl">
            {author.charAt(0)}
          </div>
          <div>
             <span className="text-[9px] font-black text-white/20 uppercase tracking-[0.4em] block mb-2">{t('DOSSIER_SIGNATURE')}</span>
             <p className="text-2xl font-[1000] uppercase tracking-tighter text-white leading-none mb-1">{author}</p>
             <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{t('DOSSIER_ROLE')}</p>
          </div>
        </div>
        <button className="w-full mt-8 py-5 bg-white/5 hover:bg-white/10 border border-white/10 text-white text-[10px] font-black uppercase tracking-[0.3em] rounded-2xl transition-all active:scale-95 flex items-center justify-center gap-3">
          <BarChart3 className="w-4 h-4" /> {t('RES_BTN_FULL')}
        </button>
      </div>
    </div>
  );
};

export default ReseauModule;
