
import React, { useState, useEffect } from 'react';
import { ExternalVoice } from '../../types';
import { MessageCircle, Globe } from 'lucide-react';
import DebatsModule from './DebatsModule';
import EchoesModule from './EchoesModule';
import { useInteraction } from '../../context/InteractionContext';
import { useArticle } from '../../context/ArticleContext';
import { RoomSkeleton } from '../ui/Loader';

interface RoomModuleProps {
  voices: ExternalVoice[];
  accentColor: string;
  initialSubTab?: 'comments' | 'echoes';
  focusCommentId?: string;
  isEditable?: boolean;
  onUpdate?: (updates: any) => void;
}

const RoomModule: React.FC<RoomModuleProps> = ({ 
  voices, accentColor, initialSubTab = 'comments', focusCommentId, isEditable, onUpdate 
}) => {
  const { isRead, markAsRead } = useInteraction();
  const { article } = useArticle();
  const [activeSubTab, setActiveSubTab] = useState<'comments' | 'echoes'>(initialSubTab);
  const [isLoading, setIsLoading] = useState(true);
  
  // Utilisation de vraies data pour les compteurs
  const unreadEchoCount = voices.filter(v => !isRead(v.id)).length;
  const unreadDebatCount = isRead(`debate-opened-${article.id}`) ? 0 : 3;

  // Simulation chargement données temps réel (sauf en mode édition où on veut de l'instantané)
  useEffect(() => {
    if (isEditable) {
        setIsLoading(false);
        return;
    }
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, [article.id, isEditable]);

  useEffect(() => {
    if (focusCommentId && focusCommentId !== 'me') setActiveSubTab('comments');
  }, [focusCommentId]);

  const handleTabChange = (tab: 'comments' | 'echoes') => {
    setActiveSubTab(tab);
    if (tab === 'comments') markAsRead(`debate-opened-${article.id}`);
  };

  const handleVoicesUpdate = (updatedVoices: ExternalVoice[]) => {
      if (onUpdate) onUpdate({ externalVoices: updatedVoices });
  };

  if (isLoading) {
    return <RoomSkeleton />;
  }

  return (
    <div className="animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex items-center gap-2 mb-10 p-1.5 bg-zinc-900/80 rounded-2xl border border-white/5 mx-4 mt-4">
        <button 
          onClick={() => handleTabChange('comments')}
          className={`flex-1 py-4 text-[10px] font-[1000] uppercase tracking-[0.2em] rounded-xl transition-all flex items-center justify-center gap-2 ${activeSubTab === 'comments' ? 'bg-white text-black' : 'text-white/20'}`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>Débats</span>
          {unreadDebatCount > 0 && <span className={`${activeSubTab === 'comments' ? 'text-black/40' : 'text-green-500'} font-[1000] ml-1`}>({unreadDebatCount})</span>}
        </button>
        <button 
          onClick={() => handleTabChange('echoes')}
          className={`flex-1 py-4 text-[10px] font-[1000] uppercase tracking-[0.2em] rounded-xl transition-all flex items-center justify-center gap-2 ${activeSubTab === 'echoes' ? 'bg-white text-black' : 'text-white/20'}`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Échos</span>
          {unreadEchoCount > 0 && <span className={`${activeSubTab === 'echoes' ? 'text-black/40' : 'text-green-500'} font-[1000] ml-1`}>({unreadEchoCount})</span>}
        </button>
      </div>

      <div className="px-4 pb-10">
        {activeSubTab === 'comments' ? (
          <DebatsModule focusId={focusCommentId} onCommentInteraction={() => {}} />
        ) : (
          <EchoesModule 
            voices={voices} 
            accentColor={accentColor} 
            isEditable={isEditable}
            onVoicesUpdate={handleVoicesUpdate}
          />
        )}
      </div>
    </div>
  );
};

export default RoomModule;
