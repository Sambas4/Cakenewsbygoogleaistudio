
import React, { CSSProperties, useRef, useEffect, useState } from 'react';

interface DossierParagraphProps {
  content: string;
  index: number;
  accentColor: string;
  isEditable?: boolean;
  onUpdate?: (text: string) => void;
}

// Extension du type CSS pour inclure contentVisibility
interface ExtendedCSS extends CSSProperties {
  contentVisibility?: string;
}

const DossierParagraph: React.FC<DossierParagraphProps> = ({ content, index, accentColor, isEditable = false, onUpdate }) => {
  const elementRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // EFFET REVEAL ON SCROLL
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        // On déclenche l'apparition dès que 10% du paragraphe est visible
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // Une fois apparu, on arrête d'observer pour la perf
        }
      },
      { threshold: 0.1, rootMargin: '50px' }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, []);

  if (!content.trim() && !isEditable) return null;

  const style: ExtendedCSS = { contentVisibility: 'auto' };

  return (
    <div 
        ref={elementRef}
        className={`relative group transition-all duration-700 ease-out transform ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
        style={{ transitionDelay: `${index * 50}ms` }} // Petit délai en cascade
    >
        <p 
          className={`text-zinc-200 text-[19px] md:text-2xl leading-[1.7] font-medium mb-10 last:mb-0 relative text-left outline-none ${isEditable ? 'hover:bg-white/5 p-2 rounded-lg transition-colors border border-transparent focus:border-white/20' : ''}`}
          style={style}
          contentEditable={isEditable}
          suppressContentEditableWarning
          onBlur={(e) => onUpdate?.(e.currentTarget.innerText)}
        >
          {index === 0 && !isEditable ? (
            <>
              <span 
                style={{ color: accentColor }} 
                className="float-left text-[85px] font-[1000] mr-4 leading-[0.7] select-none uppercase italic-none animate-in zoom-in duration-500"
              >
                {content.charAt(0)}
              </span>
              <span className="normal-case">{content.slice(1)}</span>
            </>
          ) : (
            <span className="normal-case">{content}</span>
          )}
        </p>
        {isEditable && (
            <span className="absolute right-0 top-0 text-[8px] font-black uppercase text-white/20 opacity-0 group-hover:opacity-100 pointer-events-none">
                EDIT
            </span>
        )}
    </div>
  );
};

export default React.memo(DossierParagraph);
