
import React from 'react';
import { Zap, Activity } from 'lucide-react';

// OPTIMISATION: Blocs solides, pas de dégradés, pas de flou.
const SolidBlock = ({ className }: { className?: string }) => (
    <div className={`bg-zinc-800 animate-pulse ${className}`} />
);

export const ModuleLoader = () => (
  <div className="w-full h-full flex flex-col items-center justify-center p-8 space-y-6">
    <div className="w-full space-y-4">
       <SolidBlock className="h-8 w-3/4 rounded-lg" />
       <div className="space-y-3">
          <SolidBlock className="h-4 w-full rounded" />
          <SolidBlock className="h-4 w-11/12 rounded" />
          <SolidBlock className="h-4 w-full rounded" />
       </div>
    </div>
  </div>
);

export const ContentDecryptor = ({ accentColor }: { accentColor: string }) => (
  <div className="w-full relative overflow-hidden">
     <div className="flex items-center gap-2 mb-8 opacity-50">
        <div className="w-2 h-2 rounded-full animate-flash" style={{ backgroundColor: accentColor }}></div>
        <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/50">Flux entrant...</span>
     </div>
     <div className="h-10 bg-zinc-900 rounded-lg w-5/6 mb-12"></div>
     <div className="space-y-8">
        {[1, 2, 3].map((i) => (
           <div key={i} className="space-y-3 opacity-60">
              <SolidBlock className="h-4 w-full rounded" />
              <SolidBlock className="h-4 w-[90%] rounded" />
              <SolidBlock className="h-4 w-[95%] rounded" />
           </div>
        ))}
     </div>
  </div>
);

export const ImageSkeleton = () => (
  <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center overflow-hidden">
    <div className="flex flex-col items-center gap-2 opacity-30">
        <div className="p-3 bg-white/5 rounded-full">
           <Zap className="w-5 h-5 text-white/50" />
        </div>
    </div>
  </div>
);

// SKELETON ROOM
export const RoomSkeleton = () => (
  <div className="w-full space-y-8 px-4 mt-8">
     <div className="flex items-center gap-2 mb-10 p-1.5 bg-zinc-900/50 rounded-2xl border border-white/5">
        <SolidBlock className="flex-1 h-10 rounded-xl" />
        <div className="flex-1 h-10 bg-transparent rounded-xl"></div>
     </div>
     {[1, 2, 3].map((i) => (
       <div key={i} className={`flex flex-col ${i % 2 === 0 ? 'items-end' : 'items-start'}`}>
          <div className="flex items-center gap-2 mb-2">
             <SolidBlock className="w-6 h-6 rounded-full" />
             <SolidBlock className="h-3 w-20 rounded" />
          </div>
          <div className={`w-[85%] h-24 rounded-[24px] bg-zinc-900 border border-white/5 ${i % 2 === 0 ? 'rounded-tr-none' : 'rounded-tl-none'}`}></div>
       </div>
     ))}
  </div>
);

// SKELETON RESEAU
export const ReseauSkeleton = () => (
  <div className="w-full space-y-12">
      <div className="flex items-center justify-between mb-10">
        <SolidBlock className="h-8 w-48 rounded" />
        <SolidBlock className="h-6 w-24 rounded-full" />
      </div>
      <div className="space-y-6">
         <div className="flex gap-2 opacity-50">
            <Activity className="w-4 h-4" />
            <SolidBlock className="h-4 w-32 rounded" />
         </div>
         <div className="grid grid-cols-2 gap-3">
            <div className="h-32 bg-zinc-900 rounded-[24px] border border-white/5"></div>
            <div className="h-32 bg-zinc-900 rounded-[24px] border border-white/5"></div>
            <div className="h-32 bg-zinc-900 rounded-[24px] border border-white/5"></div>
         </div>
      </div>
  </div>
);

// SKELETON MESSAGES
export const MessageSkeleton = () => (
   <div className="flex flex-col h-full bg-black overflow-hidden">
      <div className="p-8 pb-4 space-y-8">
         <SolidBlock className="h-10 w-32 rounded-lg" />
         <div className="flex bg-zinc-900 p-1 border border-white/5 rounded-2xl h-14"></div>
      </div>
      <div className="px-8 space-y-4">
         {[1, 2, 3].map(i => (
            <div key={i} className="flex gap-4 p-6 rounded-[32px] border border-white/5 bg-zinc-900">
               <SolidBlock className="w-14 h-14 rounded-2xl" />
               <div className="flex-1 space-y-3 py-1">
                  <div className="flex justify-between">
                     <SolidBlock className="h-4 w-24 rounded" />
                     <SolidBlock className="h-3 w-10 rounded" />
                  </div>
                  <SolidBlock className="h-3 w-full rounded opacity-50" />
               </div>
            </div>
         ))}
      </div>
   </div>
);

// SKELETON PROFILE
export const ProfileSkeleton = () => (
   <div className="p-8 space-y-8">
      <div className="flex justify-between items-center mb-10">
         <SolidBlock className="h-10 w-40 rounded-lg" />
         <SolidBlock className="w-12 h-12 rounded-lg" />
      </div>
      <div className="bg-zinc-900 h-48 border-2 border-white/5 mb-12"></div>
      <div className="h-20 w-full bg-zinc-900 rounded-2xl"></div>
      <div className="grid grid-cols-2 gap-4">
         {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-16 bg-zinc-900 border border-white/5"></div>
         ))}
      </div>
   </div>
);
