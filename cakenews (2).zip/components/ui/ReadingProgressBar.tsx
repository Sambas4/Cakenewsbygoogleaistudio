
import React from 'react';

interface ReadingProgressBarProps {
  progress: number; // 0 to 1
  accentColor: string;
}

const ReadingProgressBar: React.FC<ReadingProgressBarProps> = ({ progress, accentColor }) => {
  return (
    <div className="fixed top-[60px] left-0 w-full h-[3px] bg-white/5 z-[65] pointer-events-none">
      <div 
        className="h-full transition-all duration-200 ease-out"
        style={{ 
          width: `${progress * 100}%`,
          backgroundColor: accentColor 
        }}
      />
    </div>
  );
};

export default React.memo(ReadingProgressBar);
