
import React, { useEffect, useState } from 'react';
import { AlertTriangle, ChevronRight, FileText, ArrowRight, X } from 'lucide-react';
import { useBroadcast } from '../../context/BroadcastContext';
import { useTranslation } from '../../context/TranslationContext';

interface BreakingNewsOverlayProps {
  onNavigate?: (articleId: string) => void;
}

const BreakingNewsOverlay: React.FC<BreakingNewsOverlayProps> = ({ onNavigate }) => {
  const { t } = useTranslation();
  const { activeAlert, dismissAlert } = useBroadcast();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (activeAlert) {
        setIsVisible(true);
    } else {
        const timer = setTimeout(() => setIsVisible(false), 500); 
        return () => clearTimeout(timer);
    }
  }, [activeAlert]);

  if (!isVisible || !activeAlert) return null;

  const handlePrimaryAction = () => {
    dismissAlert(activeAlert.id);
    if (activeAlert.linkedArticleId && onNavigate) {
      setTimeout(() => {
        onNavigate(activeAlert.linkedArticleId!);
      }, 300);
    }
  };

  return (
    <div 
      className={`fixed inset-0 z-[400] flex flex-col items-center justify-center transition-all duration-300 overflow-hidden bg-black ${activeAlert ? 'pointer-events-auto' : 'pointer-events-none'}`}
    >
      {/* BACKGROUND SOLIDE - OPTIMISATION MAXIMALE */}
      <div className={`absolute inset-0 bg-[#8a0000] transition-opacity duration-300 ${activeAlert ? 'opacity-100' : 'opacity-0'}`}>
         {/* Motif Scanline simple (CSS pur) */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.2)_50%,transparent_50%)] bg-[length:100%_4px] pointer-events-none"></div>
      </div>

      <div 
        className={`relative z-20 w-full max-w-md p-8 flex flex-col items-center text-center transform transition-all duration-500 ease-out ${activeAlert ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}
      >
        {/* ICONE - Suppression des effets pulse complexes */}
        <div className="mb-8 relative">
            <div className="absolute inset-0 bg-red-500 rounded-full animate-flash opacity-50"></div>
            <div className="relative w-24 h-24 bg-white text-red-600 rounded-full flex items-center justify-center border-4 border-red-500">
                <AlertTriangle className="w-12 h-12 fill-current" />
            </div>
        </div>

        {/* HEADER */}
        <div className="mb-8 space-y-2">
            <div className="inline-flex items-center gap-2 px-4 py-1 bg-black border border-white/20 rounded-full">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-flash"></div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white">{t('OVERLAY_INTERRUPTION')}</span>
            </div>
            <h1 className="text-5xl font-[1000] uppercase tracking-tighter leading-[0.85] text-white italic">
                {t('OVERLAY_FLASH_TITLE').split(' ').map((word, i) => (
                    <React.Fragment key={i}>
                        {word}<br/>
                    </React.Fragment>
                ))}
            </h1>
        </div>

        {/* CONTENU MESSAGE - Suppression du blur */}
        <div className="mb-12 w-full">
            <div className="bg-black border-l-4 border-white p-6 rounded-r-2xl text-left">
                <p className="text-2xl md:text-3xl font-[1000] uppercase leading-[0.95] text-white">
                    {activeAlert.message}
                </p>
                {activeAlert.targeting.locations.length > 0 && (
                    <div className="mt-4 flex items-center gap-2">
                        <span className="text-[9px] font-black uppercase tracking-widest text-red-500 bg-white px-2 py-0.5 rounded">
                            ZONE IMPACTÉE
                        </span>
                        <span className="text-[10px] font-bold text-white/70 uppercase">
                            {activeAlert.targeting.locations.join(', ')}
                        </span>
                    </div>
                )}
            </div>
        </div>

        {/* ACTIONS */}
        <div className="w-full space-y-3">
            {activeAlert.linkedArticleId ? (
                <button 
                    onClick={handlePrimaryAction}
                    className="w-full py-5 bg-white text-black rounded-2xl font-black uppercase text-sm tracking-[0.2em] flex items-center justify-center gap-3 active:scale-95 transition-all hover:bg-zinc-200 group"
                >
                    {t('OVERLAY_OPEN')} <FileText className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
            ) : (
                <div className="h-4"></div>
            )}
            
            <button 
                onClick={() => dismissAlert(activeAlert.id)}
                className="w-full py-4 text-white/60 font-black text-[10px] uppercase tracking-[0.2em] hover:text-white transition-colors flex items-center justify-center gap-2 group"
            >
                {activeAlert.linkedArticleId ? t('OVERLAY_IGNORE') : t('OVERLAY_IGNORE')} <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
        </div>
      </div>
    </div>
  );
};

export default BreakingNewsOverlay;
