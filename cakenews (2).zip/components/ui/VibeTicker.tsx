
import React, { useMemo } from 'react';
import { MOCK_TICKER_DATA } from '../../data/mockData';
import { useModal } from '../../context/ModalContext';
import { useBroadcast } from '../../context/BroadcastContext';
import { Radio, AlertTriangle, Monitor } from 'lucide-react';
import { useTranslation } from '../../context/TranslationContext';

const VibeTicker: React.FC = () => {
  const { openModal } = useModal();
  const { activeTickerMessages, recordView, config } = useBroadcast();
  const { t } = useTranslation();

  const hasActiveCampaigns = activeTickerMessages.length > 0;
  
  const hasUrgentCampaigns = useMemo(() => {
      return activeTickerMessages.some(msg => msg.priority >= 8);
  }, [activeTickerMessages]);

  React.useEffect(() => {
      if (hasActiveCampaigns) {
          activeTickerMessages.forEach(msg => recordView(msg.id));
      }
  }, [hasActiveCampaigns, activeTickerMessages, recordView]); 

  const displayData = useMemo(() => {
    if (hasActiveCampaigns) {
        return [{
            label: hasUrgentCampaigns ? "ALERTE INFO" : "INFO LIVE",
            color: hasUrgentCampaigns ? "#ef4444" : "#ffffff",
            users: activeTickerMessages.map(msg => ({
                rank: 0,
                name: msg.name,
                score: msg.message,
                category: 'DIRECT',
                isUrgent: msg.priority >= 8,
                isOverlay: msg.type === 'ALERT'
            }))
        }];
    }

    const groupManualEntries = (entries: any[]) => {
        const groups: Record<string, any[]> = {};
        entries.forEach(entry => {
            const cat = entry.categoryLabel || 'DIVERS';
            if (!groups[cat]) groups[cat] = [];
            groups[cat].push(entry);
        });

        return Object.keys(groups).map(catKey => {
            const customTitle = config.categoryTitles?.[catKey];
            const displayLabel = customTitle || `CLASSEMENT ${catKey}`;
            const groupColor = groups[catKey][0]?.color || '#ffcc00';

            return {
                label: displayLabel,
                color: groupColor,
                users: groups[catKey].map((entry, idx) => ({
                    rank: idx + 1,
                    name: entry.userName,
                    score: entry.score,
                    category: entry.categoryLabel,
                    avatar: entry.avatar,
                    color: entry.color,
                    isUrgent: false
                }))
            };
        });
    };

    if (config.rankingMode === 'MANUAL' && config.manualRankings.length > 0) {
        return groupManualEntries(config.manualRankings);
    }

    if (config.rankingMode === 'HYBRID') {
        const pinnedNames = new Set(config.manualRankings.map(r => r.userName));
        const pinnedGroups = groupManualEntries(config.manualRankings);
        const filteredAlgoGroups = MOCK_TICKER_DATA.map(group => ({
            ...group,
            users: group.users.filter(u => !pinnedNames.has(u.name)).map(u => ({...u, isUrgent: false}))
        })).filter(group => group.users.length > 0);

        return [...pinnedGroups, ...filteredAlgoGroups];
    }

    return MOCK_TICKER_DATA.map(g => ({
        ...g,
        users: g.users.map(u => ({...u, isUrgent: false}))
    }));
  }, [hasActiveCampaigns, activeTickerMessages, config.rankingMode, config.manualRankings, hasUrgentCampaigns, config.categoryTitles]);
  
  const loopGroups = [...displayData, ...displayData];

  const indicatorColor = hasUrgentCampaigns ? 'bg-red-600' : (hasActiveCampaigns ? 'bg-blue-500' : (config.rankingMode === 'MANUAL' ? 'bg-[#ffcc00]' : 'bg-sky-500'));
  
  const indicatorLabelKey = hasUrgentCampaigns ? 'TICKER_URGENT' : (hasActiveCampaigns ? 'TICKER_TARGETED' : (config.rankingMode === 'MANUAL' ? 'TICKER_TOP' : 'TICKER_LIVE'));
  const indicatorLabel = t(indicatorLabelKey);

  return (
    <div className="relative w-full h-[50px] bg-black border-b border-white/10 flex items-center z-[60] flex-shrink-0">
      
      {/* INDICATEUR LIVE FIXE (Gauche) */}
      <div className="absolute left-0 top-0 bottom-0 px-4 bg-black z-20 flex items-center gap-2 border-r border-white/10">
        <div className="relative flex items-center justify-center">
           {/* SEUL CECI DOIT CLIGNOTER */}
           <div className={`w-2 h-2 rounded-full ${indicatorColor} animate-flash`}></div>
        </div>
        <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${hasUrgentCampaigns ? 'text-red-500' : 'text-white'}`}>
            {indicatorLabel}
        </span>
      </div>

      {/* CONTENEUR DE DEFILEMENT */}
      <div className="flex-1 overflow-hidden relative h-full flex items-center pl-4 bg-black">
        <div 
          className="flex whitespace-nowrap items-center animate-marquee-left" 
          style={{ 
            animationDuration: hasActiveCampaigns ? '30s' : '60s', 
            width: 'max-content'
          }}
        >
          {loopGroups.map((group, groupIndex) => (
            <div key={`group-${groupIndex}`} className="flex items-center">
              
              {/* TITRE DE LA CATÉGORIE - ICÔNES STATIQUES */}
              <div className="px-6 flex items-center gap-2">
                 {hasActiveCampaigns && (
                     hasUrgentCampaigns ? <AlertTriangle className="w-3 h-3 text-red-500" /> : <Radio className="w-3 h-3 text-blue-500" />
                 )}
                 <span 
                   className="text-[14px] font-[1000] uppercase tracking-wide"
                   style={{ color: group.color }}
                 >
                   {group.label}
                 </span>
                 <span className="w-1 h-1 bg-white/40 rounded-full mx-2"></span>
              </div>

              {/* ITEMS DU TICKER */}
              {group.users.map((item: any, idx: number) => {
                
                // Styles FLAT
                let containerClass = "text-white";
                let badgeClass = "bg-blue-600 text-white";

                if (item.isUrgent) {
                    containerClass = "bg-red-600 text-white border border-red-500";
                    badgeClass = "bg-white text-red-600";
                } else if (item.isOverlay) {
                    containerClass = "bg-white text-black border border-white";
                    badgeClass = "bg-black text-white";
                }

                return (
                <div key={`${group.label}-${idx}`} className="flex items-center pr-4">
                  <div 
                    className={`group flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all ${containerClass}`}
                  >
                    {hasActiveCampaigns ? (
                        // Mode Message Texte
                        <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-black uppercase px-1.5 py-0.5 rounded ${badgeClass}`}>
                                {item.name || 'INFO'}
                            </span>
                            
                            {item.isOverlay && !item.isUrgent && (
                                <Monitor className="w-3 h-3 text-black" />
                            )}
                            
                            <span className="text-[12px] font-bold uppercase tracking-tight">
                                {item.score}
                            </span>
                        </div>
                    ) : (
                        // Mode Classement
                        <>
                            <span 
                                className="text-[12px] font-black uppercase tracking-tight group-hover:text-white transition-colors cursor-pointer flex items-center gap-2" 
                                onClick={() => openModal('TROPHY_VIEWER', { 
                                    data: {
                                        ...item, 
                                        label: item.category || 'Points', 
                                        color: item.color || group.color, 
                                        avatar: item.avatar || `https://i.pravatar.cc/150?u=${item.name}`
                                    } 
                                })}
                            >
                                {(config.rankingMode === 'MANUAL' || (config.rankingMode === 'HYBRID' && group.label === "⭐ À LA UNE")) && (
                                    <span className="text-[9px] text-white/40">#{item.rank}</span>
                                )}
                                {item.name}
                            </span>
                            <span 
                                className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-white/10 border border-white/5 uppercase"
                                style={{ color: item.color || group.color }}
                            >
                                {item.score}
                            </span>
                        </>
                    )}
                  </div>
                  
                  {/* Séparateur */}
                  {idx < group.users.length - 1 && (
                    <span className="text-[10px] text-white/20 font-black mx-2">•</span>
                  )}
                </div>
              );
              })}

              {/* SÉPARATEUR DE GROUPE */}
              <div className="w-[1px] h-4 bg-white/20 mx-4"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default React.memo(VibeTicker);
