
import React, { useMemo } from 'react';

interface TickerRowProps {
  text: string;
  duration: string;
  direction?: 'left' | 'right';
  className?: string;
  isVisible: boolean;
}

const TickerRow: React.FC<TickerRowProps> = ({ 
  text, 
  duration, 
  direction = 'left', 
  className = '', 
  isVisible 
}) => {
  const content = useMemo(() => Array(4).fill(text).join('     •     '), [text]);
  
  if (!isVisible) return null;

  return (
    <div 
      className="w-full overflow-hidden flex whitespace-nowrap pointer-events-none select-none relative"
      style={{ 
        contain: 'layout paint style'
      }}
    >
      {/* OPTIMISATION: Remplacement de mask-image par des divs de dégradé */}
      <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-black to-transparent z-10" />

      <div 
        className={`flex shrink-0 ${direction === 'left' ? 'animate-marquee-left' : 'animate-marquee-right'} ${className}`}
        style={{ 
          animationDuration: duration,
          willChange: 'transform',
          transform: 'translate3d(0, 0, 0)',
          backfaceVisibility: 'hidden',
          WebkitFontSmoothing: 'antialiased'
        }}
      >
        <span className="px-4 translate-z-0">{content}</span>
        <span className="px-4 translate-z-0">{content}</span>
      </div>
    </div>
  );
};

export default React.memo(TickerRow);
