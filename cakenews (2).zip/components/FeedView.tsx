
import React, { useRef, useEffect, useState, useCallback, useLayoutEffect } from 'react';
import { Article, AppTab } from '../types';
import ArticleCard from './ArticleCard';
import { useInteraction } from '../context/InteractionContext';
import { useNavigate, useParams } from 'react-router-dom';

interface FeedViewProps {
  articles: Article[];
  activeArticleIndex?: number;
  setActiveArticleIndex?: (index: number) => void;
  activeTab?: AppTab;
  onRoomEnter?: () => void;
  onUnreadCommentsChange?: (count: number) => void;
  navTarget?: { articleId: string; commentId?: string } | null;
  commentTrigger?: number;
}

const FeedView: React.FC<FeedViewProps> = ({
  articles,
  setActiveArticleIndex: propSetIndex,
  onRoomEnter,
  onUnreadCommentsChange,
  navTarget,
  commentTrigger
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { id: paramId } = useParams();
  const { markAsRead } = useInteraction();

  const [currentIndex, setCurrentIndex] = useState(0);
  // On initialise avec window.innerWidth pour éviter un flash au premier rendu
  const [containerWidth, setContainerWidth] = useState(window.innerWidth);

  const physics = useRef({
    isDragging: false,
    startX: 0,
    startY: 0,
    currentX: 0,
    startTime: 0,
    initialTranslate: 0,
    isLockedVertical: false,
    isLockedHorizontal: false,
  });

  // --- 1. SYNCHRONISATION ROUTE -> INDEX ---
  useEffect(() => {
    const targetIndex = articles.findIndex(a => a.id === paramId);
    if (targetIndex >= 0 && targetIndex !== currentIndex) {
      setCurrentIndex(targetIndex);
    } else if (!paramId && articles.length > 0) {
      navigate(`/article/${articles[0].id}`, { replace: true });
    }
  }, [paramId, articles]);

  // --- 2. GESTION DU RESIZE & WIDTH ---
  // Critique : On doit toujours connaître la largeur exacte en pixels pour le transform
  useLayoutEffect(() => {
    const updateWidth = () => {
        if (containerRef.current) {
            setContainerWidth(containerRef.current.clientWidth);
        }
    };
    window.addEventListener('resize', updateWidth);
    // Force update immédiat
    updateWidth();
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  // --- 3. ANIMATION CSS (SNAP) ---
  // C'est ici que la correction majeure opère : on utilise des PIXELS (width * index)
  useEffect(() => {
    if (trackRef.current) {
        trackRef.current.style.transition = 'transform 0.4s cubic-bezier(0.2, 0.8, 0.2, 1)';
        // CORRECTION: Utilisation de px au lieu de % pour éviter le décalage relatif à la taille totale du track
        trackRef.current.style.transform = `translate3d(${-currentIndex * containerWidth}px, 0, 0)`;
        
        const article = articles[currentIndex];
        if (article) {
            const timer = setTimeout(() => {
                markAsRead(article.id);
                if (propSetIndex) propSetIndex(currentIndex);
                navigate(`/article/${article.id}`, { replace: true });
            }, 300);
            return () => clearTimeout(timer);
        }
    }
  }, [currentIndex, containerWidth, articles, markAsRead, propSetIndex, navigate]);


  // --- 4. MOTEUR PHYSIQUE ---
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const onTouchStart = (e: TouchEvent) => {
        physics.current.isDragging = true;
        physics.current.startX = e.touches[0].clientX;
        physics.current.startY = e.touches[0].clientY;
        physics.current.currentX = e.touches[0].clientX;
        physics.current.startTime = Date.now();
        physics.current.isLockedVertical = false;
        physics.current.isLockedHorizontal = false;
        
        if (trackRef.current) {
            // Calcul en pixels absolus
            physics.current.initialTranslate = -currentIndex * container.clientWidth;
            trackRef.current.style.transition = 'none';
        }
    };

    const onTouchMove = (e: TouchEvent) => {
        if (!physics.current.isDragging) return;

        const x = e.touches[0].clientX;
        const y = e.touches[0].clientY;
        const dx = x - physics.current.startX;
        const dy = y - physics.current.startY;

        if (!physics.current.isLockedHorizontal && !physics.current.isLockedVertical) {
            if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 5) {
                physics.current.isLockedHorizontal = true;
            } else if (Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > 5) {
                physics.current.isLockedVertical = true;
                physics.current.isDragging = false;
                return;
            }
        }

        if (physics.current.isLockedHorizontal) {
            if (e.cancelable) e.preventDefault();
            
            physics.current.currentX = x;
            let effectiveDx = dx;
            
            // Résistance élastique aux bords
            if ((currentIndex === 0 && dx > 0) || (currentIndex === articles.length - 1 && dx < 0)) {
                effectiveDx = dx * 0.35;
            }

            if (trackRef.current) {
                const pxTranslate = physics.current.initialTranslate + effectiveDx;
                trackRef.current.style.transform = `translate3d(${pxTranslate}px, 0, 0)`;
            }
        }
    };

    const onTouchEnd = (e: TouchEvent) => {
        if (!physics.current.isDragging || !physics.current.isLockedHorizontal) {
            physics.current.isDragging = false;
            return;
        }

        const dx = physics.current.currentX - physics.current.startX;
        const dt = Date.now() - physics.current.startTime;
        const velocity = Math.abs(dx) / dt;
        const width = container.clientWidth;

        const shouldSwipe = Math.abs(dx) > width * 0.35 || velocity > 0.4;

        let newIndex = currentIndex;
        if (shouldSwipe) {
            if (dx < 0 && currentIndex < articles.length - 1) {
                newIndex = currentIndex + 1;
            } else if (dx > 0 && currentIndex > 0) {
                newIndex = currentIndex - 1;
            }
        }

        if (trackRef.current) {
            trackRef.current.style.transition = 'transform 0.4s cubic-bezier(0.1, 0.9, 0.2, 1)';
            // Snap final en pixels
            trackRef.current.style.transform = `translate3d(${-newIndex * width}px, 0, 0)`;
        }

        if (newIndex !== currentIndex) {
            setCurrentIndex(newIndex);
        }

        physics.current.isDragging = false;
        physics.current.isLockedHorizontal = false;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: false });
    container.addEventListener('touchend', onTouchEnd);
    container.addEventListener('touchcancel', onTouchEnd);

    return () => {
        container.removeEventListener('touchstart', onTouchStart);
        container.removeEventListener('touchmove', onTouchMove);
        container.removeEventListener('touchend', onTouchEnd);
        container.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [currentIndex, articles.length]); // Pas de dépendance sur containerWidth ici pour éviter de recréer les listeners, on lit container.clientWidth en direct

  return (
    <div 
      ref={containerRef}
      className="w-full h-full bg-black overflow-hidden relative touch-none select-none"
    >
      <div 
        ref={trackRef}
        className="h-full flex will-change-transform"
        style={{ 
            // Largeur totale en pixels ou % (mais le transform est en px maintenant)
            width: `${articles.length * 100}%`, 
            // Position initiale en pixels
            transform: `translate3d(${-currentIndex * containerWidth}px, 0, 0)` 
        }}
      >
        {articles.map((article, index) => {
            const distance = Math.abs(currentIndex - index);
            // On rend un de plus de chaque côté pour la fluidité lors des swipes rapides
            const shouldRender = distance <= 1;

            return (
                <div 
                    key={article.id}
                    className="h-full relative"
                    // Chaque slide prend exactement la largeur du conteneur parent (l'écran)
                    // C'est vital : width: 100vw / articles.length n'est pas fiable. 
                    // Ici on utilise le % relatif au track parent qui fait N * 100%. Donc 100/N % = 1 écran.
                    style={{ width: `${100 / articles.length}%` }}
                >
                    {shouldRender ? (
                        <ArticleCard 
                            article={article}
                            isActive={index === currentIndex}
                            isPreloading={index !== currentIndex}
                            onRoomEnter={onRoomEnter}
                            onUnreadCommentsChange={onUnreadCommentsChange}
                            navTarget={index === currentIndex ? navTarget : null}
                            onNavigateNext={() => {
                                if (index < articles.length - 1) setCurrentIndex(index + 1);
                            }}
                            commentTrigger={index === currentIndex ? commentTrigger : 0}
                        />
                    ) : (
                        <div className="w-full h-full bg-black" />
                    )}
                </div>
            );
        })}
      </div>
    </div>
  );
};

export default React.memo(FeedView);
