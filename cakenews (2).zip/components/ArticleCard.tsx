
import React, { useState, useRef, useMemo, Suspense, lazy, useEffect } from 'react';
import { Article } from '../types';
import { CATEGORY_COLORS } from '../constants';
import { Layers, Globe, BarChart3 } from 'lucide-react';
import { ModuleLoader } from './ui/Loader';
import { ArticleProvider } from '../context/ArticleContext';
import { useInteraction } from '../context/InteractionContext';
import ArticleCover from './article/ArticleCover';
import ReadingProgressBar from './ui/ReadingProgressBar';

const DossierModule = lazy(() => import('./modules/DossierModule'));
const RoomModule = lazy(() => import('./modules/RoomModule'));
const ReseauModule = lazy(() => import('./modules/ReseauModule'));

interface ArticleCardProps {
  article: Article;
  isActive?: boolean;
  isPreloading?: boolean;
  onRoomEnter?: () => void;
  onUnreadCommentsChange?: (count: number) => void;
  navTarget?: { articleId: string; commentId?: string } | null;
  onNavigateNext?: () => void;
  commentTrigger?: number;
  isEditable?: boolean;
  onArticleUpdate?: (updatedArticle: Article) => void;
}

type ArticleTab = 'dossier' | 'room' | 'reseau';

const ArticleCard: React.FC<ArticleCardProps> = (props) => {
  const { 
    article, isActive = false, isPreloading = false,
    onRoomEnter, onUnreadCommentsChange, 
    navTarget, onNavigateNext,
    commentTrigger,
    isEditable = false,
    onArticleUpdate
  } = props;

  const { isRead, triggerHaptic } = useInteraction();
  const [activeTab, setActiveTab] = useState<ArticleTab>('dossier');
  const [readingMode, setReadingMode] = useState<'flash' | 'deep'>('deep');
  const [readProgress, setReadProgress] = useState(0);
  
  const verticalContainerRef = useRef<HTMLDivElement>(null);
  
  // Reset de l'état quand l'article devient actif
  useEffect(() => {
    if (isActive) {
        if (navTarget?.articleId === article.id && navTarget.commentId) {
            setActiveTab('room');
            setTimeout(() => onRoomEnter?.(), 100);
        }
    }
  }, [isActive, article.id, navTarget, onRoomEnter]);

  // Trigger externe (Action Bar)
  useEffect(() => {
    if (isActive && commentTrigger && commentTrigger > 0) {
      setActiveTab('room');
      onRoomEnter?.();
      if (verticalContainerRef.current) {
          const coverHeight = verticalContainerRef.current.clientWidth;
          verticalContainerRef.current.scrollTo({ top: coverHeight, behavior: 'smooth' });
      }
    }
  }, [commentTrigger, isActive, onRoomEnter]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (!isActive || activeTab !== 'dossier') return;
    
    // Empêche la propagation du scroll vers le parent (FeedView) pour éviter de casser le swipe
    e.stopPropagation();

    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const totalHeight = scrollHeight - clientHeight;
    if (totalHeight > 0) {
        setReadProgress(scrollTop / totalHeight);
    }
  };

  const handleTabChange = (tab: ArticleTab) => {
    triggerHaptic('light');
    setActiveTab(tab);
    if (tab === 'room') {
        onRoomEnter?.();
    }
  };

  const accentColor = useMemo(() => 
    article.isExclusive ? '#ff0000' : article.isSensitive ? '#ffcc00' : CATEGORY_COLORS[article.category]
  , [article.isExclusive, article.isSensitive, article.category]);
  
  const unreadInRoom = useMemo(() => {
    if (!isActive) return 0;
    const voicesCount = (article.externalVoices || []).filter(v => !isRead(v.id)).length;
    return voicesCount + (isRead(`room-${article.id}`) ? 0 : 2);
  }, [isRead, article.id, article.externalVoices, isActive]);

  useEffect(() => {
    if (isActive && onUnreadCommentsChange) {
      onUnreadCommentsChange(unreadInRoom);
    }
  }, [unreadInRoom, onUnreadCommentsChange, isActive]);

  const contextValue = useMemo(() => ({
    article, isActive, isUnlocked: true, accentColor, readingMode, setReadingMode
  }), [article, isActive, accentColor, readingMode]);

  // --- MODE PRELOAD (Performance critique) ---
  // Si l'article n'est pas actif (c'est le voisin de gauche ou droite), 
  // on rend une version allégée DOM sans les modules lourds.
  if (isPreloading) {
     return (
        <div className="w-full h-full bg-black flex flex-col relative overflow-hidden">
           <ArticleCover 
             imageUrl={article.imageUrl} 
             videoUrl={undefined} // Pas de vidéo en preload pour sauver la RAM
             title={article.title} 
             articleId={article.id} 
           />
           {/* Placeholder visuel du contenu */}
           <div className="flex-1 bg-black p-8 opacity-20">
               <div className="h-8 bg-zinc-800 rounded w-3/4 mb-4"></div>
               <div className="h-4 bg-zinc-800 rounded w-full mb-2"></div>
               <div className="h-4 bg-zinc-800 rounded w-full mb-2"></div>
           </div>
        </div>
     );
  }

  return (
    <ArticleProvider value={contextValue}>
      <div 
        ref={verticalContainerRef} 
        onScroll={handleScroll}
        className="w-full h-full bg-black hide-scrollbar flex flex-col relative overflow-y-auto overflow-x-hidden"
        style={{ 
          overscrollBehaviorY: 'contain', // Vital pour que le scroll ne fasse pas bouncer toute l'app
          WebkitOverflowScrolling: 'touch',
          scrollBehavior: 'smooth'
        }}
      >
        <ArticleCover 
          imageUrl={article.imageUrl} 
          videoUrl={article.videoUrl}
          title={article.title} 
          articleId={article.id}
        />
        
        <div className="sticky top-0 z-[50] flex flex-col transform-gpu">
          <div className="bg-black/95 border-b border-white/5 pt-2 backdrop-blur-sm supports-[backdrop-filter]:bg-black/80">
            <div className="flex justify-around items-center">
              {[
                { id: 'dossier', label: 'Dossier', icon: Layers },
                { id: 'room', label: 'La Room', icon: Globe },
                { id: 'reseau', label: 'Réseau', icon: BarChart3 }
              ].map((tab) => (
                <button 
                  key={tab.id} 
                  onClick={() => handleTabChange(tab.id as ArticleTab)} 
                  className={`flex flex-col items-center gap-1.5 py-4 transition-all relative flex-1 active:scale-95 ${activeTab === tab.id ? 'text-white' : 'text-white/20'}`}
                >
                  <div className="relative">
                    <tab.icon className="w-4 h-4" />
                    {tab.id === 'room' && unreadInRoom > 0 && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-black animate-flash"></span>
                    )}
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-[0.2em]">{tab.label}</span>
                  {activeTab === tab.id && <div className="absolute bottom-0 left-4 right-4 h-[2px]" style={{ backgroundColor: accentColor }}></div>}
                </button>
              ))}
            </div>
            {isActive && activeTab === 'dossier' && (
              <ReadingProgressBar progress={readProgress} accentColor={accentColor} />
            )}
          </div>
        </div>

        <div className={`flex-1 ${activeTab === 'room' ? 'p-0' : 'p-8 pb-10'} bg-black min-h-[70vh] relative`}>
          <Suspense fallback={<ModuleLoader />}>
            {activeTab === 'dossier' && (
              <DossierModule 
                content={article.content} 
                isEditable={isEditable}
                onUpdate={(updates) => onArticleUpdate?.({ ...article, ...updates })}
              />
            )}
            {activeTab === 'room' && (
              <RoomModule 
                voices={article.externalVoices || []} 
                accentColor={accentColor} 
                focusCommentId={navTarget?.commentId} 
                isEditable={isEditable}
                onUpdate={(updates) => onArticleUpdate?.({ ...article, ...updates })}
              />
            )}
            {activeTab === 'reseau' && <ReseauModule likes={article.likes} comments={article.comments} echoesCount={article.externalVoices?.length || 0} author={article.author} accentColor={accentColor} />}
          </Suspense>
          
          {activeTab === 'dossier' && !isEditable && (
            <div className="mt-20 pb-20 flex flex-col items-center">
              <button 
                onClick={() => {
                   triggerHaptic('medium');
                   onNavigateNext?.();
                }} 
                className="group flex flex-col items-center gap-4 active:scale-90 transition-all"
              >
                <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all">
                  <Globe className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40 group-hover:text-white transition-all">Article Suivant</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </ArticleProvider>
  );
};

export default React.memo(ArticleCard);
