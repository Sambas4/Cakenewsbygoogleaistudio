
import React, { useState, useEffect } from 'react';
import { MessageTab, Message as MessageType } from '../types';
import { MOCK_MESSAGES, MOCK_NOTIFICATIONS } from '../data/mockData';
import { Bell, User, Star, Info } from 'lucide-react';
import { NotificationItem, PrivateMessageBubble, OfficialMessageCard } from './messages/MessageItems';
import { MessageSkeleton } from './ui/Loader';
import { useTranslation } from '../context/TranslationContext';

interface MessagesViewProps {
  dynamicCakeNewsMessages?: MessageType[];
  onNavigateToArticle?: (id: string, commentId?: string) => void;
}

const MessagesView: React.FC<MessagesViewProps> = ({ dynamicCakeNewsMessages = [], onNavigateToArticle }) => {
  const { t } = useTranslation();
  const [activeSubTab, setActiveSubTab] = useState<MessageTab>(MessageTab.CAKENEWS);
  const [isLoading, setIsLoading] = useState(true);

  // Simulation chargement initial
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const subTabs = [
    { id: MessageTab.NOTIFICATIONS, label: t('MSG_TAB_ALERTS'), icon: Bell },
    { id: MessageTab.PRIVATE, label: t('MSG_TAB_PRIVATE'), icon: User },
    { id: MessageTab.CAKENEWS, label: t('MSG_TAB_OFFICIAL'), icon: Star },
  ];

  if (isLoading) {
      return <MessageSkeleton />;
  }

  const renderContent = () => {
    switch (activeSubTab) {
      case MessageTab.NOTIFICATIONS:
        return (
          <div className="flex flex-col h-full animate-in fade-in duration-300">
            <div className="space-y-1">
              {MOCK_NOTIFICATIONS.map((notif) => (
                <NotificationItem key={notif.id} notification={notif} onNavigate={onNavigateToArticle} />
              ))}
              {MOCK_NOTIFICATIONS.length === 0 && (
                <div className="flex flex-col items-center justify-center py-40 opacity-10">
                  <Bell className="w-16 h-16 mb-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.5em]">{t('MSG_EMPTY_ALERTS')}</p>
                </div>
              )}
            </div>
          </div>
        );
      case MessageTab.PRIVATE:
        return (
          <div className="flex flex-col h-full animate-in fade-in duration-300">
            <div className="space-y-2 pb-20">
              {MOCK_MESSAGES.map((msg) => (
                <PrivateMessageBubble key={msg.id} msg={msg} isMe={msg.sender === 'Lucas'} />
              ))}
              {MOCK_MESSAGES.length === 0 && (
                <div className="flex flex-col items-center justify-center py-40 opacity-10">
                  <User className="w-16 h-16 mb-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.5em]">{t('MSG_EMPTY_PRIVATE')}</p>
                </div>
              )}
            </div>
          </div>
        );
      case MessageTab.CAKENEWS:
        return (
          <div className="flex flex-col h-full animate-in fade-in duration-300">
            {/* OPTIMISATION: Fond solide bg-zinc-900 */}
            <div className="bg-zinc-900 p-6 rounded-[32px] border border-white/5 mb-8 flex items-start gap-4">
              <Info className="w-5 h-5 text-white/40 shrink-0 mt-0.5" />
              <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest leading-relaxed">
                {t('MSG_OFFICIAL_DESC')}
              </p>
            </div>
            <div className="space-y-1">
              {dynamicCakeNewsMessages.map((msg) => (
                <OfficialMessageCard key={msg.id} msg={msg} onNavigate={onNavigateToArticle} />
              ))}
              {dynamicCakeNewsMessages.length === 0 && (
                <p className="text-center py-20 text-[10px] font-black text-white/10 uppercase tracking-[0.5em]">Archives vides</p>
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-full bg-black overflow-hidden">
      <div className="p-8 pb-4">
        <h1 className="text-3xl font-[1000] uppercase tracking-normal mb-8">{t('NAV_CHATS')}</h1>
        
        {/* OPTIMISATION: Fond solide bg-zinc-900 et suppression shadow */}
        <div className="flex bg-zinc-900 p-1 border border-white/5 rounded-2xl mb-6">
          {subTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                activeSubTab === tab.id ? 'bg-white text-black' : 'text-white/40'
              }`}
            >
              <tab.icon className="w-3 h-3" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar px-8 pb-32">
        {renderContent()}
      </div>
    </div>
  );
};

export default MessagesView;
