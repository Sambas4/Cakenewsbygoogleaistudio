
import React, { useState, useMemo } from 'react';
import { 
  X, AlertTriangle, ShieldAlert, Zap, CheckCircle2, 
  Send, ArrowRight, Info, Link as LinkIcon, Image as ImageIcon, 
  FileText, Mic, Paperclip, ChevronLeft, Lock, AlertCircle
} from 'lucide-react';
import { useTranslation } from '../context/TranslationContext';

interface ReportPopupProps {
  onClose: () => void;
  onReportSubmitted: (ticketId: string, articleTitle: string) => void;
  articleTitle: string;
}

type ReportCategory = 'truth' | 'ethics' | 'tech';
type ReportStep = 'selection' | 'description' | 'evidence' | 'review' | 'success';

const ReportPopup: React.FC<ReportPopupProps> = ({ onClose, onReportSubmitted, articleTitle }) => {
  const { t } = useTranslation();
  const [step, setStep] = useState<ReportStep>('selection');
  const [category, setCategory] = useState<ReportCategory | null>(null);
  const [description, setDescription] = useState('');
  const [links, setLinks] = useState<string[]>(['']);
  const [attachedFiles, setAttachedFiles] = useState<string[]>([]);
  const [ticketId] = useState(`CKN-${(Math.random() * 100000).toFixed(0)}`);

  const categories = {
    truth: {
      id: 'truth' as ReportCategory,
      title: t('RPT_CAT_TRUTH'),
      subtitle: "Audit de Vérité",
      desc: "Erreur factuelle ou manipulation.",
      icon: AlertTriangle,
      color: "text-amber-400",
      bg: "bg-amber-400/10",
      border: "border-amber-400/30"
    },
    ethics: {
      id: 'ethics' as ReportCategory,
      title: t('RPT_CAT_ETHICS'),
      subtitle: "Audit de Comportement",
      desc: "Haine, harcèlement ou danger.",
      icon: ShieldAlert,
      color: "text-red-500",
      bg: "bg-red-500/10",
      border: "border-red-500/30"
    },
    tech: {
      id: 'tech' as ReportCategory,
      title: t('RPT_CAT_TECH'),
      subtitle: "Audit d'Expérience",
      desc: "Bug d'affichage ou interface.",
      icon: Zap,
      color: "text-sky-400",
      bg: "bg-sky-400/10",
      border: "border-sky-400/30"
    }
  };

  const currentCat = category ? categories[category] : null;
  const isDescriptionValid = description.trim().length >= 30;
  const hasEvidence = useMemo(() => {
    const validLinks = links.filter(l => l.trim().length > 8 && l.includes('.'));
    return validLinks.length > 0 || attachedFiles.length > 0;
  }, [links, attachedFiles]);

  const addLink = () => setLinks([...links, '']);
  const updateLink = (idx: number, val: string) => {
    const newLinks = [...links];
    newLinks[idx] = val;
    setLinks(newLinks);
  };

  const simulateFileUpload = () => {
    const names = ['preuve_capture.png', 'audio_temoignage.mp3', 'doc_source.pdf'];
    const randomName = names[Math.floor(Math.random() * names.length)];
    if (!attachedFiles.includes(randomName)) {
      setAttachedFiles([...attachedFiles, randomName]);
    }
  };

  const handleBack = () => {
    if (step === 'description') setStep('selection');
    else if (step === 'evidence') setStep('description');
    else if (step === 'review') setStep('evidence');
  };

  const handleSubmit = () => {
    setStep('success');
    onReportSubmitted(ticketId, articleTitle);
    setTimeout(onClose, 4000);
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black flex flex-col overflow-hidden animate-in fade-in duration-200">
      <div className="p-6 flex items-center justify-between border-b border-white/10 bg-zinc-950">
        <div className="flex items-center gap-4">
          {step !== 'selection' && step !== 'success' && (
            <button 
              onClick={handleBack}
              className="p-3 bg-white/10 rounded-xl hover:bg-white/20 active:scale-95 transition-all text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-white/50 uppercase tracking-[0.3em] leading-none mb-1">{t('RPT_TITLE')}</span>
            <h2 className="text-lg font-black uppercase text-white tracking-tight">Dossier #{ticketId}</h2>
          </div>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 rounded-full text-white/70 hover:text-white">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* MODIFICATION: pb-24 ajouté pour compenser la BottomNav fixe */}
      <div className="flex-1 overflow-y-auto bg-black p-6 pb-24">
        <div className="max-w-lg mx-auto">
          
          {step === 'selection' && (
            <div className="animate-in slide-in-from-bottom-4 duration-300">
              <h3 className="text-2xl font-black uppercase text-white mb-2 tracking-tighter">{t('RPT_SUBTITLE')}</h3>
              <p className="text-white/60 text-sm mb-8">Sélectionnez le canal d'investigation approprié.</p>
              
              <div className="space-y-4">
                {(Object.values(categories)).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => { setCategory(cat.id); setStep('description'); }}
                    className={`w-full bg-zinc-900 border-2 ${cat.border} p-6 rounded-3xl flex items-center justify-between group active:scale-[0.98] transition-all text-left`}
                  >
                    <div className="flex items-center gap-5">
                      <div className={`p-4 bg-black rounded-2xl border border-white/10 ${cat.color}`}>
                        <cat.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-white font-black uppercase text-sm tracking-tight">{cat.title}</p>
                        <p className="text-white/40 text-[11px] font-bold uppercase tracking-widest mt-1">{cat.desc}</p>
                      </div>
                    </div>
                    <ArrowRight className="w-5 h-5 text-white/20 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 'description' && (
            <div className="animate-in slide-in-from-right-4 duration-300">
              <h3 className="text-2xl font-black uppercase text-white mb-2 tracking-tighter">Votre Justification</h3>
              <p className="text-white/50 text-xs font-bold uppercase tracking-widest mb-8 leading-tight">
                Cible : <span className="text-white">"{articleTitle}"</span>
              </p>
              
              <div className="bg-zinc-900 rounded-3xl p-1 border border-white/10">
                <textarea
                  autoFocus
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t('RPT_DESC_PLACEHOLDER')}
                  className="w-full h-56 bg-transparent p-6 text-white text-lg outline-none placeholder:text-white/20 font-medium resize-none"
                />
              </div>

              <div className="mt-4 flex items-center justify-between px-2">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isDescriptionValid ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  <span className={`text-[10px] font-black uppercase tracking-widest ${isDescriptionValid ? 'text-emerald-500' : 'text-amber-500'}`}>
                    {description.length < 30 ? `Encore ${30 - description.length} caractères` : 'Description validée'}
                  </span>
                </div>
                <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">{description.length} / 1000</span>
              </div>

              <button 
                onClick={() => setStep('evidence')}
                disabled={!isDescriptionValid}
                className={`w-full mt-10 py-6 rounded-2xl font-black uppercase text-sm tracking-widest flex items-center justify-center gap-4 transition-all ${
                  isDescriptionValid ? 'bg-white text-black active:scale-95' : 'bg-zinc-800 text-white/10 cursor-not-allowed'
                }`}
              >
                {t('RPT_BTN_NEXT')} <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 'evidence' && (
            <div className="animate-in slide-in-from-right-4 duration-300">
              <h3 className="text-2xl font-black uppercase text-white mb-2 tracking-tighter">Dépôt de Preuves</h3>
              <p className="text-white/50 text-xs font-bold uppercase tracking-widest mb-10 leading-tight">
                Joignez au moins un lien ou un fichier pour soutenir votre audit.
              </p>
              
              <div className="space-y-10">
                <div className="bg-zinc-900 border border-white/5 p-6 rounded-3xl">
                   <div className="flex items-center gap-3 mb-4">
                      <LinkIcon className="w-4 h-4 text-sky-400" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-white">Liens Sources</span>
                   </div>
                   <div className="space-y-3">
                      {links.map((link, idx) => (
                        <input
                          key={idx}
                          value={link}
                          onChange={(e) => updateLink(idx, e.target.value)}
                          placeholder="https://source-officielle.com/..."
                          className="w-full bg-black border border-white/10 rounded-xl p-4 text-sm text-white focus:border-white/30 outline-none"
                        />
                      ))}
                      <button onClick={addLink} className="text-[10px] font-black text-sky-400 uppercase tracking-widest hover:underline mt-2">+ Ajouter une autre URL</button>
                   </div>
                </div>

                <div className="bg-zinc-900 border border-white/5 p-6 rounded-3xl">
                   <div className="flex items-center gap-3 mb-4">
                      <Paperclip className="w-4 h-4 text-emerald-400" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-white">Médias & Captures</span>
                   </div>
                   <div className="grid grid-cols-2 gap-3">
                      <button onClick={simulateFileUpload} className="bg-black border border-white/10 rounded-2xl p-6 flex flex-col items-center gap-2 active:scale-95 transition-all">
                         <ImageIcon className="w-5 h-5 text-white/40" />
                         <span className="text-[9px] font-black uppercase text-white/40">Image</span>
                      </button>
                      <button onClick={simulateFileUpload} className="bg-black border border-white/10 rounded-2xl p-6 flex flex-col items-center gap-2 active:scale-95 transition-all">
                         <Mic className="w-5 h-5 text-white/40" />
                         <span className="text-[9px] font-black uppercase text-white/40">Audio</span>
                      </button>
                   </div>
                   
                   {attachedFiles.length > 0 && (
                     <div className="mt-6 space-y-2">
                        {attachedFiles.map((file, i) => (
                          <div key={i} className="flex items-center justify-between bg-emerald-500/20 border border-emerald-500/30 p-4 rounded-xl">
                             <div className="flex items-center gap-3">
                               <FileText className="w-4 h-4 text-emerald-400" />
                               <span className="text-[11px] font-bold text-white uppercase truncate max-w-[150px]">{file}</span>
                             </div>
                             <X className="w-4 h-4 text-white/60 hover:text-white" onClick={() => setAttachedFiles(attachedFiles.filter(f => f !== file))} />
                          </div>
                        ))}
                     </div>
                   )}
                </div>
              </div>

              {!hasEvidence && (
                <div className="mt-8 p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                  <p className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">Une preuve est requise pour soumettre l'audit.</p>
                </div>
              )}

              <button 
                onClick={() => setStep('review')}
                disabled={!hasEvidence}
                className={`w-full mt-10 py-6 rounded-2xl font-black uppercase text-sm tracking-widest flex items-center justify-center gap-4 transition-all ${
                  hasEvidence ? 'bg-white text-black active:scale-95' : 'bg-zinc-800 text-white/10 cursor-not-allowed'
                }`}
              >
                Vérifier le Dossier <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 'review' && (
            <div className="animate-in slide-in-from-right-4 duration-300">
              <h3 className="text-2xl font-black uppercase text-white mb-8 tracking-tighter">Récapitulatif Final</h3>
              
              <div className="bg-zinc-900 border border-white/10 rounded-[32px] p-8 space-y-8">
                <div className="flex items-center justify-between pb-6 border-b border-white/10">
                   <div>
                     <span className="text-[9px] font-black text-white/30 uppercase tracking-widest block mb-1">Investigation</span>
                     <p className={`text-xl font-black uppercase ${currentCat?.color}`}>{currentCat?.title}</p>
                   </div>
                   <div className="p-3 bg-black rounded-xl border border-white/10">
                     {currentCat && <currentCat.icon className={`w-6 h-6 ${currentCat.color}`} />}
                   </div>
                </div>

                <div>
                   <span className="text-[9px] font-black text-white/30 uppercase tracking-widest block mb-2">Votre Justification</span>
                   <p className="text-base text-white font-bold leading-relaxed uppercase tracking-tight line-clamp-4">"{description}"</p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
                  <div className="bg-black p-4 rounded-2xl border border-white/5">
                    <span className="text-[8px] font-black text-white/30 uppercase tracking-widest block mb-1">URLs Sources</span>
                    <p className="text-2xl font-black text-white">{links.filter(l => l.trim().length > 0).length}</p>
                  </div>
                  <div className="bg-black p-4 rounded-2xl border border-white/5">
                    <span className="text-[8px] font-black text-white/30 uppercase tracking-widest block mb-1">Fichiers Médias</span>
                    <p className="text-2xl font-black text-white">{attachedFiles.length}</p>
                  </div>
                </div>
              </div>

              <div className="mt-10 p-6 bg-red-600/10 border border-red-600/30 rounded-[32px] flex gap-4">
                 <Lock className="w-6 h-6 text-red-600 shrink-0" />
                 <p className="text-[11px] text-white/70 font-bold uppercase tracking-widest leading-relaxed">
                   En soumettant ce dossier, vous engagez votre crédibilité d'auditeur Cakenews. Un abus peut entraîner des sanctions.
                 </p>
              </div>

              <button 
                onClick={handleSubmit}
                className="w-full mt-10 py-8 bg-red-600 text-white rounded-[32px] font-black uppercase text-lg tracking-[0.3em] flex items-center justify-center gap-5 transition-all active:scale-95"
              >
                {t('RPT_BTN_SUBMIT')} <Send className="w-6 h-6" />
              </button>
            </div>
          )}

          {step === 'success' && (
            <div className="flex-1 h-full flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 min-h-[60vh]">
              <div className="w-32 h-32 bg-white text-black rounded-full flex items-center justify-center mb-10 relative">
                <CheckCircle2 className="w-16 h-16" />
                <div className="absolute inset-0 rounded-full border-4 border-white animate-ping opacity-20"></div>
              </div>
              <h3 className="text-4xl font-black uppercase text-white mb-4 text-center tracking-tighter">DOSSIER REÇU</h3>
              <p className="text-white/50 text-[11px] font-black uppercase tracking-[0.4em] text-center max-w-[280px] leading-relaxed mb-10">
                Réf : {ticketId}<br/>
                Statut : Investigation Lancée
              </p>
              <div className="px-8 py-4 bg-zinc-900 border border-white/10 rounded-2xl flex items-center gap-3">
                 <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                 <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">En cours de traitement par l'équipe</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportPopup;
