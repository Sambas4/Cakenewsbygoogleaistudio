
import React, { useState } from 'react';
import { Lock, ChevronRight, Delete } from 'lucide-react';
import { useTranslation } from '../context/TranslationContext';

interface AuthViewProps {
  onLogin: (role: 'PUBLIC' | 'ADMIN') => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLogin }) => {
  const { t } = useTranslation();
  const [code, setCode] = useState('');
  const [error, setError] = useState(false);

  const handleKey = (key: string) => {
    if (code.length < 6) {
      setCode(prev => prev + key);
      setError(false);
    }
  };

  const handleDelete = () => {
    setCode(prev => prev.slice(0, -1));
    setError(false);
  };

  const handleSubmit = () => {
    // Code Admin hardcodé pour la démo : 000000
    if (code === '000000') {
      onLogin('ADMIN');
    } else if (code.length > 0) {
      // Tout autre code mène au public (mode guest)
      onLogin('PUBLIC');
    } else {
      setError(true);
    }
  };

  return (
    <div className="w-full h-full bg-black flex flex-col items-center justify-between p-6">
      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-xs">
        <div className="mb-12 text-center w-full">
           <h1 className="text-4xl font-[1000] uppercase tracking-tighter text-white mb-2">CAKENEWS</h1>
           <div className="h-1 w-20 bg-white mx-auto mb-8"></div>
           
           {/* Code Display - Flat & Brutal */}
           <div className={`w-full bg-zinc-900 border-2 py-6 px-4 flex justify-center gap-4 mb-4 ${error ? 'border-red-600' : 'border-white/20'}`}>
              {[...Array(6)].map((_, i) => (
                <div 
                  key={i} 
                  className={`w-3 h-3 ${i < code.length ? 'bg-white' : 'bg-zinc-800'}`}
                />
              ))}
           </div>
           
           <p className={`text-[10px] font-mono uppercase tracking-widest ${error ? 'text-red-600' : 'text-zinc-500'}`}>
             {error ? t('AUTH_DENIED') : t('AUTH_TITLE')}
           </p>
        </div>

        {/* Keypad - High Performance CSS Grid */}
        <div className="w-full grid grid-cols-3 gap-2 mb-8">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handleKey(num.toString())}
              className="h-20 bg-zinc-900 text-white text-2xl font-[1000] active:bg-white active:text-black touch-manipulation"
            >
              {num}
            </button>
          ))}
          <div className="h-20 bg-black flex items-center justify-center pointer-events-none">
            <Lock className="w-5 h-5 text-zinc-800" />
          </div>
          <button
            onClick={() => handleKey('0')}
            className="h-20 bg-zinc-900 text-white text-2xl font-[1000] active:bg-white active:text-black touch-manipulation"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-20 bg-zinc-900 text-white flex items-center justify-center active:bg-white active:text-black touch-manipulation"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>

        <button 
          onClick={handleSubmit}
          className="w-full py-6 bg-white text-black font-[1000] uppercase tracking-widest text-sm flex items-center justify-center gap-2 active:bg-zinc-300"
        >
          {t('AUTH_BUTTON')} <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default AuthView;
