
import { Category } from './types';

export const CATEGORIES: Category[] = ['Tech', 'Lifestyle', 'Politique', 'Sport', 'Culture', 'Crypto', 'Mode'];

export const CATEGORY_COLORS: Record<Category, string> = {
  'Tech': '#4f46e5',
  'Lifestyle': '#0284c7',
  'Politique': '#7c3aed',
  'Sport': '#ea580c',
  'Culture': '#059669',
  'Crypto': '#f59e0b',
  'Mode': '#db2777'
};

export const getTextColor = (category: Category, isExclusive?: boolean): string => {
  if (isExclusive) return 'text-white';
  return category === 'Crypto' ? 'text-black' : 'text-white';
};
