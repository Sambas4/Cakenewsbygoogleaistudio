
export type Category = 'Tech' | 'Lifestyle' | 'Politique' | 'Sport' | 'Culture' | 'Crypto' | 'Mode';

// --- SYSTÈME DE TRADUCTION ---
export type TranslationKey = string; // ex: 'ACTION_LIKE', 'NAV_HOME'

export interface TranslationDictionary {
  id: string;
  name: string; // ex: "Français", "Argot", "Fang"
  isDefault?: boolean;
  translations: Record<TranslationKey, string>;
}

export interface ExternalVoice {
  id: string;
  source: string;
  author: string;
  avatar: string;
  type: 'video' | 'audio' | 'text' | 'tweet';
  title?: string;
  content: string;
  url: string;
}

export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string;
  imageUrl: string;
  videoUrl?: string;
  author: string;
  category: Category;
  timestamp: string;
  likes: number;
  comments: number;
  isExclusive?: boolean;
  isSensitive?: boolean;
  externalVoices?: ExternalVoice[];
  status?: 'published' | 'scheduled' | 'draft';
  scheduledDate?: string;
}

export interface Message {
  id: string;
  sender: string;
  avatar: string;
  text: string;
  time: string;
  isOfficial?: boolean;
  articleId?: string;
}

export type NotificationType = 'like' | 'mention' | 'report' | 'system';

export interface AppNotification {
  id: string;
  type: NotificationType;
  user: {
    name: string;
    avatar: string;
  };
  content: string;
  time: string;
  articleId?: string;
  isRead: boolean;
}

export interface AuditLog {
  id: string;
  adminName: string;
  action: string;
  timestamp: string;
}

export interface ReportTicket {
  id: string;
  targetId: string; 
  targetType: 'ARTICLE' | 'COMMENT' | 'USER';
  targetTitle?: string;
  targetContentPreview?: string;
  reason: 'truth' | 'ethics' | 'tech';
  description: string;
  reporter: string;
  reporterScore: number;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'DISMISSED';
  timestamp: string;
  evidenceLinks?: string[];
  assignedTo?: string;
  internalNotes?: AuditLog[];
}

// --- GEOLOCALISATION UTILISATEUR ---
export interface UserLocation {
  neighborhood: string; // ex: "Louis", "Nzeng Ayong"
  city: string;         // ex: "Libreville"
  country: string;      // ex: "Gabon"
  isSet: boolean;       // Si l'utilisateur a configuré sa zone
}

// --- STATISTIQUES UTILISATEUR (TRACKING) ---
export interface UserStats {
  likesGiven: number;      // "J'aime" distribués (Engagement actif)
  likesReceived: number;   // "J'aime" reçus sur commentaires (Popularité)
  commentsPosted: number;  // Nombre de débats rejoints
  reportsReceived: number; // Signalements contre cet utilisateur (Modération)
  trustScore: number;      // Score de confiance calculé (0-100)
}

export interface UserData {
  id: string;
  name: string;
  handle: string;
  role: 'ADMIN' | 'USER' | 'MODERATOR';
  status: 'ACTIVE' | 'BANNED' | 'PENDING';
  joinDate: string;
  avatar: string;
  location?: UserLocation;
  stats: UserStats; // NOUVEAU: Données de tracking
}

// --- NOUVEAUX TYPES BROADCAST AVANCÉS ---

export type BroadcastType = 'INFO' | 'ALERT' | 'PROMO';

export interface BroadcastTargeting {
  locations: string[]; // Liste des quartiers/villes ciblés (ex: ["Louis", "Libreville"])
  interests?: Category[]; // NOUVEAU: Ciblage par centre d'intérêt
  userIds?: string[];
  minAppVersion?: string;
}

export interface BroadcastSchedule {
  startDate: string; // ISO Date
  endDate?: string; // Si null, indéfini
  isActive: boolean; // Switch manuel ON/OFF
}

export interface BroadcastCapping {
  maxViews: number; // 0 = illimité
  resetPeriod?: 'session' | 'daily' | 'never'; // Quand remettre le compteur à 0
}

export interface BroadcastCampaign {
  id: string;
  name: string; // Nom interne pour l'admin
  message: string; // Texte affiché
  type: BroadcastType;
  targeting: BroadcastTargeting;
  schedule: BroadcastSchedule;
  capping: BroadcastCapping;
  priority: number; // 1 (bas) à 10 (haut/urgent)
  createdAt: string;
  linkedArticleId?: string; // ID de l'article à ouvrir lors du clic (Optionnel)
}

// Configuration du Classement Ticker
export interface ManualRankingEntry {
  id: string;
  userName: string;
  avatar: string; // URL
  score: string; // ex: "1.5k" (formaté)
  rawValue: number; // Valeur brute pour le tri éventuel
  categoryLabel: string; // ex: "EXPERT TECH"
  color: string; // Hex color
}

export interface TickerConfig {
  mode: 'HYBRID'; // Legacy, gardé pour compatibilité
  speed: 'slow' | 'normal' | 'fast';
  defaultLocation: string; 
  rankingMode: 'AUTO' | 'MANUAL' | 'HYBRID';
  manualRankings: ManualRankingEntry[];
  categoryTitles: Record<string, string>; // NOUVEAU: Map "TECH" -> "LES ROIS DE LA TECH"
}

export interface UserPreferences {
  categories: Category[];
}

export enum AppTab {
  HOME = 'home',
  MY_FEED = 'feed',
  MESSAGES = 'messages',
  PROFILE = 'profile'
}

export enum AdminTab {
  RESEAU = 'reseau',
  DOSSIERS = 'dossiers',
  UTILISATEURS = 'utilisateurs', 
  AUDIT = 'audit',
  ANTENNE = 'antenne',
  LOCALISATION = 'localisation' // NOUVEAU
}

export enum MessageTab {
  NOTIFICATIONS = 'notifications',
  PRIVATE = 'private',
  CAKENEWS = 'cakenews'
}

export type AppViewMode = 'AUTH' | 'PUBLIC' | 'ADMIN';
